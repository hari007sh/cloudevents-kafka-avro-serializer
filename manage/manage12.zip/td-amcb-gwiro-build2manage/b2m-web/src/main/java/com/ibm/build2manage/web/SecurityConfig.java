package com.ibm.build2manage.web;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.ConstructorBinding;

/**
 * Security configuration.
 */
@Data
@ConstructorBinding
@ConfigurationProperties("b2m-web.security")
public class SecurityConfig {

    private final String[] baseWhitelist;
    private final String[] whiteList;

}
