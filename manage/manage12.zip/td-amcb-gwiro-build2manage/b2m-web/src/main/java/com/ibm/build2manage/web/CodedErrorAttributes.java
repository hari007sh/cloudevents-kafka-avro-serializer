package com.ibm.build2manage.web;

import com.ibm.build2manage.errors.CodedException;
import org.springframework.boot.web.error.ErrorAttributeOptions;
import org.springframework.boot.web.servlet.error.DefaultErrorAttributes;
import org.springframework.boot.web.servlet.error.ErrorAttributes;
import org.springframework.web.context.request.WebRequest;

import java.util.Map;

/**
 * Implementation of {@link ErrorAttributes} that adds the error code when
 * receiving a {@link CodedException}.
 */
public class CodedErrorAttributes extends DefaultErrorAttributes {

    @Override
    public Map<String, Object> getErrorAttributes(WebRequest webRequest, ErrorAttributeOptions options) {
        Map<String, Object> result = super.getErrorAttributes(webRequest, options);
        Throwable error = getError(webRequest);
        if (error instanceof CodedException) {
            result.put("code", ((CodedException) error).getErrorCode());
        } else {
            result.put("code", null);
        }
        return result;
    }
}
