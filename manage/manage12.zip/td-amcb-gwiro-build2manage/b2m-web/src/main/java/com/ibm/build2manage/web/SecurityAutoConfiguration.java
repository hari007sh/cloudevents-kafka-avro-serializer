package com.ibm.build2manage.web;

import org.springframework.boot.autoconfigure.AutoConfigureBefore;
import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.autoconfigure.web.servlet.error.ErrorMvcAutoConfiguration;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;

/**
 * Autoconfiguration of Build 2 Manage for web secured applications.
 */
@Configuration
@PropertySource("security.properties")
@AutoConfigureBefore(ErrorMvcAutoConfiguration.class)
@ConditionalOnClass(WebSecurityConfigurerAdapter.class)
@EnableConfigurationProperties(SecurityConfig.class)
public class SecurityAutoConfiguration {

    @Bean
    @ConditionalOnMissingBean(WebSecurityConfigurerAdapter.class)
    WebSecurityConfigurerAdapter security(SecurityConfig config, ApplicationContext context) {
        return new SecurityConfigurer(config, context);
    }

}
