package com.ibm.build2manage.web;

import com.ibm.build2manage.errors.CodedException;
import com.ibm.build2manage.errors.ErrorSource;
import lombok.RequiredArgsConstructor;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.MissingRequestHeaderException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;

/**
 * Class responsible for managing common exceptions and returns the appropriate error.
 */
@ControllerAdvice
@RequiredArgsConstructor
public class DefaultControllerAdvice {

    private static final Logger LOG = LogManager.getLogger(DefaultControllerAdvice.class);

    private final ErrorSource source;

    /**
     * Returns 428 - Precondition Required when a validation fails for a missing If-* header
     *
     * @param ex the exception
     *
     * @throws MissingRequestHeaderException if thd missing header is not precondition related
     */
    @ExceptionHandler(MissingRequestHeaderException.class)
    @ResponseStatus(HttpStatus.PRECONDITION_REQUIRED)
    public void missingHeaderException(MissingRequestHeaderException ex) throws MissingRequestHeaderException {
        String headerName = ex.getHeaderName();
        // Validate in a case insensitive way that the missing header name starts with if-
        if (headerName == null || headerName.length() < 3 ||
                !((headerName.charAt(0) == 'i' || headerName.charAt(0) == 'I') &&
                        (headerName.charAt(1) == 'f' || headerName.charAt(1) == 'F') &&
                        headerName.charAt(2) == '-')) {
            throw ex;
        }
        LOG.atWarn().withThrowable(ex).log("Missing required precondition: {}", ex);
    }

    /**
     * Make sure that a {@link CodedException} is properly logged and returns a 500 - internal server error response
     * properly formatted.
     *
     * @param ex the exception
     */
    @ExceptionHandler(CodedException.class)
    @ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
    public void errorCodeException(CodedException ex) {
        LOG.atFatal().withThrowable(ex).log(source.get(ex.getErrorCode(), ex.getDefaultMessage(), ex.getArgs()));
    }
}
