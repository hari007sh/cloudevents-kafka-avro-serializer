package com.ibm.build2manage.web;

import lombok.RequiredArgsConstructor;
import org.springframework.beans.BeansException;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.annotation.AnnotationAwareOrderComparator;
import org.springframework.security.config.Customizer;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.config.annotation.web.configurers.oauth2.server.resource.OAuth2ResourceServerConfigurer;
import org.springframework.security.config.http.SessionCreationPolicy;

import java.util.*;

/**
 * Security configuration for the web service. This implementation allows to define a set of whitelisted URLs that will
 * not be secured. It is possible to configure the JWT security using {@link JwtCustomizer} beans.
 */
@Configuration
@RequiredArgsConstructor
public class SecurityConfigurer extends WebSecurityConfigurerAdapter {

    private final SecurityConfig config;

    private final ApplicationContext context;

    @Override
    protected void configure(HttpSecurity http) throws Exception {
        HttpSecurity tmp = http
                .httpBasic().disable()
                .csrf().disable()
                .sessionManagement().sessionCreationPolicy(SessionCreationPolicy.STATELESS)
                .and()
                .authorizeRequests().antMatchers(config.getBaseWhitelist()).permitAll()
                .antMatchers(config.getWhiteList()).permitAll()
                .anyRequest().authenticated()
                .and();
        try {
            List<JwtCustomizer> beans = new ArrayList<>(context.getBeansOfType(JwtCustomizer.class).values());
            beans.sort(AnnotationAwareOrderComparator.INSTANCE);
            tmp.oauth2ResourceServer().jwt(j -> beans.forEach(c -> c.customize(j)));
        } catch (BeansException e) {
            tmp.oauth2ResourceServer(OAuth2ResourceServerConfigurer::jwt);
        }
    }

    /**
     * Simple interface to remove generics, allowing for easy bean injection.
     */
    public interface JwtCustomizer extends Customizer<OAuth2ResourceServerConfigurer<HttpSecurity>.JwtConfigurer> {

    }
}
