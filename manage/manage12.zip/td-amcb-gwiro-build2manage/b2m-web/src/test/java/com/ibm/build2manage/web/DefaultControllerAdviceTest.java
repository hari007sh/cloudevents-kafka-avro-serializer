package com.ibm.build2manage.web;

import com.ibm.build2manage.errors.ErrorSource;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.NullSource;
import org.junit.jupiter.params.provider.ValueSource;
import org.mockito.Mockito;
import org.springframework.web.bind.MissingRequestHeaderException;

class DefaultControllerAdviceTest {

    private static final ErrorSource ERRORS = Mockito.mock(ErrorSource.class);

    private static final DefaultControllerAdvice UNDER_TEST = new DefaultControllerAdvice(ERRORS);

    @ParameterizedTest
    @ValueSource(strings = {
            "If-Match",
            "if-match",
            "IF-MATCH",
            "iF-mATCH",
            "if-"
    })
    void shouldNotThrowException(String headerName) {
        Assertions.assertDoesNotThrow(() -> UNDER_TEST.missingHeaderException(new MissingRequestHeaderException(headerName, null)));
    }

    @ParameterizedTest
    @NullSource
    @ValueSource(strings = {
            "If",
            "if",
            "IF",
            "iF",
            "SomethingElse",
            ""
    })
    void shouldThrowException(String headerName) {
        MissingRequestHeaderException expected = new MissingRequestHeaderException(headerName, null);
        MissingRequestHeaderException actual = Assertions.assertThrows(MissingRequestHeaderException.class, () -> UNDER_TEST.missingHeaderException(expected));
        Assertions.assertSame(expected, actual);
    }

}