package com.ibm.build2manage.web;

import io.restassured.response.Response;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.ResponseEntity;

import static org.junit.jupiter.api.Assertions.assertNotEquals;

@SpringBootTest(classes = WebAutoConfiguration.class,
        webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT,
        properties = {"test.path=/",
                "b2m-web.security.whitelist=/manual",
                "spring.security.oauth2.resourceserver.jwt.public-key-location=classpath:jwk.pub"
        })
public class SecurityConfigurerIT extends AbstractWebTest {

    @ValueSource(strings = {
            "/manual",
            "/v2/api-docs",
            "/error",
            "/swagger-resources/something",
            "/configuration/ui",
            "/configuration/security",
            "/swagger-ui.html",
            "/webjars/something"
    })
    @ParameterizedTest
    void shouldAllow(String url) {
        Response tmp = given(r -> ResponseEntity.noContent().build())
                .log()
                .all()
                .when()
                .get(url);
        assertNotEquals(401, tmp.getStatusCode());
    }

    @ValueSource(strings = {
            "/secured",
            "/bob"
    })
    @ParameterizedTest
    void shouldNotAllow(String url) {
        given(r -> ResponseEntity.noContent().build())
                .when()
                .get(url)
                .then()
                .statusCode(401);
    }

}
