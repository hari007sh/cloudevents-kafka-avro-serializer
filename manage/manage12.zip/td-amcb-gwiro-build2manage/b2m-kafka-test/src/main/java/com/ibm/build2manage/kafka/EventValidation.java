package com.ibm.build2manage.kafka;

import lombok.Getter;
import lombok.extern.log4j.Log4j2;
import org.apache.kafka.clients.admin.*;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.consumer.OffsetAndMetadata;
import org.apache.kafka.common.TopicPartition;
import org.awaitility.Awaitility;
import org.junit.jupiter.api.Assertions;
import org.springframework.kafka.config.KafkaListenerEndpoint;
import org.springframework.kafka.listener.MessageListener;
import org.springframework.kafka.listener.MessageListenerContainer;
import org.springframework.kafka.support.TopicPartitionOffset;
import org.springframework.kafka.support.converter.MessageConverter;
import org.springframework.lang.NonNull;

import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeUnit;
import java.util.function.Consumer;
import java.util.regex.Pattern;

@Log4j2
public class EventValidation<K, V> implements KafkaListenerEndpoint {

    private final String topic;

    private final Consumer<ConsumerRecord<K, V>> onEvent;

    private final AdminClient admin;

    @Getter
    private final String id;

    private final ConsumerRecord<K, V>[] data;

    public EventValidation(String topic, AdminClient admin, int partitions, Consumer<ConsumerRecord<K, V>> onEvent) {
        this.topic = topic;
        this.admin = admin;
        this.id = topic + "-" + hashCode();
        this.data = new ConsumerRecord[partitions];
        this.onEvent = onEvent;
    }


    public ConsumerRecord<K, V> getData() {
        return getData(0);
    }

    public ConsumerRecord<K, V> getData(int partition) {
        Assertions.assertTrue(partition >= 0 && partition < data.length);
        return data[partition];
    }

    @Override
    public String getGroupId() {
        return getId();
    }

    @Override
    public String getGroup() {
        return getId();
    }

    @NonNull
    @Override
    public Collection<String> getTopics() {
        return List.of(topic);
    }

    @Override
    public TopicPartitionOffset[] getTopicPartitionsToAssign() {
        return new TopicPartitionOffset[0];
    }

    @Override
    public Pattern getTopicPattern() {
        return null;
    }

    @Override
    public String getClientIdPrefix() {
        return null;
    }

    @Override
    public Integer getConcurrency() {
        return 1;
    }

    @Override
    public Boolean getAutoStartup() {
        return true;
    }

    @Override
    public void setupListenerContainer(@NonNull MessageListenerContainer listenerContainer, MessageConverter messageConverter) {
        listenerContainer.setupMessageListener((MessageListener<K, V>) this::receive);
    }

    private void receive(ConsumerRecord<K, V> data) {
        log.atInfo().log("Received payload {}", data);
        try {
            onEvent.accept(data);
        } finally {
            this.data[data.partition()] = data;
        }
    }

    @Override
    public boolean isSplitIterables() {
        return false;
    }

    public EventValidation<K, V> waitAtMost(long duration, TimeUnit unit) {
        Map<TopicPartition, ListOffsetsResult.ListOffsetsResultInfo> expected = getExpected(duration, unit);
        log.atDebug().log("Expecting partition offsets of {}", expected);
        Awaitility.await()
                .atMost(duration, unit).until(() -> {
                    Map<TopicPartition, OffsetAndMetadata> partitions = admin.listConsumerGroupOffsets(id).partitionsToOffsetAndMetadata().get();
                    log.atTrace().log("Current partitions: {}", partitions);
                    if (partitions == null || partitions.size() != expected.size()) {
                        log.atTrace().log("Size does not matches");
                        return false;
                    }
                    for (Map.Entry<TopicPartition, ListOffsetsResult.ListOffsetsResultInfo> p : expected.entrySet()) {
                        if (!partitions.containsKey(p.getKey()) || partitions.get(p.getKey()).offset() < p.getValue().offset()) {
                            log.atTrace().log("Offset did not match for topic {}", p);
                            return false;
                        }
                    }
                    log.atDebug().log("Partition matched");
                    return true;
                });
        return this;
    }

    private Map<TopicPartition, ListOffsetsResult.ListOffsetsResultInfo> getExpected(long duration, TimeUnit unit) {
        // Wait for consumer to be registered with Kafka
        log.atDebug().log("Waiting for {} to connect", id);
        Awaitility.await().atMost(duration, unit).until(() -> {
            int detected = admin.listConsumerGroupOffsets(id).partitionsToOffsetAndMetadata().get().size();
            log.atTrace().log("{} partition information detected for group {}", detected, id);
            return data.length == detected;
        });
        log.atDebug().log("Endpoint {} connected", id);
        try {
            ConsumerGroupDescription description = admin.describeConsumerGroups(List.of(id))
                    .all()
                    .get()
                    .get(id);
            Map<TopicPartition, OffsetSpec> topics = new HashMap<>();
            for (MemberDescription member : description.members()) {
                for (TopicPartition p : member.assignment().topicPartitions()) {
                    topics.put(p, OffsetSpec.latest());
                }
            }
            return admin.listOffsets(topics).all().get();
        } catch (InterruptedException | ExecutionException e) {
            throw new RuntimeException(e);
        }
    }
}
