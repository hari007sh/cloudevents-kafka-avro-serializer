package com.ibm.build2manage.kafka;

import org.springframework.core.annotation.AnnotatedElementUtils;
import org.springframework.kafka.test.context.EmbeddedKafka;
import org.springframework.lang.NonNull;
import org.springframework.test.context.ContextConfigurationAttributes;
import org.springframework.test.context.ContextCustomizer;
import org.springframework.test.context.ContextCustomizerFactory;

import java.util.List;

public class KafkaTestCustomizerFactory implements ContextCustomizerFactory {

    @Override
    public ContextCustomizer createContextCustomizer(@NonNull Class<?> testClass, @NonNull List<ContextConfigurationAttributes> configAttributes) {
        EmbeddedKafka embeddedKafka =
                AnnotatedElementUtils.findMergedAnnotation(testClass, EmbeddedKafka.class);
        return embeddedKafka != null ? new KafkaTestCustomizer(testClass.getSimpleName()) : null;
    }
}
