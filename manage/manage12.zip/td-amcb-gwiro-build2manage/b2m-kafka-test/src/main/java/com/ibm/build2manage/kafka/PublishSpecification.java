package com.ibm.build2manage.kafka;

import lombok.AccessLevel;
import lombok.RequiredArgsConstructor;
import lombok.extern.log4j.Log4j2;
import org.apache.kafka.clients.admin.AdminClient;
import org.apache.kafka.clients.admin.AdminClientConfig;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.kafka.common.header.Header;
import org.apache.kafka.common.header.internals.RecordHeader;
import org.awaitility.Awaitility;
import org.springframework.kafka.config.ConcurrentKafkaListenerContainerFactory;
import org.springframework.kafka.config.KafkaListenerEndpointRegistry;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.lang.NonNull;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.concurrent.TimeUnit;
import java.util.function.Consumer;

@Log4j2
@RequiredArgsConstructor(access = AccessLevel.MODULE)
public class PublishSpecification<K, V> {

    @SuppressWarnings("rawtypes")
    private static final Consumer NO_OP = c -> {
    };
    private static KafkaTestPropertySource PROPS;

    private final String topic;

    private final int partitions;

    private final AdminClient admin;

    private Consumer<ConsumerRecord<K, V>> onEvent;


    public static void init(KafkaTestPropertySource properties) {
        PROPS = properties;
    }

    public static <K, V> PublishSpecification<K, V> given(@NonNull String topic) {
        return new PublishSpecification<>(
                Objects.requireNonNull(topic),
                (int) PROPS.getProperty("spring.kafka.streams.replication-factor"),
                AdminClient.create(Collections.singletonMap(AdminClientConfig.BOOTSTRAP_SERVERS_CONFIG, PROPS.getProperty("spring.kafka.bootstrap-servers")))
        );
    }

    @SuppressWarnings("unchecked")
    public static <K, V> Consumer<ConsumerRecord<K, V>> noop() {
        return NO_OP;
    }

    private K key;

    private V value;

    private final List<Header> headers = new ArrayList<>();

    public PublishSpecification<K, V> key(K key) {
        this.key = key;
        return this;
    }

    public PublishSpecification<K, V> value(V value) {
        this.value = value;
        return this;
    }

    public PublishSpecification<K, V> header(String name, String value) {
        headers.add(new RecordHeader(name, value.getBytes()));
        return this;
    }

    public PublishSpecification<K, V> send(KafkaTemplate<K, V> kafka) {
        ProducerRecord<K, V> msg = key == null ? new ProducerRecord<>(topic, value) : new ProducerRecord<>(topic, key, value);
        headers.forEach(msg.headers()::add);
        log.info("Sending message {}", msg);
        kafka.send(msg);
        return this;
    }

    public EventValidation<K, V> then(KafkaListenerEndpointRegistry registry, ConcurrentKafkaListenerContainerFactory<K, V> factory) {
        EventValidation<K, V> endpoint = new EventValidation<>(topic, admin, partitions, Objects.requireNonNullElseGet(onEvent, PublishSpecification::noop));
        // TODO allow using a different CommonHandler
        factory.setCommonErrorHandler(ErrorIgnoredCommonHandler.INSTANCE);
        log.atInfo().log("Registering endpoint {}", endpoint.getGroupId());
        registry.registerListenerContainer(endpoint, factory, true);
        log.atDebug().log("Endpoint {} registered", endpoint.getGroupId());
        return endpoint;
    }

    public PublishSpecification<K, V> onEvent(Consumer<ConsumerRecord<K, V>> onEvent) {
        this.onEvent = onEvent;
        return this;
    }
}
