package com.ibm.build2manage.kafka;

import org.springframework.kafka.listener.CommonErrorHandler;

/**
 * Implementation of {@link CommonErrorHandler} that specify we ingore
 */
public class ErrorIgnoredCommonHandler implements CommonErrorHandler {
    public static final CommonErrorHandler INSTANCE = new ErrorIgnoredCommonHandler();
}
