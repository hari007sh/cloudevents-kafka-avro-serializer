package com.ibm.build2manage.kafka;

import lombok.RequiredArgsConstructor;
import lombok.extern.log4j.Log4j2;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.core.env.ConfigurableEnvironment;
import org.springframework.core.env.MutablePropertySources;
import org.springframework.core.env.PropertySource;
import org.springframework.kafka.test.EmbeddedKafkaBroker;
import org.springframework.lang.NonNull;
import org.springframework.test.context.ContextCustomizer;
import org.springframework.test.context.MergedContextConfiguration;

@Log4j2
@RequiredArgsConstructor
public class KafkaTestCustomizer implements ContextCustomizer {
    private static final int HASH_CODE = new Object().hashCode();

    private final String appName;

    @Override
    public void customizeContext(ConfigurableApplicationContext context, @NonNull MergedContextConfiguration mergedConfig) {
        ConfigurableEnvironment environment = context.getEnvironment();
        MutablePropertySources propertySources = environment.getPropertySources();
        PropertySource<?> existing = propertySources.get(KafkaTestPropertySource.NAME);
        if (existing != null) {
            log.trace("EmbeddedKafkaPropertySource already present");
            return;
        }
        existing = new KafkaTestPropertySource(context, appName);
        propertySources.addFirst(existing);
        PublishSpecification.init((KafkaTestPropertySource) existing);
        log.trace("EmbeddedKafkaPropertySource added to Environment");
    }

    @Override
    public int hashCode() {
        return HASH_CODE;
    }

    @Override
    public boolean equals(Object obj) {
        return obj instanceof KafkaTestCustomizer;
    }
}
