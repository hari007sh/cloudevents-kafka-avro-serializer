package com.ibm.build2manage.kafka;

import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.kafka.annotation.EnableKafka;
import org.springframework.kafka.test.context.EmbeddedKafka;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.context.TestPropertySource;

import java.lang.annotation.*;

@Inherited
@EnableKafka
@DirtiesContext
@EnableAutoConfiguration
@Target(ElementType.TYPE)
@Retention(RetentionPolicy.RUNTIME)
@EmbeddedKafka(partitions = 1)
@TestPropertySource(properties = {
        "spring.kafka.security.protocol=PLAINTEXT"
})

@PropertySource("classpath:defaults.properties")
public @interface KafkaTest {
}
