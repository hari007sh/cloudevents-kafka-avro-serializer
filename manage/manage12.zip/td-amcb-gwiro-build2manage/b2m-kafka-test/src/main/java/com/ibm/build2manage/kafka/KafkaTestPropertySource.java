package com.ibm.build2manage.kafka;

import lombok.extern.log4j.Log4j2;
import org.springframework.beans.BeansException;
import org.springframework.context.ApplicationContext;
import org.springframework.core.env.PropertySource;
import org.springframework.kafka.test.EmbeddedKafkaBroker;
import org.springframework.lang.NonNull;

import java.util.function.Function;

@Log4j2
public class KafkaTestPropertySource extends PropertySource<ApplicationContext> {

    public static final String NAME = "EmbeddedKafka";
    private final String appName;

    public KafkaTestPropertySource(ApplicationContext context, String appName) {
        super(NAME, context);
        this.appName = appName;
    }

    @Override
    public Object getProperty(@NonNull String name) {
        switch (name) {
            case "spring.kafka.bootstrap-servers":
                return get(EmbeddedKafkaBroker::getBrokersAsString);
            case "spring.kafka.streams.replication-factor":
                return get(EmbeddedKafkaBroker::getPartitionsPerTopic);
            case "spring.application.name":
                return appName;
            default:
                log.debug("Unsupported property: {}", name);
        }
        return null;
    }

    private Object get(Function<EmbeddedKafkaBroker, Object> fct) {
        Object value = null;
        try {
            value = fct.apply(source.getBean(EmbeddedKafkaBroker.class));
        } catch (BeansException b) {
            log.debug("Broker not configured yet. Unable to provide {}", name);
        }
        return value;
    }
}
