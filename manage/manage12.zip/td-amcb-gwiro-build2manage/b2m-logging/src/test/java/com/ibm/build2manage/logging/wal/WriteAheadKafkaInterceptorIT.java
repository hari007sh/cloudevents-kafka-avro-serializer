package com.ibm.build2manage.logging.wal;

import com.ibm.build2manage.kafka.*;
import com.ibm.build2manage.logging.LoggingAutoConfiguration;
import com.ibm.build2manage.logging.LoggingContextKafkaInterceptor;
import com.ibm.build2manage.logging.LoggingSession;
import org.junit.jupiter.api.Test;
import org.mockito.InOrder;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.kafka.config.ConcurrentKafkaListenerContainerFactory;
import org.springframework.kafka.config.KafkaListenerEndpointRegistry;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.listener.CompositeRecordInterceptor;

import javax.annotation.PostConstruct;
import java.util.UUID;
import java.util.concurrent.TimeUnit;

@KafkaTest
@SpringBootTest(classes = LoggingAutoConfiguration.class, properties = {
        "spring.kafka.consumer.auto-offset-reset=earliest"
})
class WriteAheadKafkaInterceptorIT {

    @MockBean
    private LoggingSession session;

    @MockBean
    private LogEventCache cache;

    @Autowired
    private LoggingContextKafkaInterceptor loggingContext;

    @Autowired
    private WriteAheadKafkaInterceptor underTest;

    @Autowired
    private KafkaListenerEndpointRegistry registry;

    @Autowired
    private KafkaTemplate<Object, Object> kafka;

    @Autowired
    private ConcurrentKafkaListenerContainerFactory<Object, Object> factory;

    @PostConstruct
    public void initInterceptor() {
        factory.setRecordInterceptor(new CompositeRecordInterceptor<>(loggingContext, underTest));
    }

    @Test
    void noException() {
        String id = UUID.randomUUID().toString();
        PublishSpecification.given("WriteAheadKafkaInterceptorIT-noException")
                .header("requestId", id)
                .send(kafka)
                .then(registry, factory)
                .waitAtMost(10, TimeUnit.SECONDS);
        Mockito.verify(session).initSession(id);

        InOrder inOrder = Mockito.inOrder(session, cache);
        // Assert that we cleared the session
        inOrder.verify(cache, Mockito.atLeastOnce()).getAll();
        inOrder.verify(session, Mockito.atLeastOnce()).clear();
    }

    @Test
    void withException() {
        String id = UUID.randomUUID().toString();
        PublishSpecification.given("WriteAheadKafkaInterceptorIT-exception")
                .header("requestId", id)
                .send(kafka)
                .onEvent(r -> {
                    throw new RuntimeException("test");
                })
                .then(registry, factory)
                .waitAtMost(10, TimeUnit.SECONDS);
        Mockito.verify(session).initSession(id);

        InOrder inOrder = Mockito.inOrder(session, cache);
        // Assert that we cleared the session
        inOrder.verify(cache, Mockito.atLeastOnce()).logAll();
        inOrder.verify(session, Mockito.atLeastOnce()).clear();
    }
}
