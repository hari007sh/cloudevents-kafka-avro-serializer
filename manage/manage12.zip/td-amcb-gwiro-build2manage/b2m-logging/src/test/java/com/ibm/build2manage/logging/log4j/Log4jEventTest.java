package com.ibm.build2manage.logging.log4j;

import org.apache.logging.log4j.Level;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.logging.log4j.Marker;
import org.junit.jupiter.api.Test;

import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;

class Log4jEventTest {

    // We test only the behavior when the method cannot be called.

    private static final Object[] PARAMS = new Object[]{"LogEventCacheTest Message1", "LogEventCacheTest Message2"};

    private static final Logger LOG = LogManager.getLogger();

    @Test
    void notAccessibleShouldThrowIllegalStateException() throws NoSuchMethodException {
        Method m = Log4jEventTest.class.getDeclaredMethod("wrongParams", Object.class, Object.class);
        Log4jEvent event = new Log4jEvent((org.apache.logging.log4j.core.Logger) LOG, Level.INFO, null, m, PARAMS);
        assertThrows(IllegalStateException.class, event::log);
    }

    @Test
    void throwingExceptionShouldWrapIntoIllegalStateException() throws NoSuchMethodException {
        Method m = Log4jEventTest.class.getDeclaredMethod("throwingException", org.apache.logging.log4j.core.Logger.class, Level.class, Marker.class);
        Log4jEvent event = new Log4jEvent((org.apache.logging.log4j.core.Logger) LOG, Level.INFO, null, m);
        assertThrows(IllegalStateException.class, event::log);
    }

    @Test
    void wrongParamsShouldThrowIllegalArgumentException() throws NoSuchMethodException {
        Method m = Log4jEventTest.class.getDeclaredMethod("wrongParams", Object.class, Object.class);
        m.setAccessible(true);
        Log4jEvent event = new Log4jEvent((org.apache.logging.log4j.core.Logger) LOG, Level.INFO, null, m, PARAMS);
        assertThrows(IllegalArgumentException.class, event::log);
    }

    private void wrongParams(Object o1, Object o2) {
        assertSame(PARAMS[0], o1);
        assertSame(PARAMS[1], o2);
    }

    private void throwingException(org.apache.logging.log4j.core.Logger logger, Level level, Marker marker) {
        throw new RuntimeException();
    }

}