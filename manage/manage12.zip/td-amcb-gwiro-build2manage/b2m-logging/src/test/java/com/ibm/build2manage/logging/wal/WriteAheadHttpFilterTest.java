package com.ibm.build2manage.logging.wal;

import com.ibm.build2manage.IntegerInterval;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

import static org.junit.jupiter.api.Assertions.*;

@ExtendWith(MockitoExtension.class)
class WriteAheadHttpFilterTest {

    @Mock
    private LogEventCache cache;

    @Mock
    private HttpServletRequest request;

    @Mock
    private HttpServletResponse response;

    @Mock
    private FilterChain chain;

    @Mock
    private IntegerInterval range;

    @InjectMocks
    private WriteAheadHttpFilter underTest;

    @ParameterizedTest
    @ValueSource(classes = {RuntimeException.class, IOException.class, ServletException.class})
    void shouldFlushCacheAndRethrow(Class<? extends Exception> ex) throws IOException, ServletException {
        Mockito.doThrow(ex).when(chain).doFilter(request, response);
        assertThrows(ex, () -> underTest.doFilterInternal(request, response, chain));
        Mockito.verify(cache).logAll();
    }

    @Test
    void shouldClearCacheWhenNotInRange() throws ServletException, IOException {
        Mockito.when(response.getStatus()).thenReturn(200);
        Mockito.when(range.contains(200)).thenReturn(false);
        underTest.doFilterInternal(request, response, chain);
        Mockito.verify(cache).clear();
    }

    @Test
    void shouldLogCacheWhenInRange() throws ServletException, IOException {
        Mockito.when(response.getStatus()).thenReturn(500);
        Mockito.when(range.contains(500)).thenReturn(true);
        underTest.doFilterInternal(request, response, chain);
        Mockito.verify(cache).logAll();
    }
}