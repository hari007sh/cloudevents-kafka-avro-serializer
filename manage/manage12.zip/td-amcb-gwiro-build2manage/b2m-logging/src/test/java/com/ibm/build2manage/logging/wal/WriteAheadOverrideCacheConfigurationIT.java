package com.ibm.build2manage.logging.wal;

import com.ibm.build2manage.logging.LoggingAutoConfiguration;
import org.junit.jupiter.api.Test;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;

import static org.junit.jupiter.api.Assertions.assertSame;

@EnableAutoConfiguration
@SpringBootTest(classes = LoggingAutoConfiguration.class, properties = {
        "spring.application.name=WriteAheadOverrideCacheConfigurationIT",
        "b2m-logging.wal.current=false"
})
class WriteAheadOverrideCacheConfigurationIT extends AbstractWriteAheadConfigurationIT {

    @MockBean
    private LogEventCache cache;

    @Test
    void shouldHaveLoggingCache() {
        LogEventCache c = assertBean(LogEventCache.class, cache.getClass());
        assertSame(cache, c);
    }

}
