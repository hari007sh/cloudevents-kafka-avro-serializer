package com.ibm.build2manage.logging.wal;

import com.ibm.build2manage.logging.LoggingContextHttpFilter;
import com.ibm.build2manage.logging.LoggingAutoConfiguration;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.annotation.DirtiesContext;

import javax.servlet.Filter;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertTrue;


@EnableAutoConfiguration
@SpringBootTest(classes = LoggingAutoConfiguration.class, properties = "spring.application.name=WriteAheadHttpFilterIT")
class WriteAheadHttpFilterIT {

    @Autowired
    private LoggingContextHttpFilter httpFilter;

    @Autowired
    private WriteAheadHttpFilter underTest;

    @Autowired
    private List<Filter> filters;

    @Test
    void wireAheadFilterShouldExecuteAfterLoggingFilter() {
        assertTrue(filters.contains(httpFilter));
        assertTrue(filters.contains(underTest));
        assertTrue(filters.indexOf(httpFilter) < filters.indexOf(underTest));
    }

}
