package com.ibm.build2manage.logging.log4j;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.commons.io.IOUtils;
import org.apache.logging.log4j.core.appender.ConsoleAppender;
import org.apache.logging.log4j.core.appender.SocketAppender;
import org.hamcrest.BaseMatcher;
import org.hamcrest.Description;
import org.hamcrest.Matchers;
import org.hamcrest.TypeSafeMatcher;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Disabled;
import org.junitpioneer.jupiter.SetEnvironmentVariable;

import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Arrays;
import java.util.Map;
import java.util.UUID;
import java.util.logging.Level;

import static org.junit.jupiter.api.Assertions.assertEquals;


/**
 * Manual test to make sure the Console only configuration works. This test cannot be run with other runs but should be
 * executed when the configuration changes.
 */
@Disabled
@SetEnvironmentVariable(key = "APPLICATION", value = "build2manage-unit")
@SetEnvironmentVariable(key = "HOSTNAME", value = "b2m-host")
public class DataDogLoggingTest extends AbstractLoggingTest {

    private static final ObjectMapper MAPPER = new ObjectMapper();

    private final String key = UUID.randomUUID().toString();

    private final ByteArrayOutputStream received = new ByteArrayOutputStream();
    private ServerSocket server;

    @BeforeEach
    void init() throws IOException {
        server = new ServerSocket(0);
        Thread t = new Thread(this::listen);
        t.start();
        System.setProperty("logging.datadog.apiKey", key);
        System.setProperty("logging.datadog.hostname", "localhost");
        System.setProperty("logging.datadog.port", String.valueOf(server.getLocalPort()));
        assertAppender("Out", ConsoleAppender.class);
        assertAppender("DataDog", SocketAppender.class);
    }

    private void listen() {
        try (Socket client = server.accept()) {
            InputStream in = client.getInputStream();
            int i = 0;
            byte[] bytes = new byte[1024];
            while ((i = in.read(bytes)) != -1) {
                received.write(bytes, 0, i);
                Arrays.fill(bytes, (byte) 0);
            }
            in.close();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    protected void assertMessage(String name, Level level, String expected) throws IOException {
        // Stop listening to make sure we have no more records
        server.close();
        assertLineMatches(new ByteArrayInputStream(console.toByteArray()), Matchers.endsWith(String.format("[%-5s] %s", level, expected)));
        assertLineMatches(new ByteArrayInputStream(received.toByteArray()), new TypeSafeMatcher<String>() {

            @Override
            protected boolean matchesSafely(String item) {
                if (item.startsWith(key + " ")) {
                    try {
                        JsonNode tree = MAPPER.readTree(item.substring(key.length() + 1));
                        return tree.get("message").asText().equals(expected)
                                && tree.get("service").asText().equals("build2manage-unit")
                                && tree.get("hostname").asText().equals("b2m-host")
                                ;
                    } catch (JsonProcessingException e) {
                        throw new RuntimeException(e);
                    }
                }
                return false;
            }

            @Override
            public void describeTo(Description description) {

            }
        });
    }

}
