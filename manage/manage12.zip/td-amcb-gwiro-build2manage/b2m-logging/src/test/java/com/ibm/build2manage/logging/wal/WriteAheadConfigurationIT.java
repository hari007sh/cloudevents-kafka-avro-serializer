package com.ibm.build2manage.logging.wal;

import com.ibm.build2manage.logging.LoggingAutoConfiguration;
import com.ibm.build2manage.logging.wal.caches.SimpleEventCache;
import org.junit.jupiter.api.Test;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.test.context.SpringBootTest;

@EnableAutoConfiguration
@SpringBootTest(classes = LoggingAutoConfiguration.class, properties =
        {
                "spring.application.name=WriteAheadConfigurationIT"
        })
class WriteAheadConfigurationIT extends AbstractWriteAheadConfigurationIT {

    @Test
    void shouldHaveLoggingCache() {
        assertBean(LogEventCache.class, SimpleEventCache.class);
    }

}
