package com.ibm.build2manage.logging.log4j;

import org.apache.logging.log4j.Level;

class Filter12Test extends WriteAheadFilterTest {

    @Override
    void log(int i, Level level) {
        LOG[i].log(level, MARKER[i], level.name() + i, T[i]);
    }

    @Override
    void logWithBuilder(int i, Level level) {
        LOG[i].atLevel(level).withMarker(MARKER[i]).withThrowable(T[i]).log(level.name() + i);
    }

    @Override
    void assertEvent(int i, Level level) {
        assertEvent(LOG[i], level, MARKER[i], level.name() + i, T[i]);
    }

}
