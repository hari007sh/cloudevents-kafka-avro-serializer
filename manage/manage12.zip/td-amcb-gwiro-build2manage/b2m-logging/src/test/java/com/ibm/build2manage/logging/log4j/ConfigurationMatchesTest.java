package com.ibm.build2manage.logging.log4j;

import org.apache.commons.io.IOUtils;
import org.junit.jupiter.api.Test;

import java.io.IOException;
import java.nio.charset.Charset;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class ConfigurationMatchesTest {

    @Test
    void configsMatch() throws IOException {
        assertEquals(IOUtils.toString(ConfigurationMatchesTest.class.getResourceAsStream("/log4j2-spring.xml"), Charset.defaultCharset()),
                IOUtils.toString(ConfigurationMatchesTest.class.getResourceAsStream("/log4j2.xml"), Charset.defaultCharset()));
    }

}
