package com.ibm.build2manage.logging.wal.caches;

import com.ibm.build2manage.logging.LoggingSession;
import com.ibm.build2manage.logging.wal.LogEvent;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.NullSource;
import org.junit.jupiter.params.provider.ValueSource;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.UUID;

import static java.util.Arrays.asList;
import static java.util.Collections.*;
import static org.junit.jupiter.api.Assertions.*;

@ExtendWith(MockitoExtension.class)
class SimpleEventCacheTest {

    private final String id = UUID.randomUUID().toString();

    @Mock
    private LoggingSession session;

    @Mock
    private LogEvent event1;

    @Mock
    private LogEvent event2;

    @InjectMocks
    private SimpleEventCache underTest;

    @ParameterizedTest
    @ValueSource(strings = "myId")
    @NullSource
    void verifyEmptyCache(String id) {
        Mockito.when(session.getId()).thenReturn(id);
        assertEquals(0, underTest.count());
        assertSame(emptyList(), underTest.getAll());
    }

    @Test
    void verifyOneElementCache() {
        Mockito.when(session.getIdOrCreate()).thenReturn(id);
        Mockito.when(session.getId()).thenReturn(id);
        underTest.add(event1);
        assertEquals(1, underTest.count());
        assertEquals(singletonList(event1), underTest.getAll());
    }

    @Test
    void verifyTwoElementsCached() {
        Mockito.when(session.getIdOrCreate()).thenReturn(id);
        Mockito.when(session.getId()).thenReturn(id);
        underTest.add(event1);
        underTest.add(event2);
        assertEquals(2, underTest.count());
        assertEquals(asList(event1, event2), underTest.getAll());
    }

    @Test
    void verifyClearedAfterGetAll() {
        Mockito.when(session.getIdOrCreate()).thenReturn(id);
        Mockito.when(session.getId()).thenReturn(id);
        underTest.add(event1);
        assertEquals(1, underTest.count());
        assertEquals(singletonList(event1), underTest.getAll());
        assertEquals(0, underTest.count());
        assertSame(emptyList(), underTest.getAll());
    }

    @Test
    void verifyReusableAfterGetAll() {
        Mockito.when(session.getIdOrCreate()).thenReturn(id);
        Mockito.when(session.getId()).thenReturn(id);
        underTest.add(event1);
        assertEquals(1, underTest.count());
        assertEquals(singletonList(event1), underTest.getAll());
        underTest.add(event2);
        assertEquals(1, underTest.count());
        assertEquals(singletonList(event2), underTest.getAll());
    }

}