package com.ibm.build2manage.logging.log4j;

import com.ibm.build2manage.ReplicatingOutputStream;
import lombok.RequiredArgsConstructor;
import org.apache.commons.io.IOUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.core.*;
import org.apache.logging.log4j.core.filter.Filterable;
import org.hamcrest.Matcher;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import java.io.*;
import java.nio.charset.Charset;
import java.util.*;
import java.util.logging.Level;

import static org.junit.jupiter.api.Assertions.*;

@RequiredArgsConstructor
public abstract class AbstractLoggingTest {

    private final Map<String, Class<? extends Appender>> appenders = new HashMap<>();

    protected final ByteArrayOutputStream console = new ByteArrayOutputStream();

    public <T extends Appender & Filterable> void assertAppender(String name, Class<T> tClass) {
        appenders.put(name, tClass);
    }

    protected abstract void assertMessage(String appenderName, Level level, String expected) throws IOException;

    @Test
    void doTest() throws IOException {
        String message = UUID.randomUUID().toString();
        PrintStream actual = hijackConsole();
        try {
            // We declare the logger here to allow tests to initialize the environment
            // Before the Log4j2 context is loaded
            Logger underTest = (Logger) LogManager.getLogger();
            for (Map.Entry<String, Class<? extends Appender>> appender : appenders.entrySet()) {
                assertInstanceOf(appender.getValue(), underTest.getAppenders().get(appender.getKey()), "Appender " + appender);
            }
            underTest.info(message);
        } finally {
            System.setOut(actual);
        }
        // We validate after to prevent adding junk to what we are testing
        for (String name : appenders.keySet()) {
            assertMessage(name, Level.INFO, message);
        }
    }

    private PrintStream hijackConsole() {
        PrintStream actual = System.out;
        System.setOut(new PrintStream(new ReplicatingOutputStream(console, actual)));
        return actual;
    }

    protected void assertLineMatches(InputStream stream, Matcher<String> matcher) throws IOException {
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(stream))) {
            for (String str = reader.readLine(); str != null; str = reader.readLine()) {
                if (matcher.matches(str)) {
                    return;
                }
            }
            Assertions.fail(IOUtils.toString(stream, Charset.defaultCharset()) + " did not match " + matcher.toString());
        }
    }
}
