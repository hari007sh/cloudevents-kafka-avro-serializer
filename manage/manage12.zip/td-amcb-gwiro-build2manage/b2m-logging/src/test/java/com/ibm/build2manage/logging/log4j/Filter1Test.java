package com.ibm.build2manage.logging.log4j;

import org.apache.logging.log4j.Level;

class Filter1Test extends WriteAheadFilterTest {

    @Override
    void log(int i, Level level) {
        LOG[i].log(level, MARKER[i], level.name() + i + ": {} {} {} {} {} {} {} {} {} {} {}", "p0" + i, "p1" + i, "p2" + i, "p3" + i, "p4" + i, "p5" + i, "p6" + i, "p7" + i, "p8" + i, "p9" + i, "extra" + i);
    }

    @Override
    void logWithBuilder(int i, Level level) {
        LOG[i].atLevel(level).withMarker(MARKER[i]).log(level.name() + i + ": {} {} {} {} {} {} {} {} {} {} {}", "p0" + i, "p1" + i, "p2" + i, "p3" + i, "p4" + i, "p5" + i, "p6" + i, "p7" + i, "p8" + i, "p9" + i, "extra" + i);
    }

    @Override
    void assertEvent(int i, Level level) {
        assertEvent(LOG[i], level, MARKER[i], level.name() + i + ": p0" + i + " p1" + i + " p2" + i + " p3" + i + " p4" + i + " p5" + i + " p6" + i + " p7" + i + " p8" + i + " p9" + i + " extra" + i);
    }

}
