package com.ibm.build2manage.logging.log4j;

import com.ibm.build2manage.logging.LoggingSession;
import com.ibm.build2manage.logging.wal.caches.SimpleEventCache;
import org.apache.logging.log4j.Level;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Marker;
import org.apache.logging.log4j.core.Appender;
import org.apache.logging.log4j.core.LogEvent;
import org.apache.logging.log4j.core.Logger;
import org.apache.logging.log4j.core.LoggerContext;
import org.junit.jupiter.api.*;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.MethodSource;
import org.junit.jupiter.params.provider.ValueSource;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.opentest4j.AssertionFailedError;

import java.util.ArrayList;
import java.util.List;

import static java.util.Collections.singletonList;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;

@ExtendWith(MockitoExtension.class)
abstract class WriteAheadFilterTest {

    private static final String ROOT_LOGGER = "unit.writeahead";

    private static final LoggingSession SESSION = new Log4jLoggingSession("unit.test");
    private static final SimpleEventCache CACHE = new SimpleEventCache(SESSION);
    private static final WriteAheadFilter UNDER_TEST = new WriteAheadFilter(CACHE, singletonList("unit.writeahead"));

    // We create 3 bogus logger in a root logger so we are not impacted by other tests
    protected static final Logger[] LOG = {
            (Logger) LogManager.getLogger(ROOT_LOGGER + ".log4j.Class"),
            (Logger) LogManager.getLogger(ROOT_LOGGER + ".OtherClass"),
            (Logger) LogManager.getLogger("other")
    };

    protected static final Throwable[] T = {
            new Throwable(),
            new Throwable(),
            new Throwable()
    };

    protected static final Marker[] MARKER = {
            Mockito.mock(Marker.class),
            Mockito.mock(Marker.class),
            Mockito.mock(Marker.class)
    };

    @Mock
    protected Appender appender;

    private final List<LogEvent> events = new ArrayList<>();

    @BeforeAll
    static void initLoggers() {
        LoggerContext context = (LoggerContext) LogManager.getContext(false);
        context.getConfiguration().addFilter(UNDER_TEST);
        for (Logger l : LOG) {
            l.addFilter(UNDER_TEST);
        }
    }

    @AfterAll
    static void removeFilter() {
        LoggerContext context = (LoggerContext) LogManager.getContext(false);
        context.getConfiguration().removeFilter(UNDER_TEST);
    }

    @BeforeEach
    void addAppender() {
        Mockito.when(appender.getName()).thenReturn("mock");
        Mockito.lenient().when(appender.isStarted()).thenReturn(true);
        Mockito.lenient().doAnswer(i -> {
            events.add(i.getArgument(0, LogEvent.class).toImmutable());
            return null;
        }).when(appender).append(any());
        for (Logger l : LOG) {
            l.addAppender(appender);
        }
    }

    @AfterEach
    void removeAppender() {
        for (Logger l : LOG) {
            l.removeAppender(appender);
            l.setLevel(Level.INFO);
        }
        CACHE.clear();
        SESSION.clear();
        assertTrue(events.isEmpty(), "Events left at end of test: " + events);
    }

    static Object[][] cached() {
        return new Object[][]{
                {Level.TRACE},
                {Level.DEBUG}
        };
    }

    static Object[][] notCached() {
        return new Object[][]{
                {Level.INFO},
                {Level.WARN},
        };
    }

    static Object[][] triggersFlush() {
        return new Object[][]{
                {Level.ERROR},
                {Level.FATAL}
        };
    }

    protected void assertEvent(Logger log, Level level, Marker marker, String formattedMessage) {
        assertEvent(log, level, marker, formattedMessage, null);
    }

    protected void assertEvent(Logger log, Level level, Marker marker, String formattedMessage, Throwable t) {
        assertFalse(events.isEmpty(), "Missing expected message");
        LogEvent event = events.remove(0);
        assertEquals(log.getName(), event.getLoggerName());
        assertEquals(level, event.getLevel());
        assertEquals(formattedMessage, event.getMessage().getFormattedMessage());
        assertEquals(t, event.getThrown());
        assertEquals(marker, event.getMarker());
    }

    protected void assertCached(int expected) {
        if (expected != CACHE.count()) {
            throw new AssertionFailedError("Invalid cache", expected, CACHE.getAll().toString());
        }
    }

    abstract void log(int i, Level level);

    abstract void logWithBuilder(int i, Level level);

    abstract void assertEvent(int i, Level level);

    @ParameterizedTest
    @MethodSource({"cached", "notCached", "triggersFlush"})
    void shouldIgnoreFilter(Level level) {
        // Make sure we have a session going and cache is available
        SESSION.getIdOrCreate();
        assertTrue(CACHE.isAvailable(), "Cache is not available before test");
        LOG[2].setLevel(Level.ALL);
        log(2, level);
        assertCached(0);
        assertEvent(2, level);
    }

    @ParameterizedTest
    @MethodSource({"cached", "notCached", "triggersFlush"})
    void shouldIgnoreFilterWithBuilder(Level level) {
        // Make sure we have a session going and cache is available
        SESSION.getIdOrCreate();
        assertTrue(CACHE.isAvailable(), "Cache is not available before test");
        LOG[2].setLevel(Level.ALL);
        logWithBuilder(2, level);
        assertCached(0);
        assertEvent(2, level);
    }

    @ParameterizedTest
    @MethodSource("cached")
    void shouldCacheEvent(Level level) {
        // Make sure we have a session going and cache is available
        SESSION.getIdOrCreate();
        assertTrue(CACHE.isAvailable(), "Cache is not available before test");
        log(0, level);
        log(1, level);
        log(2, level);
        assertCached(2);
    }

    @ParameterizedTest
    @MethodSource("cached")
    void shouldCacheEventWithBuilder(Level level) {
        // Make sure we have a session going and cache is available
        SESSION.getIdOrCreate();
        assertTrue(CACHE.isAvailable(), "Cache is not available before test");
        logWithBuilder(0, level);
        logWithBuilder(1, level);
        logWithBuilder(2, level);
        assertCached(2);
    }

    @ParameterizedTest
    @MethodSource("cached")
    void shouldNotCacheEventWithoutSession(Level level) {
        assertFalse(CACHE.isAvailable(), "Cache is not disabled");
        log(0, level);
        log(1, level);
        log(2, level);
        assertCached(0);
    }

    @ParameterizedTest
    @MethodSource("cached")
    void shouldNotCacheEventWithoutSessionWithBuilder(Level level) {
        assertFalse(CACHE.isAvailable(), "Cache is not disabled");
        logWithBuilder(0, level);
        logWithBuilder(1, level);
        logWithBuilder(2, level);
        assertCached(0);
    }

    @ParameterizedTest
    @MethodSource({"notCached", "triggersFlush"})
    void shouldNotCacheEvent(Level level) {
        // Make sure we have a session going and cache is available
        SESSION.getIdOrCreate();
        assertTrue(CACHE.isAvailable(), "Cache is not available before test");
        log(0, level);
        log(1, level);
        log(2, level);
        assertCached(0);
        assertEvent(0, level);
        assertEvent(1, level);
        assertEvent(2, level);
    }

    @ParameterizedTest
    @MethodSource({"notCached", "triggersFlush"})
    void shouldNotCacheEventWithBuilder(Level level) {
        // Make sure we have a session going and cache is available
        SESSION.getIdOrCreate();
        assertTrue(CACHE.isAvailable(), "Cache is not available before test");
        logWithBuilder(0, level);
        logWithBuilder(1, level);
        logWithBuilder(2, level);
        assertCached(0);
        assertEvent(0, level);
        assertEvent(1, level);
        assertEvent(2, level);
    }

    @ParameterizedTest
    @MethodSource("triggersFlush")
    void shouldFlushCache(Level level) {
        // Make sure we have a session going and cache is available
        SESSION.getIdOrCreate();
        assertTrue(CACHE.isAvailable(), "Cache is not available before test");
        log(0, Level.TRACE);
        assertCached(1);
        log(0, level);
        assertCached(0);
        assertEvent(0, Level.TRACE);
        assertEvent(0, level);
    }

    @ParameterizedTest
    @MethodSource("triggersFlush")
    void shouldFlushCacheWithBuilder(Level level) {
        // Make sure we have a session going and cache is available
        SESSION.getIdOrCreate();
        assertTrue(CACHE.isAvailable(), "Cache is not available before test");
        logWithBuilder(0, Level.TRACE);
        assertCached(1);
        logWithBuilder(0, level);
        assertCached(0);
        assertEvent(0, Level.TRACE);
        assertEvent(0, level);
    }
}