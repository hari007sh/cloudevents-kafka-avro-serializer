package com.ibm.build2manage.logging.wal;

import com.ibm.build2manage.logging.LoggingSession;
import com.ibm.build2manage.logging.log4j.Log4jCleaner;
import com.ibm.build2manage.logging.log4j.Log4jLoggingSession;
import com.ibm.build2manage.logging.log4j.WriteAheadFilter;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.core.Filter;
import org.apache.logging.log4j.core.Logger;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.test.annotation.DirtiesContext;

import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;


abstract class AbstractWriteAheadConfigurationIT {

    @Autowired
    protected ApplicationContext context;

    protected <I, T extends I> T assertBean(Class<I> iface, Class<T> impl) {
        Map<String, ?> beans = context.getBeansOfType(iface);
        assertEquals(1, beans.size());
        Object b = beans.values().iterator().next();
        assertEquals(impl, b.getClass());
        return impl.cast(b);
    }

    @Test
    void shouldFindLog4jSession() {
        assertBean(LoggingSession.class, Log4jLoggingSession.class);
    }

    @Test
    void filterShouldBeConfigured() {
        WriteAheadFilter f = assertBean(Filter.class, WriteAheadFilter.class);
        Logger l = (Logger) LogManager.getLogger();
        Filter actual = l.getContext().getConfiguration().getFilter();
        assertSame(f, actual);

        Log4jCleaner c = assertBean(Cleaner.class, Log4jCleaner.class);
        assertTrue(c.contains(f));
    }
}
