package com.ibm.build2manage.logging;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.annotation.DirtiesContext;

import javax.servlet.Filter;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;


@EnableAutoConfiguration
@SpringBootTest(classes = LoggingAutoConfiguration.class, properties = "spring.application.name=LoggingContextHttpFilterIT")
class LoggingContextHttpFilterIT {

    @Autowired
    private LoggingContextHttpFilter httpFilter;

    @Autowired
    private List<Filter> filters;

    @Test
    void loggingFilterShouldExecuteFirst() {
        assertEquals(0, filters.indexOf(httpFilter));
    }

}
