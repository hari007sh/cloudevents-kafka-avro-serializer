package com.ibm.build2manage.logging.log4j;

import org.apache.logging.log4j.Level;

class Filter6Test extends WriteAheadFilterTest {

    @Override
    void log(int i, Level level) {
        LOG[i].log(level, MARKER[i], level.name() + i + ": {} {} {} {} {}", "p0" +i, "p1" + i, "p2" + i, "p3" + i, "p4" + i);
    }

    @Override
    void logWithBuilder(int i, Level level) {
        LOG[i].atLevel(level).withMarker(MARKER[i]).log(level.name() + i + ": {} {} {} {} {}", "p0" +i, "p1" + i, "p2" + i, "p3" + i, "p4" + i);
    }

    @Override
    void assertEvent(int i, Level level) {
        assertEvent(LOG[i], level, MARKER[i], level.name() + i + ": p0" +i + " p1" + i + " p2" + i + " p3" + i + " p4" + i);
    }

}
