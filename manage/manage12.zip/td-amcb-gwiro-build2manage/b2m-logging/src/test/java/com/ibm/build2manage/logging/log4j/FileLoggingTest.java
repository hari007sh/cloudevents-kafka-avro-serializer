package com.ibm.build2manage.logging.log4j;

import org.apache.logging.log4j.core.appender.ConsoleAppender;
import org.apache.logging.log4j.core.appender.RollingFileAppender;
import org.hamcrest.Matchers;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Disabled;

import java.io.*;
import java.util.logging.Level;

/**
 * Manual test to make sure the Console only configuration works. This test cannot be run with other runs but should be
 * executed when the configuration changes.
 */
@Disabled
public class FileLoggingTest extends AbstractLoggingTest {

    @BeforeEach
    void init() {
        System.setProperty("logging.file", "target/tmp.log");
        assertAppender("Out", ConsoleAppender.class);
        assertAppender("File", RollingFileAppender.class);
    }

    @Override
    protected void assertMessage(String name, Level level, String expected) throws IOException {
        assertLineMatches(new ByteArrayInputStream(console.toByteArray()), Matchers.endsWith(String.format("[%-5s] %s", level, expected)));
        assertLineMatches(new FileInputStream("target/tmp.log"), Matchers.endsWith(String.format("[%-5s] %s", level, expected)));
    }
}
