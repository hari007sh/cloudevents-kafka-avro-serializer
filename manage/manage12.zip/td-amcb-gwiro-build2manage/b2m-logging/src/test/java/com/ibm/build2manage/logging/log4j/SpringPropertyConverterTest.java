package com.ibm.build2manage.logging.log4j;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.MethodSource;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.core.env.Environment;

import java.util.UUID;

import static org.junit.jupiter.api.Assertions.*;

@ExtendWith(MockitoExtension.class)
class SpringPropertyConverterTest {

    private final String key = UUID.randomUUID().toString();
    private final String value = UUID.randomUUID().toString();

    private final StringBuilder sb = new StringBuilder();

    @Mock
    private Environment env;

    static Object[][] shouldProvideOneKey() {
        return new Object[][]{
                {null},
                {new String[0]},
                {new String[]{"one", "two"}}
        };
    }

    @ParameterizedTest
    @MethodSource
    void shouldProvideOneKey(String[] options) {
        IllegalArgumentException ex = assertThrows(IllegalArgumentException.class, () -> SpringPropertyConverter.newInstance(options));
        assertEquals("One (1) property name must be provided", ex.getMessage());
    }

    @AfterEach
    void removeEnvironment() {
        SpringPropertyConverter.setEnvironment(null);
    }

    @Test
    void noEnvironmentReturnsUndefined() {
        SpringPropertyConverter underTest = SpringPropertyConverter.newInstance(key);
        underTest.format(null, sb);
        assertEquals("undefined", sb.toString());
    }

    @Test
    void nullPropertyReturnsUndefined() {
        SpringPropertyConverter underTest = SpringPropertyConverter.newInstance(key);
        SpringPropertyConverter.setEnvironment(env);
        underTest.format(null, sb);
        assertEquals("undefined", sb.toString());
    }

    @Test
    void keyStartingWithDotShouldPrependSpring() {
        SpringPropertyConverter underTest = SpringPropertyConverter.newInstance('.' + key);
        SpringPropertyConverter.setEnvironment(env);
        Mockito.when(env.getProperty("spring." + key)).thenReturn(value);
        underTest.format(null, sb);
        assertEquals(value, sb.toString());
    }

    @Test
    void keyShouldReturnValue() {
        SpringPropertyConverter underTest = SpringPropertyConverter.newInstance(key);
        SpringPropertyConverter.setEnvironment(env);
        Mockito.when(env.getProperty(key)).thenReturn(value);
        underTest.format(null, sb);
        assertEquals(value, sb.toString());
    }
}