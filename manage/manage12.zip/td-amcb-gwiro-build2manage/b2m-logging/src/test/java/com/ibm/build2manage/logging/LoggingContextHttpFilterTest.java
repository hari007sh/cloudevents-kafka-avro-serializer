package com.ibm.build2manage.logging;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.assertThrows;

@ExtendWith(MockitoExtension.class)
class LoggingContextHttpFilterTest {

    private final String header = UUID.randomUUID().toString();

    @Mock
    private HttpServletRequest request;

    @Mock
    private HttpServletResponse response;

    @Mock
    private FilterChain chain;

    @Mock
    private LoggingSession session;

    private LoggingContextHttpFilter underTest;

    @BeforeEach
    void init() {
        String headerName = UUID.randomUUID().toString();
        underTest = new LoggingContextHttpFilter(session, headerName);
        Mockito.when(request.getHeader(headerName)).thenReturn(header);
    }

    @ParameterizedTest
    @ValueSource(classes = {RuntimeException.class, IOException.class, ServletException.class})
    void shouldClearSessionRethrow(Class<? extends Exception> ex) throws IOException, ServletException, NoSuchMethodException, IllegalAccessException, InvocationTargetException, InstantiationException {
        Exception expected = ex.getDeclaredConstructor().newInstance();
        Mockito.doAnswer(i -> {
            Mockito.verify(session).initSession(header);
            throw expected;
        }).when(chain).doFilter(request, response);
        assertThrows(ex, () -> underTest.doFilterInternal(request, response, chain));
        Mockito.verify(session).clear();
    }

    @Test
    void shouldClearSessionOnSuccess() throws ServletException, IOException {
        underTest.doFilterInternal(request, response, chain);
        Mockito.verify(session).clear();
    }
}