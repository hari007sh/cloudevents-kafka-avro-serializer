package com.ibm.build2manage.logging.log4j;

import org.apache.logging.log4j.core.LogEvent;
import org.apache.logging.log4j.core.config.plugins.Plugin;
import org.apache.logging.log4j.core.pattern.ConverterKeys;
import org.apache.logging.log4j.core.pattern.LogEventPatternConverter;
import org.springframework.core.env.Environment;

import java.util.Objects;

/**
 * {@link LogEventPatternConverter} that allow retrieving spring properties using either %s or %spring. The converter
 * requires one property name in options. If logging occurs before the spring framework is done loading, or if the
 * property does not exists, this converter will <code>undefined</code>.
 */
@Plugin(name = "spring", category = "Converter")
@ConverterKeys({"s", "spring"})
public class SpringPropertyConverter extends LogEventPatternConverter {

    private static final String UNDEFINED = "undefined";
    private static Environment springEnv;
    private final String key;

    /**
     * Log4J plugin factory method.
     *
     * @param options the converter options
     *
     * @return the converter
     */
    public static SpringPropertyConverter newInstance(String... options) {
        return new SpringPropertyConverter(options);
    }

    /**
     * Constructor.
     *
     * @param options the property name to return
     */
    private SpringPropertyConverter(String[] options) {
        super("appName", null);
        if (options == null || options.length != 1) {
            throw new IllegalArgumentException("One (1) property name must be provided");
        }
        // Allow not specifying spring twice
        if (options[0].charAt(0) == '.') {
            this.key = "spring" + options[0];
        } else {
            this.key = options[0];
        }
    }

    /**
     * Method to set the spring environment once loaded.
     *
     * @param environment the spring environment
     */
    static void setEnvironment(Environment environment) {
        springEnv = environment;
    }

    @Override
    public void format(LogEvent event, StringBuilder toAppendTo) {
        if (springEnv == null) {
            toAppendTo.append(UNDEFINED);
        } else {
            toAppendTo.append(Objects.requireNonNullElse(springEnv.getProperty(key), UNDEFINED));
        }
    }
}
