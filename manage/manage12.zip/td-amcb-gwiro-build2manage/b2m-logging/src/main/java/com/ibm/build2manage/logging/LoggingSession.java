package com.ibm.build2manage.logging;

import org.slf4j.MDC;
import org.springframework.lang.NonNull;

/**
 * a {@link LoggingSession} is used to interface with the logging framework to store and retrieve information about the
 * logging session. It was decided not to depends on {@link MDC} for two reasons:
 * <ol>
 *     <li>The implementation can implements logic using features provided with the logging framework, even if they don't support MDC</li>
 *     <li>This allows the application using this framework to implements it's own way of managing the logging session if they wish to</li>
 * </ol>
 */
public interface LoggingSession {

    /**
     * @return the current session id or null if the framework does not have a session yet
     */
    String getId();

    /**
     * Look for the current session id within the logging framework. If none exists, create one.
     *
     * @return the session id
     */
    @NonNull
    String getIdOrCreate();

    /**
     * Set the current session id within the logging framework. If the id provided is null, generate a new session id.
     *
     * @param id the value of the session
     *
     * @throws IllegalStateException if the session id already exists
     */
    void initSession(String id) throws IllegalStateException;

    /**
     * Clear the current session from the logging framework.
     */
    void clear();

    /**
     * Set a session property.
     *
     * @param key the name of the session property
     * @param value the value of the session property
     */
    void set(String key, String value);
}
