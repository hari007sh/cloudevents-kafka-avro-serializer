package com.ibm.build2manage.logging.wal;

import com.ibm.build2manage.IntegerInterval;
import com.ibm.build2manage.logging.LoggingConfiguration;
import lombok.RequiredArgsConstructor;
import org.springframework.boot.web.servlet.filter.OrderedFilter;
import org.springframework.lang.NonNull;
import org.springframework.web.filter.OncePerRequestFilter;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * Implementation of {@link Filter} that assure the write ahead cache is cleaned once an HTTP request execution is
 * completed. If the execution completed with an error, this will flush the cache in the logs.
 */
@RequiredArgsConstructor
public class WriteAheadHttpFilter extends OncePerRequestFilter implements OrderedFilter {

    private final LogEventCache cache;

    private final IntegerInterval flushRange;

    @Override
    protected void doFilterInternal(@NonNull HttpServletRequest request, @NonNull HttpServletResponse response, @NonNull FilterChain filterChain) throws ServletException, IOException {
        try {
            filterChain.doFilter(request, response);
            // If the response status is within range, make sure the cache is flushed
            // if it was not already. Otherwise, we cleanup
            if (flushRange.contains(response.getStatus())) {
                cache.logAll();
            } else {
                cache.clear();
            }
        } catch (RuntimeException | IOException | ServletException e) {
            // Make sure the write-ahead cache is logged before forwarding an error.
            cache.logAll();
            // Rethrow the exception
            throw e;
        }
    }

    @Override
    public int getOrder() {
        return LoggingConfiguration.BASE_ORDER + 1;
    }
}
