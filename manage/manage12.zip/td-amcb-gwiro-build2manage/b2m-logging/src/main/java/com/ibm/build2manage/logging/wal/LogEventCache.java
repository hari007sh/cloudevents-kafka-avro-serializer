package com.ibm.build2manage.logging.wal;

import java.util.List;

/**
 * Cache used to store {@link LogEvent}.
 */
public interface LogEventCache {

    /**
     * Add an event to the cache.
     *
     * @param event the event to add
     */
    void add(LogEvent event);

    /**
     * Return the amount of cached logging elements for the current session.
     *
     * @return the amount of cached event logging
     */
    int count();

    /**
     * Retrieves all cached events for the current logging session.
     *
     * @return the list of cached events for the session.
     */
    List<LogEvent> getAll();

    /**
     * Triggers a log for every element contained in the cache.
     */
    default void logAll() {
        for (LogEvent event : getAll()) {
            event.log();
        }
    }

    /**
     * Clear the cached events for the current logging session.
     */
    default void clear() {
        // In most cases, clear is simply a getAll ignoring the return
        getAll();
    }

    /**
     * A cache is available if there is a unique identifier for the current logging session and that we are able to
     * store the events.
     *
     * @return true if the cache is available.
     */
    boolean isAvailable();
}
