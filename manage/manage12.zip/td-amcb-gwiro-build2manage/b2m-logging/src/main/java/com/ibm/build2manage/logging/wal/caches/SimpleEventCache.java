package com.ibm.build2manage.logging.wal.caches;

import com.ibm.build2manage.logging.LoggingSession;
import com.ibm.build2manage.logging.wal.LogEvent;
import com.ibm.build2manage.logging.wal.LogEventCache;
import lombok.RequiredArgsConstructor;

import java.util.*;

/**
 * Simple implementation of {@link LogEventCache} using a Map to store the cached element. This {@link LogEventCache}
 * does not supports any sort of automated cleanup or resource usage restriction. This could lead to issues in
 * production.
 */
@RequiredArgsConstructor
public class SimpleEventCache implements LogEventCache {

    private final Map<String, List<LogEvent>> cached = new HashMap<>();

    protected final LoggingSession session;

    @Override
    public void add(LogEvent event) {
        cached.computeIfAbsent(session.getIdOrCreate(), e -> new ArrayList<>()).add(event);
    }

    @Override
    public int count() {
        String key = this.session.getId();
        if (key != null && cached.containsKey(key)) {
            return cached.get(key).size();
        }
        return 0;
    }

    @Override
    public List<LogEvent> getAll() {
        String key = this.session.getId();
        if (key != null && cached.containsKey(key)) {
            return cached.remove(key);
        }
        return Collections.emptyList();
    }

    @Override
    public boolean isAvailable() {
        return session.getId() != null;
    }
}
