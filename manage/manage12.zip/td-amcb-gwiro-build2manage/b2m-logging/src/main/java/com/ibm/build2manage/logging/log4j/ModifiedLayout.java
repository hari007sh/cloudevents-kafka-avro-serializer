package com.ibm.build2manage.logging.log4j;

import org.apache.logging.log4j.core.LogEvent;
import org.apache.logging.log4j.core.StringLayout;
import org.apache.logging.log4j.core.config.plugins.Plugin;
import org.apache.logging.log4j.core.config.plugins.PluginBuilderAttribute;
import org.apache.logging.log4j.core.config.plugins.PluginBuilderFactory;
import org.apache.logging.log4j.core.config.plugins.PluginElement;
import org.apache.logging.log4j.core.layout.AbstractStringLayout;

import java.nio.charset.Charset;

@Plugin(
        name = "ModifiedLayout",
        category = "Core",
        elementType = "layout"
)
public class ModifiedLayout extends AbstractStringLayout {

    private final StringLayout delegate;
    private final ModificationStrategy strategy;

    protected ModifiedLayout(Charset charset, final StringLayout delegate, final ModificationStrategy strategy) {
        super(charset);
        this.delegate = delegate;
        this.strategy = strategy;
    }

    @Override
    public String toSerializable(LogEvent event) {
        if (strategy == null) {
            return delegate.toSerializable(event);
        }
        return strategy.apply(delegate.toSerializable(event));
    }

    /**
     * Creates a builder for a custom ModifiedLayout.
     *
     * @return a ModifiedLayout builder.
     */
    @PluginBuilderFactory
    public static Builder newBuilder() {
        return new Builder();
    }

    public static class Builder implements org.apache.logging.log4j.core.util.Builder<ModifiedLayout> {

        @PluginBuilderAttribute
        private Charset charset = Charset.defaultCharset();
        @PluginElement("Layout")
        private StringLayout layout;

        @PluginElement("Modification")
        private ModificationStrategy modification;

        /**
         * @param charset The character set. The platform default is used if not specified.
         */
        public Builder withCharset(final Charset charset) {
            // LOG4J2-783 if null, use platform default by default
            if (charset != null) {
                this.charset = charset;
            }
            return this;
        }

        /**
         * @param layout The StringLayout. Required
         */
        public Builder withLayout(final StringLayout layout) {
            this.layout = layout;
            return this;
        }

        /**
         * @param modification The ModificationStrategy. Defaults to identity.
         */
        public Builder withModification(final ModificationStrategy modification) {
            this.modification = modification;
            return this;
        }

        @Override
        public ModifiedLayout build() {
            return new ModifiedLayout(charset, layout, modification);
        }
    }

    public interface ModificationStrategy {

        String apply(String event);
    }
}
