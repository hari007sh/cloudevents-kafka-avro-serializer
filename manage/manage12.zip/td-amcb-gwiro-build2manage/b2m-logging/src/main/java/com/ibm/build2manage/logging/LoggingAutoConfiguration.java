package com.ibm.build2manage.logging;

import com.ibm.build2manage.logging.log4j.Log4jLoggingSession;
import org.apache.logging.log4j.ThreadContext;
import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.kafka.listener.RecordInterceptor;

import javax.servlet.Filter;

@Configuration(proxyBeanMethods = false)
@EnableConfigurationProperties(LoggingConfiguration.class)
@PropertySource("classpath:logging.properties")
public class LoggingAutoConfiguration {

    // Must be here to allow LogEventCache from being discovered
    @Bean
    @ConditionalOnClass(ThreadContext.class)
    @ConditionalOnMissingBean(LoggingSession.class)
    public LoggingSession log4jSession(LoggingConfiguration config) {
        return new Log4jLoggingSession(config.getIdKey());
    }

}
