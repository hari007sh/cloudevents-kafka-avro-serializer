package com.ibm.build2manage.logging;

import lombok.RequiredArgsConstructor;
import org.springframework.boot.web.servlet.filter.OrderedFilter;
import org.springframework.lang.NonNull;
import org.springframework.web.filter.OncePerRequestFilter;

import javax.servlet.*;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

import static com.ibm.build2manage.logging.LoggingConfiguration.BASE_ORDER;

/**
 * Implementation of {@link Filter} that makes sure the relevant information is loaded to the logging Context when an
 * HTTP request is received. Once a request is completed, the logging context is cleared.
 */
@RequiredArgsConstructor
public class LoggingContextHttpFilter extends OncePerRequestFilter implements OrderedFilter {

    private final LoggingSession session;

    private final String headerName;

    @Override
    protected void doFilterInternal(HttpServletRequest req, @NonNull HttpServletResponse res, FilterChain filterChain) throws ServletException, IOException {
        session.initSession(req.getHeader(headerName));
        try {
            filterChain.doFilter(req, res);
        } finally {
            session.clear();
        }
    }

    @Override
    public int getOrder() {
        return BASE_ORDER;
    }
}
