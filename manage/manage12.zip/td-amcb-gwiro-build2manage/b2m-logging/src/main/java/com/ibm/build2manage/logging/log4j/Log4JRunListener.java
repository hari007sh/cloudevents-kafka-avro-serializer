package com.ibm.build2manage.logging.log4j;

import org.springframework.boot.ConfigurableBootstrapContext;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.SpringApplicationRunListener;
import org.springframework.core.env.ConfigurableEnvironment;

/**
 * Implementation of SpringApplicationRunListener that is forwarding the spring environment to the {@link
 * SpringPropertyConverter} once the environment is prepared. This allows to make the log4j plugin aware of the spring
 * environment.
 */
public class Log4JRunListener implements SpringApplicationRunListener {

    /**
     * Constructor required by the spring framework.
     *
     * @param app the spring application
     * @param args the command line arguments
     */
    public Log4JRunListener(SpringApplication app, String[] args) {
        // Ignored but required by spring framework
    }

    @Override
    public void environmentPrepared(ConfigurableBootstrapContext bootstrapContext, ConfigurableEnvironment environment) {
        SpringPropertyConverter.setEnvironment(environment);
    }
}
