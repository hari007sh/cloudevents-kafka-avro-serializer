package com.ibm.build2manage.logging.wal;

import org.springframework.boot.autoconfigure.condition.ConditionalOnBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.filter.OncePerRequestFilter;

import javax.servlet.Filter;

@Configuration
@ConditionalOnClass(OncePerRequestFilter.class)
public class WebWriteAheadAutoConfiguration {

    @Bean
    @ConditionalOnBean(LogEventCache.class)
    public Filter walHttpFilter(LogEventCache cache, WriteAheadConfiguration config) {
        return new WriteAheadHttpFilter(cache, config.getFlushRange());
    }
}
