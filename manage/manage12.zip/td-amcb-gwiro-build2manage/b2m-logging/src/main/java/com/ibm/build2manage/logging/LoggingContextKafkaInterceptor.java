package com.ibm.build2manage.logging;

import lombok.RequiredArgsConstructor;
import org.apache.kafka.clients.consumer.Consumer;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.common.header.Header;
import org.springframework.core.Ordered;
import org.springframework.kafka.listener.RecordInterceptor;
import org.springframework.lang.NonNull;

import java.util.Iterator;

/**
 * Implementation of {@link RecordInterceptor} that makes sure the relevant information is loaded to the logging Context
 * when a Kafka event is received. Once the request is processed, the logging context is cleared.
 */
@RequiredArgsConstructor
public class LoggingContextKafkaInterceptor implements RecordInterceptor<Object, Object>, Ordered {

    private final LoggingSession session;

    private final String headerName;

    @Override
    public ConsumerRecord<Object, Object> intercept(@NonNull ConsumerRecord<Object, Object> rec) {
        Iterator<Header> i = rec.headers().headers(headerName).iterator();
        session.initSession(i.hasNext() ? new String(i.next().value()) : null);
        return rec;
    }

    @Override
    public void afterRecord(@NonNull ConsumerRecord<Object, Object> rec, @NonNull Consumer<Object, Object> consumer) {
        session.clear();
    }

    @Override
    public int getOrder() {
        return LoggingConfiguration.BASE_ORDER;
    }
}