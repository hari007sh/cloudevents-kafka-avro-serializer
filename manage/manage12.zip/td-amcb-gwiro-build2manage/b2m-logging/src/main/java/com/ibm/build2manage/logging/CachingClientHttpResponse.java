package com.ibm.build2manage.logging;

import com.ibm.build2manage.CachingInputStream;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.client.ClientHttpResponse;
import org.springframework.lang.NonNull;

import java.io.IOException;

@RequiredArgsConstructor
public class CachingClientHttpResponse implements ClientHttpResponse {

    private final ClientHttpResponse response;

    private final int max;
    private CachingInputStream in;


    @NonNull
    @Override
    public HttpStatus getStatusCode() throws IOException {
        return this.response.getStatusCode();
    }

    @Override
    public int getRawStatusCode() throws IOException {
        return this.response.getRawStatusCode();
    }

    @NonNull
    @Override
    public String getStatusText() throws IOException {
        return this.response.getStatusText();
    }

    @NonNull
    @Override
    public HttpHeaders getHeaders() {
        return this.response.getHeaders();
    }

    @NonNull
    @Override
    public CachingInputStream getBody() throws IOException {
        if (in == null) {
            in = new CachingInputStream(response.getBody(), max);
        }
        return in;
    }

    /**
     * @return the buffered body as String. If {@link #getBody()} was not called before, this will return null
     */
    public byte[] fillAndGet() throws IOException {
        return getBody().fillAndGet();
    }

    @Override
    public void close() {
        this.response.close();
    }

}
