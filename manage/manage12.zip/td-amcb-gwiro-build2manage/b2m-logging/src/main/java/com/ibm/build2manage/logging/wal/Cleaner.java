package com.ibm.build2manage.logging.wal;

import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.DisposableBean;

import java.util.List;

/**
 * Abstraction that is executed when the spring context is destroyed to make sure we cleanup the spring related beans
 * from the logging framework.
 *
 * @param <T> the type of bean we are unregistering
 */
@RequiredArgsConstructor
public abstract class Cleaner<T> implements DisposableBean {

    private final List<T> beans;

    /**
     * Determines if a bean is registered for cleanup.
     *
     * @param bean the bean
     *
     * @return true if the bean is registered for cleanup
     */
    public boolean contains(T bean) {
        return beans.contains(bean);
    }

    /**
     * Unregister a bean from the logging framework.
     *
     * @param bean the bean to unregister
     */
    protected abstract void unregister(T bean);

    @Override
    public void destroy() {
        for (T bean : beans) {
            unregister(bean);
        }
    }

}
