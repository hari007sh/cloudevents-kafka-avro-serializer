package com.ibm.build2manage.logging;

import com.ibm.build2manage.logging.wal.LogEventCache;
import com.ibm.build2manage.logging.wal.WriteAheadKafkaInterceptor;
import org.springframework.boot.autoconfigure.condition.ConditionalOnBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.listener.RecordInterceptor;


//DefaultKafkaConsumerFactoryCustomizer for Kafka AutoConfiguration
// ListenerContainerCustomizer


@Configuration
@ConditionalOnClass(RecordInterceptor.class)
public class KafkaLoggingAutoConfiguration {

    @Bean
    public LoggingContextKafkaInterceptor loggingInterceptor(LoggingSession session, LoggingConfiguration config) {
        return new LoggingContextKafkaInterceptor(session, config.getHeaderName());
    }


    @Bean
    @ConditionalOnBean(LogEventCache.class)
    public WriteAheadKafkaInterceptor walInterceptor(LogEventCache cache) {
        return new WriteAheadKafkaInterceptor(cache);
    }

}
