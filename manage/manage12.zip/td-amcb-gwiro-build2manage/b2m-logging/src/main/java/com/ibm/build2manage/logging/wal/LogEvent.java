package com.ibm.build2manage.logging.wal;

/**
 * Instance that can trigger a logging event.
 */
public interface LogEvent {

    /**
     * Inform the event that it should log itself with the logging library.
     */
    void log();

}
