package com.ibm.build2manage.logging.log4j;

import com.ibm.build2manage.logging.wal.LogEventCache;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;
import org.apache.logging.log4j.Level;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Marker;
import org.apache.logging.log4j.core.LogEvent;
import org.apache.logging.log4j.core.Logger;
import org.apache.logging.log4j.core.filter.AbstractFilter;
import org.apache.logging.log4j.internal.DefaultLogBuilder;
import org.apache.logging.log4j.message.Message;
import org.apache.logging.log4j.spi.AbstractLogger;

import java.lang.reflect.Method;
import java.util.List;

/**
 * Filter that uses a {@link LogEventCache} to store any logging event that would otherwise be dropped. When a critical
 * event occurs, the cache is flushed to allow troubleshooting of the issue.
 */
@RequiredArgsConstructor
public class WriteAheadFilter extends AbstractFilter {

    private final LogEventCache cache;

    private final List<String> loggerNames;

    @Getter
    @Setter
    private Level cachingLevel = Level.ALL;

    @Getter
    @Setter
    private Level flushCacheLevel = Level.ERROR;

    private static Method getMethod(String name, Class<?>... params) {
        try {
            Method m = AbstractLogger.class.getDeclaredMethod(name, params);
            m.setAccessible(true);
            return m;
        } catch (NoSuchMethodException e) {
            throw new IllegalStateException("Unable to initialize Write Ahead Filter", e);
        }
    }

    /**
     * On reception of a filter event, determines if the cache should be flushed and if the current logging event should
     * be cached.
     *
     * @param logger the logger used for logging
     * @param level  the level of logging
     * @return true if log event should be cached
     */
    private boolean onLogEvent(Logger logger, Level level) {
        // We do not log or do anything when level is not provided
        if (level == null || logger == null || !cache.isAvailable() || !cachingEnabled(logger)) {
            return false;
        }
        if (level.isMoreSpecificThan(flushCacheLevel)) {
            cache.logAll();
        }
        return level.isMoreSpecificThan(cachingLevel) && !logger.getLevel().isLessSpecificThan(level);
    }

    private boolean cachingEnabled(Logger logger) {
        for (String s : loggerNames) {
            if (logger.getName().startsWith(s)) {
                return true;
            }
        }
        return false;
    }

    private static final String LOG_MESSAGE = "logMessage";
    private static final Method LOG1 = getMethod(LOG_MESSAGE, String.class, Level.class, Marker.class, String.class, Object[].class);

    /**
     * @see AbstractLogger#logIfEnabled(String, Level, Marker, String, Object...)
     */
    @Override
    public Result filter(Logger logger, Level level, Marker marker, String msg, Object... params) {
        if (onLogEvent(logger, level)) {
            cache.add(new Log4jEvent(logger, level, marker, LOG1, msg, params));
            return getOnMismatch();
        }
        return getOnMatch();
    }

    private static final Method LOG2 = getMethod(LOG_MESSAGE, String.class, Level.class, Marker.class, String.class, Object.class);

    /**
     * @see AbstractLogger#logIfEnabled(String, Level, Marker, String, Object)
     */
    @Override
    public Result filter(Logger logger, Level level, Marker marker, String message, Object p0) {
        if (onLogEvent(logger, level)) {
            cache.add(new Log4jEvent(logger, level, marker, LOG2, message, p0));
            return getOnMismatch();
        }
        return getOnMatch();
    }

    private static final Method LOG3 = getMethod(LOG_MESSAGE, String.class, Level.class, Marker.class, String.class, Object.class, Object.class);

    /**
     * @see AbstractLogger#logIfEnabled(String, Level, Marker, String, Object, Object)
     */
    @Override
    public Result filter(Logger logger, Level level, Marker marker, String message, Object p0, Object p1) {
        if (onLogEvent(logger, level)) {
            cache.add(new Log4jEvent(logger, level, marker, LOG3, message, p0, p1));
            return getOnMismatch();
        }
        return getOnMatch();
    }

    private static final Method LOG4 = getMethod(LOG_MESSAGE, String.class, Level.class, Marker.class, String.class, Object.class, Object.class, Object.class);

    /**
     * @see AbstractLogger#logIfEnabled(String, Level, Marker, String, Object, Object, Object)
     */
    @Override
    public Result filter(Logger logger, Level level, Marker marker, String message, Object p0, Object p1, Object p2) {
        if (onLogEvent(logger, level)) {
            cache.add(new Log4jEvent(logger, level, marker, LOG4, message, p0, p1, p2));
            return getOnMismatch();
        }
        return getOnMatch();
    }

    private static final Method LOG5 = getMethod(LOG_MESSAGE, String.class, Level.class, Marker.class, String.class, Object.class, Object.class, Object.class, Object.class);

    /**
     * @see AbstractLogger#logIfEnabled(String, Level, Marker, String, Object, Object, Object, Object)
     */
    @Override
    public Result filter(Logger logger, Level level, Marker marker, String message, Object p0, Object p1, Object p2, Object p3) {
        if (onLogEvent(logger, level)) {
            cache.add(new Log4jEvent(logger, level, marker, LOG5, message, p0, p1, p2, p3));
            return getOnMismatch();
        }
        return getOnMatch();
    }

    private static final Method LOG6 = getMethod(LOG_MESSAGE, String.class, Level.class, Marker.class, String.class, Object.class, Object.class, Object.class, Object.class, Object.class);

    /**
     * @see AbstractLogger#logIfEnabled(String, Level, Marker, String, Object, Object, Object, Object, Object)
     */
    @Override
    public Result filter(Logger logger, Level level, Marker marker, String message, Object p0, Object p1, Object p2, Object p3, Object p4) {
        if (onLogEvent(logger, level)) {
            cache.add(new Log4jEvent(logger, level, marker, LOG6, message, p0, p1, p2, p3, p4));
            return getOnMismatch();
        }
        return getOnMatch();
    }

    private static final Method LOG7 = getMethod(LOG_MESSAGE, String.class, Level.class, Marker.class, String.class, Object.class, Object.class, Object.class, Object.class, Object.class, Object.class);

    /**
     * @see AbstractLogger#logIfEnabled(String, Level, Marker, String, Object, Object, Object, Object, Object, Object)
     */
    @Override
    public Result filter(Logger logger, Level level, Marker marker, String message, Object p0, Object p1, Object p2, Object p3, Object p4, Object p5) {
        if (onLogEvent(logger, level)) {
            cache.add(new Log4jEvent(logger, level, marker, LOG7, message, p0, p1, p2, p3, p4, p5));
            return getOnMismatch();
        }
        return getOnMatch();
    }

    private static final Method LOG8 = getMethod(LOG_MESSAGE, String.class, Level.class, Marker.class, String.class, Object.class, Object.class, Object.class, Object.class, Object.class, Object.class, Object.class);

    /**
     * @see AbstractLogger#logIfEnabled(String, Level, Marker, String, Object, Object, Object, Object, Object, Object,
     * Object)
     */
    @Override
    public Result filter(Logger logger, Level level, Marker marker, String message, Object p0, Object p1, Object p2, Object p3, Object p4, Object p5, Object p6) {
        if (onLogEvent(logger, level)) {
            cache.add(new Log4jEvent(logger, level, marker, LOG8, message, p0, p1, p2, p3, p4, p5, p6));
            return getOnMismatch();
        }
        return getOnMatch();
    }

    private static final Method LOG9 = getMethod(LOG_MESSAGE, String.class, Level.class, Marker.class, String.class, Object.class, Object.class, Object.class, Object.class, Object.class, Object.class, Object.class, Object.class);

    /**
     * @see AbstractLogger#logIfEnabled(String, Level, Marker, String, Object, Object, Object, Object, Object, Object,
     * Object, Object)
     */
    @Override
    public Result filter(Logger logger, Level level, Marker marker, String message, Object p0, Object p1, Object p2, Object p3, Object p4, Object p5, Object p6, Object p7) {
        if (onLogEvent(logger, level)) {
            cache.add(new Log4jEvent(logger, level, marker, LOG9, message, p0, p1, p2, p3, p4, p5, p6, p7));
            return getOnMismatch();
        }
        return getOnMatch();
    }

    private static final Method LOG10 = getMethod(LOG_MESSAGE, String.class, Level.class, Marker.class, String.class, Object.class, Object.class, Object.class, Object.class, Object.class, Object.class, Object.class, Object.class, Object.class);

    /**
     * @see AbstractLogger#logIfEnabled(String, Level, Marker, String, Object, Object, Object, Object, Object, Object,
     * Object, Object, Object)
     */
    @Override
    public Result filter(Logger logger, Level level, Marker marker, String message, Object p0, Object p1, Object p2, Object p3, Object p4, Object p5, Object p6, Object p7, Object p8) {
        if (onLogEvent(logger, level)) {
            cache.add(new Log4jEvent(logger, level, marker, LOG10, message, p0, p1, p2, p3, p4, p5, p6, p7, p8));
            return getOnMismatch();
        }
        return getOnMatch();
    }

    private static final Method LOG11 = getMethod(LOG_MESSAGE, String.class, Level.class, Marker.class, String.class, Object.class, Object.class, Object.class, Object.class, Object.class, Object.class, Object.class, Object.class, Object.class, Object.class);

    /**
     * @see AbstractLogger#logIfEnabled(String, Level, Marker, String, Object, Object, Object, Object, Object, Object,
     * Object, Object, Object, Object)
     */
    @Override
    public Result filter(Logger logger, Level level, Marker marker, String message, Object p0, Object p1, Object p2, Object p3, Object p4, Object p5, Object p6, Object p7, Object p8, Object p9) {
        if (onLogEvent(logger, level)) {
            cache.add(new Log4jEvent(logger, level, marker, LOG11, message, p0, p1, p2, p3, p4, p5, p6, p7, p8, p9));
            return getOnMismatch();
        }
        return getOnMatch();
    }

    private static final Method LOG12 = getMethod(LOG_MESSAGE, String.class, Level.class, Marker.class, String.class, Throwable.class);

    /**
     * @see AbstractLogger#logIfEnabled(String, Level, Marker, String, Throwable)
     */
    @Override
    public Result filter(Logger logger, Level level, Marker marker, Object msg, Throwable t) {
        // The null check allows us to detect if we are called using Logger.atLevel(level)
        // When using the LogBuilder, there is an isEnabled check before creating the actual LogEvent.
        // As such, we have to make sure that we don't cache the even at the moment, nor do we block
        // This means we accept everything if the cache is enabled, or return the logic to the logger if
        // cache is not available
        if (marker == null && msg == null && t == null) {
            return cachingEnabled(logger) && cache.isAvailable() ? Result.ACCEPT : Result.NEUTRAL;
        }
        if (onLogEvent(logger, level)) {
            cache.add(new Log4jEvent(logger, level, marker, LOG12, msg, t));
            return getOnMismatch();
        }
        return getOnMatch();
    }

    private static final Method LOG13 = getMethod("logMessageSafely", String.class, Level.class, Marker.class, Message.class, Throwable.class);

    /**
     * @see AbstractLogger#logIfEnabled(String, Level, Marker, Message, Throwable)
     */
    @Override
    public Result filter(Logger logger, Level level, Marker marker, Message msg, Throwable t) {
        if (onLogEvent(logger, level)) {
            cache.add(new Log4jEvent(logger, level, marker, LOG13, msg, t));
            return getOnMismatch();
        }
        return getOnMatch();
    }

    @Override
    public Result filter(LogEvent event) {
        // When using logger.atLevel(level), we reach this point through the DefaultLogBuilder.
        // But we have to be cautious as we will reach this method too when doing the cache flushing.
        if (DefaultLogBuilder.class.getName().equals(event.getLoggerFqcn())) {
            return filter((Logger) LogManager.getLogger(event.getLoggerName()), event.getLevel(), event.getMarker(), event.getMessage(), event.getThrown());
        }
        return super.filter(event);
    }
}
