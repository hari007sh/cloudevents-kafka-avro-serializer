package com.ibm.build2manage.logging.log4j;

import com.ibm.build2manage.logging.wal.WriteAheadAutoConfiguration;
import com.ibm.build2manage.logging.wal.LogEventCache;
import com.ibm.build2manage.logging.wal.WriteAheadConfiguration;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.ThreadContext;
import org.apache.logging.log4j.core.Filter;
import org.apache.logging.log4j.core.Logger;
import org.apache.logging.log4j.core.LoggerContext;
import org.springframework.boot.autoconfigure.AutoConfigureAfter;
import org.springframework.boot.autoconfigure.condition.ConditionalOnBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.ArrayList;
import java.util.List;

@Configuration
@ConditionalOnClass(ThreadContext.class)
@AutoConfigureAfter(WriteAheadAutoConfiguration.class)
public class Log4JAutoConfiguration {

    @Bean
    @ConditionalOnBean(LogEventCache.class)
    public Filter log4jWriteAheadFilter(LogEventCache cache, WriteAheadConfiguration config) {
        WriteAheadFilter filter = new WriteAheadFilter(cache, new ArrayList<>(config.getLoggers()));
        LoggerContext ctx = (LoggerContext) LogManager.getContext(config.isCurrent());
        ctx.getConfiguration().addFilter(filter);
        ctx.getConfiguration().getLoggers().values().forEach(l-> l.addFilter(filter));
        ctx.updateLoggers();
        return filter;
    }

    @Bean
    @ConditionalOnBean(Filter.class)
    public Log4jCleaner log4jCleaner(List<Filter> filters) {
        return new Log4jCleaner(filters);
    }
}
