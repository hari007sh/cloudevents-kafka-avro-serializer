package com.ibm.build2manage.logging;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.ConstructorBinding;
import org.springframework.core.Ordered;

/**
 * Configuration for the logging module.
 */
@ConstructorBinding
@ConfigurationProperties(prefix = LoggingConfiguration.NAME)
@Data
public class LoggingConfiguration {

    public static final String NAME = "b2m-logging";
    public static final int BASE_ORDER = Ordered.HIGHEST_PRECEDENCE;

    /**
     * Logging context key containing the request id.
     */
    private final String idKey;
    /**
     * Incoming request headers to retrieve the request id from.
     */
    private final String headerName;
    /**
     * Specify how many bytes from the response from remote system should we log.
     */
    private final int logResponseSize;
}
