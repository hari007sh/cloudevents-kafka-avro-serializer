package com.ibm.build2manage.logging.log4j;

import com.ibm.build2manage.logging.wal.Cleaner;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.core.Filter;
import org.apache.logging.log4j.core.LoggerContext;
import org.apache.logging.log4j.core.config.Configuration;

import java.util.List;

/**
 * {@link Cleaner} implementation for Log4j.
 */
public class Log4jCleaner extends Cleaner<Filter> {

    /**
     * Constructor.
     *
     * @param filters the list of filters
     */
    public Log4jCleaner(List<Filter> filters) {
        super(filters);
    }

    @Override
    public void unregister(Filter bean) {
        Configuration config = ((LoggerContext) LogManager.getContext(false)).getConfiguration();
        config.removeFilter(bean);
    }
}
