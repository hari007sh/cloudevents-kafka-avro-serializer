package com.ibm.build2manage.logging.log4j;

import com.ibm.build2manage.logging.LoggingSession;
import lombok.RequiredArgsConstructor;
import org.apache.logging.log4j.ThreadContext;
import org.springframework.lang.NonNull;

import java.util.*;

/**
 * Implementation of {@link LoggingSession} for the log4j framework. The id is stored in the {@link ThreadContext}
 * which allow, through configuration, to use the same MDC key than the request id.
 */
@RequiredArgsConstructor
public class Log4jLoggingSession implements LoggingSession {

    private final String contextKey;

    @NonNull
    @Override
    public String getIdOrCreate() {
        if (!ThreadContext.containsKey(contextKey)) {
            ThreadContext.put(contextKey, UUID.randomUUID().toString());
        }
        return ThreadContext.get(contextKey);
    }

    @Override
    public void initSession(String id) throws IllegalStateException {
        if (ThreadContext.containsKey(contextKey)) {
            throw new IllegalStateException("Session id already defined for this session");
        }
        if (id == null) {
            id = UUID.randomUUID().toString();
        }
        ThreadContext.put(contextKey, id);
    }

    @Override
    public void clear() {
        ThreadContext.clearAll();
    }

    @Override
    public void set(String key, String value) {
        ThreadContext.put(key, value);
    }

    @Override
    public String getId() {
        return ThreadContext.get(contextKey);
    }
}
