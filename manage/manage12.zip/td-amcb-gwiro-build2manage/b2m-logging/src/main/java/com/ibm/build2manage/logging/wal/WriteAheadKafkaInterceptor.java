package com.ibm.build2manage.logging.wal;

import lombok.RequiredArgsConstructor;
import org.apache.kafka.clients.consumer.Consumer;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.springframework.core.Ordered;
import org.springframework.kafka.listener.RecordInterceptor;
import org.springframework.lang.NonNull;

import static com.ibm.build2manage.logging.LoggingConfiguration.BASE_ORDER;

/**
 * Implementation of {@link RecordInterceptor} that assure the write ahead cache is cleaned once a Kafka event is
 * processed. If the execution completed with an error, this will flush the cache in the logs.
 */
@RequiredArgsConstructor
public class WriteAheadKafkaInterceptor implements RecordInterceptor<Object, Object>, Ordered {

    private final LogEventCache cache;

    @Override
    public ConsumerRecord<Object, Object> intercept(@NonNull ConsumerRecord<Object, Object> rec) {
        return rec;
    }

    @Override
    public void success(@NonNull ConsumerRecord<Object, Object> rec, @NonNull Consumer<Object, Object> consumer) {
        cache.getAll();
    }

    @Override
    public void failure(@NonNull ConsumerRecord<Object, Object> rec, @NonNull Exception exception, Consumer<Object, Object> consumer) {
        cache.logAll();
    }

    @Override
    public int getOrder() {
        return BASE_ORDER + 1;
    }
}
