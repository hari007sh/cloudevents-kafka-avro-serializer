package com.ibm.build2manage.logging.log4j;

import lombok.RequiredArgsConstructor;
import org.apache.logging.log4j.core.config.plugins.Plugin;
import org.apache.logging.log4j.core.config.plugins.PluginBuilderAttribute;
import org.apache.logging.log4j.core.config.plugins.PluginBuilderFactory;

@Plugin(
        name = "Formatted",
        category = "Core",
        elementType = "modification"
)
@RequiredArgsConstructor
public class FormattingStrategy implements ModifiedLayout.ModificationStrategy {

    private final String format;

    @Override
    public String apply(String event) {
        return String.format(format, event);
    }

    /**
     * Creates a builder for a custom FormattingStrategy.
     *
     * @return a FormattingStrategy builder.
     */
    @PluginBuilderFactory
    public static Builder newBuilder() {
        return new Builder();
    }

    public static class Builder implements org.apache.logging.log4j.core.util.Builder<FormattingStrategy> {

        @PluginBuilderAttribute
        private String format = "%";

        /**
         * @param format the format. If Not specified, defaults to "%"
         */
        public Builder withFormat(String format) {
            this.format = format;
            return this;
        }

        @Override
        public FormattingStrategy build() {
            return new FormattingStrategy(format);
        }
    }
}
