package com.ibm.build2manage.logging.wal;

import com.ibm.build2manage.IntegerInterval;
import com.ibm.build2manage.logging.LoggingConfiguration;
import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.ConstructorBinding;

import java.util.List;

/**
 * Configuration for the write ahead logging module.
 */
@ConstructorBinding
@ConfigurationProperties(prefix = LoggingConfiguration.NAME + ".wal")
@Data
public class WriteAheadConfiguration {

    /**
     * List of prefix for loggers that are accepted for write-ahead caching.
     */
    private final List<String> loggers;

    /**
     * Range for the HTTP statuses triggering the flush of the Write-Ahead cache.
     */
    private final IntegerInterval flushRange;

    /**
     * True if configuring current log4j context.
     */
    private final boolean current;
}
