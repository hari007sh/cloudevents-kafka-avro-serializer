package com.ibm.build2manage.logging.log4j;

import lombok.AllArgsConstructor;
import org.apache.logging.log4j.core.config.Node;
import org.apache.logging.log4j.core.config.arbiters.Arbiter;
import org.apache.logging.log4j.core.config.arbiters.SystemPropertyArbiter;
import org.apache.logging.log4j.core.config.plugins.Plugin;
import org.apache.logging.log4j.core.config.plugins.PluginBuilderAttribute;
import org.apache.logging.log4j.core.config.plugins.PluginBuilderFactory;

/**
 * Log4J2 Arbiter that allows to put condition about an unspecified system property.
 */
@Plugin(name = "UnspecifiedSystemPropertyArbiter", category = Node.CATEGORY, elementType = Arbiter.ELEMENT_TYPE,
        deferChildren = true, printObject = true)
@AllArgsConstructor
public class UnspecifiedSystemPropertyArbiter implements Arbiter {

    private final String propertyName;

    /**
     * Returns true if the system property is null.
     */
    @Override
    public boolean isCondition() {
        return System.getProperty(propertyName) == null;
    }

    @PluginBuilderFactory
    public static UnspecifiedSystemPropertyArbiter.Builder newBuilder() {
        return new UnspecifiedSystemPropertyArbiter.Builder();
    }

    public static class Builder implements org.apache.logging.log4j.core.util.Builder<UnspecifiedSystemPropertyArbiter> {

        public static final String ATTR_PROPERTY_NAME = "propertyName";

        @PluginBuilderAttribute(ATTR_PROPERTY_NAME)
        private String propertyName;

        /**
         * Sets the Property Name.
         *
         * @param propertyName the property name.
         * @return this
         */
        public UnspecifiedSystemPropertyArbiter.Builder setPropertyName(final String propertyName) {
            this.propertyName = propertyName;
            return asBuilder();
        }

        public UnspecifiedSystemPropertyArbiter.Builder asBuilder() {
            return this;
        }

        public UnspecifiedSystemPropertyArbiter build() {
            return new UnspecifiedSystemPropertyArbiter(propertyName);
        }
    }
}
