package com.ibm.build2manage.logging.log4j;

import com.ibm.build2manage.logging.wal.LogEvent;
import lombok.ToString;
import org.apache.logging.log4j.Level;
import org.apache.logging.log4j.Marker;
import org.apache.logging.log4j.core.Logger;
import org.apache.logging.log4j.spi.AbstractLogger;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

/**
 * Implementation of {@link LogEvent} for the log4j logging framework.
 */
@ToString
class Log4jEvent implements LogEvent {

    // the FQCN is used to determine the caller class and method when location information needs to be logged
    // We use AbstractLogger to continue as if the filter returned ALLOW
    // See ExtendedLogger for more information
    private static final String FQCN = AbstractLogger.class.getName();
    private final Logger logger;
    private final Level level;
    private final Marker marker;
    private final Method method;
    private final Object[] params;

    /**
     * Constructor.
     *
     * @param logger the logger initiating the event
     * @param level the level of logging
     * @param marker the marker or null if no marker present
     * @param method the method to invoke to continue logging
     * @param otherParams other params to send to the provided method. Those params are appended to the level and marker
     */
    Log4jEvent(Logger logger, Level level, Marker marker, Method method, Object... otherParams) {
        this.logger = logger;
        this.level = level;
        this.marker = marker;
        this.method = method;
        this.params = otherParams;
    }

    @Override
    public void log() {
        Object[] tmp = new Object[params.length + 3];
        tmp[0] = FQCN;
        tmp[1] = level;
        tmp[2] = marker;
        System.arraycopy(params, 0, tmp, 3, params.length);
        try {
            method.invoke(logger, tmp);
        } catch (IllegalAccessException | InvocationTargetException e) {
            // We throw an IllegalStateException as this is a major flaw and means we
            // May not have tested the framework properly which would require a revert
            // if this occurs in production
            throw new IllegalStateException("Unable to flush log event", e);
        }
    }
}
