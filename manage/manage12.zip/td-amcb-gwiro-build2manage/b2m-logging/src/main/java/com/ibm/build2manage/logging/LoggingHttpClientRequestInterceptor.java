package com.ibm.build2manage.logging;

import lombok.RequiredArgsConstructor;
import lombok.extern.log4j.Log4j2;
import org.springframework.boot.web.client.RestTemplateCustomizer;
import org.springframework.http.HttpRequest;
import org.springframework.http.client.ClientHttpRequestExecution;
import org.springframework.http.client.ClientHttpRequestInterceptor;
import org.springframework.http.client.ClientHttpResponse;
import org.springframework.lang.NonNull;
import org.springframework.web.client.RestTemplate;

import java.io.IOException;
import java.nio.charset.StandardCharsets;

@Log4j2
@RequiredArgsConstructor
public class LoggingHttpClientRequestInterceptor implements ClientHttpRequestInterceptor, RestTemplateCustomizer {

    private final int logResponse;

    @NonNull
    @Override
    public ClientHttpResponse intercept(HttpRequest request, byte[] body, @NonNull ClientHttpRequestExecution execution) throws IOException {
        log.atDebug().log("Calling {} {}", request.getMethod(), request.getURI());
        if (body.length > 0) {
            // We use supplier to avoid creating the string if it's not required
            log.atTrace().log("Body content: {}", () -> new String(body, StandardCharsets.UTF_8));
        }
        ClientHttpResponse response = execution.execute(request, body);
        log.atDebug().log("Response {}", response.getStatusCode());
        if (logResponse >0) {
            if (response.getHeaders().getContentLength() > 0) {
                CachingClientHttpResponse actual = new CachingClientHttpResponse(response, logResponse);
                log.atTrace().log("Response body: {}", () -> {
                    try {
                        return new String(actual.fillAndGet(), StandardCharsets.UTF_8);
                    } catch (IOException e) {
                        return e.getMessage();
                    }
                });
                return actual;
            } else {
                log.atTrace().log("Empty response body");
            }
        } else {
            log.atTrace().log("Response body logging disabled");
        }
        return response;
    }

    @Override
    public void customize(RestTemplate restTemplate) {
        if (!restTemplate.getInterceptors().contains(this)) {
            restTemplate.getInterceptors().add(this);
        }
    }
}