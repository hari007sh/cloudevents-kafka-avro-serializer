package com.ibm.build2manage.resources.smb;

import com.hierynomus.smbj.share.File;
import lombok.extern.log4j.Log4j2;

import java.io.FilterOutputStream;
import java.io.IOException;

/**
 * Implementation of {@link java.io.OutputStream} used with {@link SmbResource} that make sure that we close the
 * underlying SMBJ {@link File}.
 */
@Log4j2
class SmbFileOutputStream extends FilterOutputStream {

    private final File file;

    /**
     * Constructor.
     *
     * @param file the smb file we are writing to
     */
    protected SmbFileOutputStream(File file) {
        super(file.getOutputStream());
        this.file = file;
    }

    @Override
    public void close() throws IOException {
        log.atDebug().log("Closing InputStream for {}", file);
        super.close();
        file.close();
    }
}
