package com.ibm.build2manage.resources.smb;

import lombok.Getter;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class SmbDescriptor {

    private static final Pattern SMB_URL_PATTERN = Pattern.compile("smb://(((([^\\\\]*)\\\\)?([^:]*):([^@]*)@)?([a-zA-Z0-9\\-\\.]*))/(.[^/]+)(/.*)?");

    private final Matcher m;
    private final String path;

    @Getter
    private final boolean folder;

    private String asString;

    private SmbDescriptor(Matcher m) {
        this(m, m.group(9));
    }

    private SmbDescriptor(Matcher m, String path) {
        this.m = m;
        this.path = path == null ? "" : path;
        folder = path == null || path.lastIndexOf('/') > path.lastIndexOf('.');
    }

    public static SmbDescriptor parse(String location) {
        Matcher m = SMB_URL_PATTERN.matcher(location);
        if (m.matches()) {
            return new SmbDescriptor(m);
        }
        return null;
    }

    // Only for internal use
    String sessionId() {
        // This will return the server and authentication part of the URL
        // Should be used only internally to SmbProtocolResolver
        return m.group(1);
    }

    // Only for internal use
    char[] password() {
        return m.group(6) == null ? new char[0] : m.group(6).toCharArray();
    }

    public String hostname() {
        return m.group(7);
    }

    public String username() {
        return m.group(5);
    }

    public String domain() {
        return m.group(4);
    }

    public String share() {
        return m.group(8);
    }

    public String path() {
        return path;
    }

    public SmbDescriptor relative(String relativePath) {
        if (!path.endsWith("/") && !relativePath.startsWith("/")) {
            return new SmbDescriptor(m, path + "/" + relativePath);
        } else if (path.endsWith("/") && relativePath.startsWith("/")) {
            return new SmbDescriptor(m, path + relativePath.substring(1));
        }
        return new SmbDescriptor(m, path + relativePath);
    }

    @Override
    public String toString() {
        if (asString == null) {
            StringBuilder sb = new StringBuilder("smb://");
            if (domain() != null) {
                sb.append(domain()).append('\\');
            }
            if (m.group(2) != null) {
                sb.append(m.group(5)).append(':').append("*****@");
            }
            asString = sb.append(hostname())
                    .append("/")
                    .append(share())
                    .append(path)
                    .toString();
        }
        return asString;
    }
}
