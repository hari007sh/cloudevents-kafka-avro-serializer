package com.ibm.build2manage.resources.smb;

import com.hierynomus.smbj.SMBClient;
import com.hierynomus.smbj.auth.AuthenticationContext;
import com.hierynomus.smbj.connection.Connection;
import com.hierynomus.smbj.session.Session;
import lombok.extern.log4j.Log4j2;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.SpringApplicationRunListener;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.core.io.ProtocolResolver;
import org.springframework.core.io.Resource;
import org.springframework.core.io.ResourceLoader;
import org.springframework.lang.NonNull;

import java.io.IOException;
import java.util.AbstractMap;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;

@Log4j2
public class SmbResourceManager implements ProtocolResolver, SpringApplicationRunListener, AutoCloseable {

    private final SMBClient client;


    private final Map<String, Map.Entry<Session, AtomicInteger>> sessions = new HashMap<>();

    /**
     * Constructor required by the spring framework.
     *
     * @param app  the spring application
     * @param args the command line arguments
     */
    public SmbResourceManager(SpringApplication app, String[] args) {
        this(new SMBClient());
    }

    public SmbResourceManager(SMBClient smbClient) {
        this.client = smbClient;
    }

    @Override
    public void contextPrepared(ConfigurableApplicationContext context) {
        context.addProtocolResolver(this);
    }

    @Override
    public Resource resolve(@NonNull String location, @NonNull ResourceLoader resourceLoader) {
        try {
            SmbDescriptor descriptor = SmbDescriptor.parse(location);
            if (descriptor != null) {
                return new SmbResource(this, descriptor);
            }
        } catch (IllegalArgumentException e) {
            log.error("Unable to parse SMB resource", e);
            throw e;
        }
        return null;
    }

    Session getSession(SmbDescriptor share) {
        log.atDebug().log("Retrieving session for {}",share);
        Map.Entry<Session, AtomicInteger> tmp = sessions.computeIfAbsent(share.sessionId(), k -> createSession(share));
        tmp.getValue().incrementAndGet();
        return tmp.getKey();
    }

    private Map.Entry<Session, AtomicInteger> createSession(SmbDescriptor share) {
        try {
            // We do not need to manage pooling for connection. This is done internally by SMBJ
            Connection c = client.connect(share.hostname());
            AuthenticationContext ac = new AuthenticationContext(share.username(), share.password(), share.domain());
            return new AbstractMap.SimpleImmutableEntry<>(c.authenticate(ac), new AtomicInteger(0));
        } catch (IOException e) {
            throw new IllegalStateException("Unable to create connection", e);
        }
    }

    void release(SmbDescriptor share) throws IOException {
        try {
            log.atDebug().log("Releasing {}",share);
            if (sessions.get(share.sessionId()).getValue().decrementAndGet() == 0) {
                Session s = sessions.remove(share.sessionId()).getKey();
                s.close();
                // Connection is pooled
                s.getConnection().close();
            }
        } catch (RuntimeException e) {
            log.atWarn().withThrowable(e).log("Error releasing session");
        }
    }

    @Override
    public void close() {
        log.atDebug().log("Closing manager");
        // Sessions and connections are closed by the client
        sessions.clear();
        client.close();
    }
}
