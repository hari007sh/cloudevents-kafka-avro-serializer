package com.ibm.build2manage.resources.smb;

import com.hierynomus.smbj.share.File;
import lombok.extern.log4j.Log4j2;

import java.io.FilterInputStream;
import java.io.IOException;

/**
 * Implementation of {@link java.io.InputStream} used with {@link SmbResource} that make sure that we close the
 * underlying SMBJ {@link File}.
 */
@Log4j2
class SmbFileInputStream extends FilterInputStream {

    private final File file;

    /**
     * Constructor;
     *
     * @param file the file we are reading from
     */
    protected SmbFileInputStream(File file) {
        super(file.getInputStream());
        this.file = file;
    }

    @Override
    public void close() throws IOException {
        log.atDebug().log("Closing InputStream for {}", file);
        super.close();
        file.close();
    }
}
