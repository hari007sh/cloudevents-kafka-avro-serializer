package com.ibm.build2manage.resources.smb;

import com.hierynomus.msdtyp.AccessMask;
import com.hierynomus.msfscc.FileNotifyAction;
import com.hierynomus.msfscc.directory.FileNotifyInformation;
import com.hierynomus.msfscc.fileinformation.FileAllInformation;
import com.hierynomus.msfscc.fileinformation.FileIdBothDirectoryInformation;
import com.hierynomus.msfscc.fileinformation.FileStandardInformation;
import com.hierynomus.mssmb2.SMB2CreateDisposition;
import com.hierynomus.mssmb2.SMB2ShareAccess;
import com.hierynomus.smbj.common.SMBRuntimeException;
import com.hierynomus.smbj.session.Session;
import com.hierynomus.smbj.share.Directory;
import com.hierynomus.smbj.share.DiskShare;
import com.ibm.build2manage.resources.DeletableResource;
import com.ibm.build2manage.resources.ListableResource;
import com.ibm.build2manage.resources.ResourceProcessor;
import lombok.AccessLevel;
import lombok.RequiredArgsConstructor;
import lombok.extern.log4j.Log4j2;
import org.springframework.core.io.WritableResource;
import org.springframework.lang.NonNull;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URI;
import java.net.URL;
import java.util.*;

import static com.hierynomus.msdtyp.AccessMask.GENERIC_READ;
import static com.hierynomus.msdtyp.AccessMask.GENERIC_WRITE;
import static com.hierynomus.mssmb2.SMB2CompletionFilter.*;
import static com.hierynomus.mssmb2.SMB2CreateDisposition.FILE_OPEN;
import static com.hierynomus.mssmb2.SMB2CreateDisposition.FILE_OVERWRITE_IF;
import static com.hierynomus.mssmb2.SMB2ShareAccess.FILE_SHARE_READ;
import static com.hierynomus.mssmb2.SMB2ShareAccess.FILE_SHARE_WRITE;

/**
 * Represents a {@link org.springframework.core.io.Resource} retrieved from a Windows share.
 */
@Log4j2
@RequiredArgsConstructor(access = AccessLevel.PACKAGE)
public class SmbResource implements WritableResource, AutoCloseable, ListableResource, DeletableResource {

    private final SmbResourceManager owner;
    private final SmbDescriptor descriptor;

    private FileAllInformation info;

    private Session session;
    private DiskShare share;
    private Directory dir;

    private Thread t;

    private final List<ResourceProcessor> processors = new ArrayList<>(0);

    private DiskShare get() {
        if (share == null) {
            log.atDebug().log("Retrieving share {} for {}", descriptor, this);
            session = owner.getSession(descriptor);
            share = (DiskShare) session.connectShare(descriptor.share());
        }
        return share;
    }

    private FileAllInformation getInfo() throws IOException {
        try {
            if (info == null) {
                info = get().getFileInformation(descriptor.path());
            }
            return info;
        } catch (SMBRuntimeException e) {
            throw new IOException("Unable to retrieve file information for " + this, e);
        }
    }

    private com.hierynomus.smbj.share.File open(AccessMask access, SMB2ShareAccess shareAccess, SMB2CreateDisposition create) throws IOException {
        try {
            log.atDebug().log("Opening {} with access={}, shareAccess={}, create={}", descriptor, access, shareAccess, create);
            return get().openFile(descriptor.path(), EnumSet.of(access), null, EnumSet.of(shareAccess), create, null);
        } catch (SMBRuntimeException e) {
            throw new IOException("Unable to open " + this + " for " + access.name(), e);
        }
    }

    @Override
    public boolean exists() {
        try {
            if (descriptor.path() == null) {
                // If we have no descriptor.path(), we simply return true if the share can be created
                get();
                return true;
            }
            return descriptor.isFolder() ? get().folderExists(descriptor.path()) : get().fileExists(descriptor.path());
        } catch (SMBRuntimeException e) {
            log.atWarn().withThrowable(e).log("Unable to determine file existence of " + this, e);
            return false;
        }
    }

    @NonNull
    @Override
    public URL getURL() throws IOException {
        throw new IOException("SmbResource cannot be represented as an URL");
    }

    @NonNull
    @Override
    public URI getURI() throws IOException {
        throw new IOException("SmbResource cannot be represented as an URI");
    }

    @NonNull
    @Override
    public File getFile() throws IOException {
        throw new IOException("Resource cannot be represented as File");
    }

    @Override
    public long contentLength() throws IOException {
        FileStandardInformation info = getInfo().getStandardInformation();
        if (info.isDirectory()) {
            return 0;
        }
        return getInfo().getStandardInformation().getEndOfFile();
    }

    @Override
    public long lastModified() throws IOException {
        return getInfo().getBasicInformation().getLastWriteTime().toEpochMillis();
    }

    @NonNull
    @Override
    public SmbResource createRelative(@NonNull String relativePath) throws IOException {
        if (getInfo().getStandardInformation().isDirectory()) {
            return new SmbResource(owner, descriptor.relative(relativePath));
        }
        throw new IOException("Unable to create relative descriptor.path() from a file");
    }

    @Override
    public String getFilename() {
        return descriptor.path().substring(descriptor.path().lastIndexOf('/') + 1);
    }

    @NonNull
    @Override
    public String getDescription() {
        return toString();
    }

    @Override
    public boolean isReadable() {
        try {
            return !getInfo().getStandardInformation().isDirectory();
        } catch (IOException e) {
            return false;
        }
    }

    @NonNull
    @Override
    public InputStream getInputStream() throws IOException {
        if (isReadable()) {
            return new SmbFileInputStream(open(GENERIC_READ, FILE_SHARE_READ, FILE_OPEN));
        }
        throw new IOException("Cannot open stream for non readable resource");
    }

    @Override
    public boolean isWritable() {
        try {
            return !exists() || !getInfo().getStandardInformation().isDirectory();
        } catch (IOException e) {
            log.atDebug().withThrowable(e).log("Exception while looking if file is writable");
            return false;
        }
    }

    @NonNull
    @Override
    public OutputStream getOutputStream() throws IOException {
        if (isWritable()) {
            return new SmbFileOutputStream(open(GENERIC_WRITE, FILE_SHARE_WRITE, FILE_OVERWRITE_IF));
        }
        throw new IOException("Cannot open stream for non writable resource");
    }


    @Override
    public Iterator<String> iterator() {
        if (descriptor.isFolder()) {
            try {
                return new SmbIterator(get().list(descriptor.path()).iterator());
            } catch (SMBRuntimeException e) {
                log.atError().withThrowable(e).log("Unable to list resources for {}", this);
            }
        }
        return Collections.emptyIterator();
    }


    @Override
    public void close() throws Exception {
        log.atInfo().log("Closing {} resource {}", descriptor, this);
        if (dir != null) {
            stopWatching();
        }
        if (session != null) {
            session = null;
            share = null;
            owner.release(descriptor);
        }
    }

    @Override
    public String toString() {
        return descriptor.toString();
    }

    @Override
    public void watch(ResourceProcessor processor) throws IOException {
        if (!descriptor.isFolder()) {
            throw new IOException("Cannot watch a file");
        }
        if (t == null) {
            dir = get().openDirectory(descriptor.path(), EnumSet.of(GENERIC_READ), null, EnumSet.of(FILE_SHARE_READ), FILE_OPEN, null);
            t = new Thread(this::monitor);
            t.start();
        }
        processors.add(processor);
    }

    private void monitor() {
        try {
            log.info("Resource monitoring started on {}", descriptor.toString());
            while (!Thread.currentThread().isInterrupted() && share != null && share.isConnected()) {
                log.debug("Waiting for next events");
                for (FileNotifyInformation i : dir.watchAsync(EnumSet.of(FILE_NOTIFY_CHANGE_FILE_NAME), true).get().getFileNotifyInfoList()) {
                    log.debug("Processing {}", i);
                    if (i.getAction().equals(FileNotifyAction.FILE_ACTION_ADDED) || i.getAction().equals(FileNotifyAction.FILE_ACTION_MODIFIED)) {
                        log.info("Event detected for {}", i);
                        // At the moment SMB protocol does not support detecting if the file
                        // is available other than trying to get an InputStream.
                        // It is delegated to the consumer to make sure it is usable
                        try (SmbResource r = createRelative(i.getFileName())) {
                            processors.forEach(c -> c.created(r));
                            log.info("Processing of {} completed", i.getFileName());
                        } catch (Exception e) {
                            log.atWarn().withThrowable(e).log("Error while processing {}", i.getFileName());
                        }
                    }
                }
            }
        } catch (Exception e) {
            Throwable cause = e;
            while (cause != null && !(cause instanceof InterruptedException)) {
                cause = cause.getCause();
            }
            if (cause == null) {
                log.atWarn().withThrowable(e).log("Unable to retrieve list of changes");
                if (e instanceof RuntimeException) {
                    throw (RuntimeException) e;
                }
                throw new RuntimeException(e);
            }
        } finally {
            log.info("Resource monitoring stopped on {}", descriptor.toString());
        }
        System.out.println("Stopped");
    }

    @Override
    public void stopWatching() {
        log.atInfo().log("Request to stop watching {}", descriptor);
        if (t != null) {
            t.interrupt();
            try {
                t.join();
            } catch (InterruptedException e) {
                // We continue and hope for the best
            }
        }
        if (dir != null) {
            dir.closeSilently();
        }
        log.atInfo().log("Watch to {} stopped", descriptor);
    }

    @Override
    public boolean delete() throws IOException {
        try {
            log.atDebug().log("Deleting {}", descriptor);
            get().rm(descriptor.path());
            log.atInfo().log("{} deleted", descriptor);
        } catch (SMBRuntimeException e) {
            throw new IOException("Unable to delete " + this, e);
        }
        return !exists();
    }

    @RequiredArgsConstructor
    private static class SmbIterator implements Iterator<String> {
        private final Iterator<FileIdBothDirectoryInformation> i;

        @Override
        public boolean hasNext() {
            return i.hasNext();
        }

        @Override
        public String next() {
            return i.next().getFileName();
        }
    }
}
