package com.ibm.build2manage.resources.smb;

import com.hierynomus.smbj.SMBClient;
import com.hierynomus.smbj.auth.AuthenticationContext;
import com.hierynomus.smbj.connection.Connection;
import com.hierynomus.smbj.session.Session;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.MethodSource;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.core.io.ResourceLoader;
import org.springframework.test.util.ReflectionTestUtils;

import java.io.IOException;
import java.util.*;
import java.util.concurrent.atomic.AtomicInteger;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.times;

@ExtendWith(MockitoExtension.class)
class SmbResourceManagerTest {

    private static final String URL = "smb://DOMAIN\\username:password@server/path/to/someplace";
    private static final String URL2 = "smb://DOMAIN\\username:password@server.with.special-09871.char/path/to/someplace";

    @Mock
    private SMBClient client;

    @Mock
    private ResourceLoader loader;

    @Mock
    private Connection connection;

    @Mock
    private Session session;

    private SmbResourceManager underTest;

    @BeforeEach
    void init() {
        underTest = new SmbResourceManager(client);
    }

    @Test
    void smbResourceCreated() {
        assertTrue(underTest.resolve(URL, loader) instanceof SmbResource);
    }

    @Test
    void notSmb() {
        assertNull(underTest.resolve("http://whatever.com", loader));
    }

    void link(String hostname, AuthenticationContext auth, Connection connection, Session session) throws IOException {
        Mockito.when(client.connect(hostname)).thenReturn(connection);
        Mockito.when(connection.authenticate(Mockito.argThat(m ->
                m != null &&
                        Objects.equals(m.getUsername(), auth.getUsername())
                        && Objects.equals(m.getDomain(), auth.getDomain())
                        && Arrays.equals(m.getPassword(), auth.getPassword())))).thenReturn(session);
        Mockito.when(session.getConnection()).thenReturn(connection);
    }

    @Test
    void singleSession() throws IOException {
        SmbDescriptor DESC1 = Objects.requireNonNull(SmbDescriptor.parse(URL));
        link("server", new AuthenticationContext("username", "password".toCharArray(), "DOMAIN"), connection, session);

        assertSame(session, underTest.getSession(DESC1));
        assertPool("sessions", "DOMAIN\\username:password@server", session, 1);

        assertSame(session, underTest.getSession(DESC1));
        assertPool("sessions", "DOMAIN\\username:password@server", session, 2);

        underTest.release(DESC1);
        assertPool("sessions", "DOMAIN\\username:password@server", session, 1);

        underTest.release(DESC1);
        assertPool("sessions", "DOMAIN\\username:password@server", session, 0);

        Mockito.verify(session).close();
        Mockito.verify(connection).close();
    }

    @Test
    void sameUserTwoConnections() throws IOException {
        SmbDescriptor DESC1 = Objects.requireNonNull(SmbDescriptor.parse(URL));
        SmbDescriptor desc2 = Objects.requireNonNull(SmbDescriptor.parse(URL2));

        Session session2 = Mockito.mock(Session.class);
        Connection connection2 = Mockito.mock(Connection.class);

        link("server", new AuthenticationContext("username", "password".toCharArray(), "DOMAIN"), connection, session);
        link("server.with.special-09871.char", new AuthenticationContext("username", "password".toCharArray(), "DOMAIN"), connection2, session2);

        assertSame(session, underTest.getSession(DESC1));
        assertPool("sessions", "DOMAIN\\username:password@server", session, 1);
        assertPool("sessions", "DOMAIN\\username:password@server.with.special-09871.char", session2, 0);

        assertSame(session2, underTest.getSession(desc2));
        assertPool("sessions", "DOMAIN\\username:password@server", session, 1);
        assertPool("sessions", "DOMAIN\\username:password@server.with.special-09871.char", session2, 1);

        underTest.release(DESC1);
        assertPool("sessions", "DOMAIN\\username:password@server", session, 0);
        assertPool("sessions", "DOMAIN\\username:password@server.with.special-09871.char", session2, 1);

        Mockito.verify(session).close();
        Mockito.verify(connection).close();
        Mockito.verify(session2, times(0)).close();
        Mockito.verify(connection2, times(0)).close();


        underTest.release(desc2);
        assertPool("sessions", "DOMAIN\\username:password@server", session, 0);
        assertPool("sessions", "DOMAIN\\username:password@server.with.special-09871.char", session2, 0);

        Mockito.verify(session).close();
        Mockito.verify(connection).close();
        Mockito.verify(session2).close();
        Mockito.verify(connection2).close();
    }

    @Test
    void differentUserSameConnection() throws IOException {
        SmbDescriptor DESC1 = Objects.requireNonNull(SmbDescriptor.parse(URL));
        SmbDescriptor desc2 = Objects.requireNonNull(SmbDescriptor.parse("smb://DOMAIN2\\username2:password2@server/path/to/someplace"));

        Session session2 = Mockito.mock(Session.class);

        link("server", new AuthenticationContext("username", "password".toCharArray(), "DOMAIN"), connection, session);
        link("server", new AuthenticationContext("username2", "password2".toCharArray(), "DOMAIN2"), connection, session2);

        assertSame(session, underTest.getSession(DESC1));
        assertPool("sessions", "DOMAIN\\username:password@server", session, 1);
        assertPool("sessions", "DOMAIN2\\username2:password2@server", session2, 0);

        assertSame(session2, underTest.getSession(desc2));
        assertPool("sessions", "DOMAIN\\username:password@server", session, 1);
        assertPool("sessions", "DOMAIN2\\username2:password2@server", session2, 1);

        underTest.release(DESC1);
        assertPool("sessions", "DOMAIN\\username:password@server", session, 0);
        assertPool("sessions", "DOMAIN2\\username2:password2@server", session2, 1);

        Mockito.verify(session).close();
        Mockito.verify(connection).close();
        Mockito.verify(session2, times(0)).close();

        underTest.release(desc2);
        assertPool("sessions", "DOMAIN\\username:password@server", session, 0);
        assertPool("sessions", "DOMAIN2\\username2:password2@server", session2, 0);

        Mockito.verify(session).close();
        Mockito.verify(session2).close();
        Mockito.verify(connection, Mockito.times(2)).close();
    }

    @SuppressWarnings("unchecked")
    private <T> void assertPool(String field, String key, T value, int n) {
        Map<String, Map.Entry<T, AtomicInteger>> cache = (Map<String, Map.Entry<T, AtomicInteger>>) Objects.requireNonNull(ReflectionTestUtils.getField(underTest, field));
        if (n == 0) {
            assertFalse(cache.containsKey(key));
        } else {
            assertTrue(cache.containsKey(key));
            assertSame(value, cache.get(key).getKey());
            assertEquals(n, cache.get(key).getValue().get());
        }
    }


    private static <T> Map.Entry<T, AtomicInteger> mock(Class<T> tClass, int n) {
        return new AbstractMap.SimpleImmutableEntry<>(
                Mockito.mock(tClass), new AtomicInteger(n)
        );
    }

    static Object[][] close() {
        return new Object[][]{
                {Collections.emptyMap(), Collections.emptyMap()},
                {Map.of("1", mock(Session.class, 1))},
                {Map.of("1", mock(Session.class, 2))},
                {Map.of("1", mock(Session.class, 1),
                        "2", mock(Session.class, 1)),
                },
                {Map.of("1", mock(Session.class, 1),
                        "2", mock(Session.class, 1))
                },
        };
    }

    @MethodSource
    @ParameterizedTest
    @SuppressWarnings("unchecked")
    void close(Map<String, Map.Entry<Session, AtomicInteger>> sessions) throws IOException {
        ReflectionTestUtils.setField(underTest, "sessions", new HashMap<>(sessions));
        underTest.close();
        assertTrue(((Map<String, Map.Entry<?, AtomicInteger>>) Objects.requireNonNull(ReflectionTestUtils.getField(underTest, "sessions"))).isEmpty());
    }

}