package com.ibm.build2manage.resources.smb;

import com.hierynomus.smbj.SMBClient;
import org.apache.commons.io.IOUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.util.StreamUtils;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.Charset;
import java.time.Instant;
import java.time.OffsetDateTime;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.util.concurrent.CountDownLatch;

/**
 * Small utility to manually test with SMB resources.
 * <p>
 * TODO convert to use any ListableResource
 */
public class SmbContext {

    private static final DateTimeFormatter FORMAT = DateTimeFormatter.ofPattern("yyyyMMdd_hhmmss");

    private static Logger LOGGER;

    public static void display(SmbResource r) throws IOException {
        LOGGER.info("===========================");
        LOGGER.info("Resource found: {}", r.toString());
        LOGGER.info("Filename: {}", r.getFilename());
        LOGGER.info("Last modified: {}", Instant.ofEpochMilli(r.lastModified()).atOffset(ZoneOffset.UTC));
        LOGGER.info("Readable: {}", r.isReadable());
        LOGGER.info("Writable: {}", r.isWritable());
        LOGGER.info("Content length: {}", r.contentLength());
        LOGGER.info("===========================");
    }

    public static void main(String[] args) throws IOException, InterruptedException {
        System.setProperty("log4j2.configurationFile", "log4j2.tmp.xml");
        LOGGER = LogManager.getLogger();
        try (SmbResourceManager resolver = new SmbResourceManager(new SMBClient())) {
            SmbResource r = (SmbResource) resolver.resolve("smb://D2-TDBFG\\SVC_GWIRO_APP:" + args[0] + "@ABGWIROSDDVY1A0.D2-TDBFG.COM/GWIROSHAREIN", null);
            display(r);

            for (String child : r) {
                if (!child.matches("^\\.*$")) {
                    display(r.createRelative(child));
                }
            }

            int nbFiles = 5;

            CountDownLatch latch = new CountDownLatch(nbFiles);

            int maxRetry = 5;
            long retryDelay = 5000;

            r.watch(n -> {
                try {
                    boolean processed = false;
                    display((SmbResource) n);
                    for (int i = 0; i < maxRetry && !processed && !Thread.currentThread().isInterrupted(); i++) {
                        try (InputStream s = n.getInputStream()) {
                            LOGGER.info(StreamUtils.copyToString(s, Charset.defaultCharset()));
                            processed = true;
                            latch.countDown();
                        } catch (IOException e) {
                            // Do nothing, we retry
                            try {
                                Thread.sleep(retryDelay);
                            } catch (InterruptedException ie) {
                                // do nothing and close
                            }
                        }
                    }
                    ((SmbResource) n).delete();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            });

            for (int i = 0; i < nbFiles; i++) {
                SmbResource child = r.createRelative("test-" + OffsetDateTime.now().format(FORMAT) + ".txt");
                LOGGER.info("Creating " + child);
                OutputStream out = (child).getOutputStream();
                IOUtils.write("This is a test " + OffsetDateTime.now(), out, Charset.defaultCharset());
                out.close();
                Thread.sleep(5000);
            }

            latch.await();
        }
    }

}
