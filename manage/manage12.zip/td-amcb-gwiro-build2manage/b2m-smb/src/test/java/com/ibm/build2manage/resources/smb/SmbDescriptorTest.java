package com.ibm.build2manage.resources.smb;

import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;

import java.util.Objects;

import static org.junit.jupiter.api.Assertions.*;

class SmbDescriptorTest {

    private void assertDescriptor(SmbDescriptor descriptor, String toString, String domain, String username, String password, String hostname, String session1Id, String share, String path, boolean folder) {
        assertEquals(domain, descriptor.domain());
        assertEquals(username, descriptor.username());
        assertArrayEquals(password == null ? new char[0] : password.toCharArray(), descriptor.password());
        assertEquals(hostname, descriptor.hostname());
        assertEquals(session1Id, descriptor.sessionId());
        assertEquals(share, descriptor.share());
        assertEquals(path, descriptor.path());
        assertEquals(folder, descriptor.isFolder());
        assertEquals(toString, descriptor.toString());
    }

    @CsvSource({
            "smb://server/path,smb://server/path,,,,server,server,path,'',true",
            "smb://server/path/to/someplace,smb://server/path/to/someplace,,,,server,server,path,/to/someplace,true",
            "smb://server/path/to/someplace.txt,smb://server/path/to/someplace.txt,,,,server,server,path,/to/someplace.txt,false",
            "smb://username:password@server/path,smb://username:*****@server/path,,username,password,server,username:password@server,path,'',true",
            "smb://username:password@server/path/to/someplace,smb://username:*****@server/path/to/someplace,,username,password,server,username:password@server,path,/to/someplace,true",
            "smb://username:password@server/path/to/someplace.txt,smb://username:*****@server/path/to/someplace.txt,,username,password,server,username:password@server,path,/to/someplace.txt,false",
            "smb://DOMAIN\\username:password@server/path/to/someplace,smb://DOMAIN\\username:*****@server/path/to/someplace,DOMAIN,username,password,server,DOMAIN\\username:password@server,path,/to/someplace,true",
            "smb://DOMAIN\\username:password@server/path/to/someplace.txt,smb://DOMAIN\\username:*****@server/path/to/someplace.txt,DOMAIN,username,password,server,DOMAIN\\username:password@server,path,/to/someplace.txt,false",
            "smb://DOMAIN\\username:password@server.with.special-09871.char/path/to/someplace,smb://DOMAIN\\username:*****@server.with.special-09871.char/path/to/someplace,DOMAIN,username,password,server.with.special-09871.char,DOMAIN\\username:password@server.with.special-09871.char,path,/to/someplace,true",
            "smb://DOMAIN\\username:password@server.with.special-09871.char/path/to/someplace.txt,smb://DOMAIN\\username:*****@server.with.special-09871.char/path/to/someplace.txt,DOMAIN,username,password,server.with.special-09871.char,DOMAIN\\username:password@server.with.special-09871.char,path,/to/someplace.txt,false",
            "smb://DOM!@#$%^&*()AIN\\usern!@#$%^&*()ame:pa!#$%^&*()ssword@server.with.special-09871.char/path/to/someplace,smb://DOM!@#$%^&*()AIN\\usern!@#$%^&*()ame:*****@server.with.special-09871.char/path/to/someplace,DOM!@#$%^&*()AIN,usern!@#$%^&*()ame,pa!#$%^&*()ssword,server.with.special-09871.char,DOM!@#$%^&*()AIN\\usern!@#$%^&*()ame:pa!#$%^&*()ssword@server.with.special-09871.char,path,/to/someplace,true",
    })
    @ParameterizedTest
    void resolve(String location, String toString, String domain, String username, String password, String hostname, String session1Id, String share, String path, boolean folder) {
        SmbDescriptor descriptor = SmbDescriptor.parse(location);
        assertNotNull(descriptor);
        assertDescriptor(descriptor, toString, domain, username, password, hostname, session1Id, share, path, folder);
    }

    @CsvSource({
            "smb://DOMAIN\\username:password@server/path/to/someplace,child",
            "smb://DOMAIN\\username:password@server/path/to/someplace,/child",
            "smb://DOMAIN\\username:password@server/path/to/someplace/,child",
            "smb://DOMAIN\\username:password@server/path/to/someplace/,/child",
    })
    @ParameterizedTest
    void testRelative(String location, String relative) {
        SmbDescriptor descriptor = Objects.requireNonNull(SmbDescriptor.parse(location));
        assertDescriptor(descriptor.relative(relative), "smb://DOMAIN\\username:*****@server/path/to/someplace/child", "DOMAIN", "username", "password", "server", "DOMAIN\\username:password@server", "path", "/to/someplace/child", true);
    }

}