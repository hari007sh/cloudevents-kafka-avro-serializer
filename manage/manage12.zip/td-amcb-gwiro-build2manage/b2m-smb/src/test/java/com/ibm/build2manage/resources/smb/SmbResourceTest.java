package com.ibm.build2manage.resources.smb;

import com.hierynomus.msdtyp.FileTime;
import com.hierynomus.msfscc.fileinformation.FileAllInformation;
import com.hierynomus.msfscc.fileinformation.FileBasicInformation;
import com.hierynomus.msfscc.fileinformation.FileIdBothDirectoryInformation;
import com.hierynomus.msfscc.fileinformation.FileStandardInformation;
import com.hierynomus.smbj.common.SMBRuntimeException;
import com.hierynomus.smbj.session.Session;
import com.hierynomus.smbj.share.DiskShare;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.junit.jupiter.params.provider.MethodSource;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.stubbing.Answer;
import org.springframework.test.util.ReflectionTestUtils;

import java.io.IOException;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;

@ExtendWith(MockitoExtension.class)
class SmbResourceTest {

    private static final SMBRuntimeException SESSION_ISSUE = new SMBRuntimeException("Session issue");
    private static final SMBRuntimeException SHARE_ISSUE = new SMBRuntimeException("Share issue");

    private static final SMBRuntimeException INFO_ISSUE = new SMBRuntimeException("Information issue");

    @Mock
    private Session session;

    @Mock
    private SmbResourceManager manager;

    @Mock
    private DiskShare share;

    @Mock
    private SmbDescriptor descriptor;

    @InjectMocks
    private SmbResource underTest;
    @Mock
    private FileAllInformation fileInfo;
    @Mock
    private FileStandardInformation standardInfo;

    @Mock
    private FileBasicInformation basicInfo;

    private static void none(SmbResourceManager manager, Session session, DiskShare share, SmbDescriptor descriptor, String shareName, SmbResource underTest) {
    }

    private static void happyPath(SmbResourceManager manager, Session session, DiskShare share, SmbDescriptor descriptor, String shareName, SmbResource underTest) {
        Mockito.when(manager.getSession(descriptor)).thenReturn(session);
        Mockito.when(descriptor.share()).thenReturn(shareName);
        Mockito.when(session.connectShare(shareName)).thenReturn(share);
    }

    private static void alreadyInitialized(SmbResourceManager manager, Session session, DiskShare share, SmbDescriptor descriptor, String shareName, SmbResource underTest) {
        ReflectionTestUtils.setField(underTest, "session", session);
        ReflectionTestUtils.setField(underTest, "share", share);
    }

    private static void sessionIssue(SmbResourceManager manager, Session session, DiskShare share, SmbDescriptor descriptor, String shareName, SmbResource underTest) {
        Mockito.when(manager.getSession(descriptor)).thenThrow(SESSION_ISSUE);
    }

    private static void shareIssue(SmbResourceManager manager, Session session, DiskShare share, SmbDescriptor descriptor, String shareName, SmbResource underTest) {
        Mockito.when(manager.getSession(descriptor)).thenReturn(session);
        Mockito.when(descriptor.share()).thenReturn(shareName);
        Mockito.when(session.connectShare(shareName)).thenThrow(SHARE_ISSUE);
    }

    private static void infoIssue(SmbResourceManager manager, Session session, DiskShare share, SmbDescriptor descriptor, String shareName, SmbResource underTest) {
        happyPath(manager, session, share, descriptor, shareName, underTest);
        Mockito.when(share.getFileInformation((String) any())).thenThrow(INFO_ISSUE);
    }

    static Object[][] existsNoPath() {
        return new Object[][]{
                {(InitializeTest) SmbResourceTest::happyPath, true},
                {(InitializeTest) SmbResourceTest::alreadyInitialized, true},
                {(InitializeTest) SmbResourceTest::sessionIssue, false},
                {(InitializeTest) SmbResourceTest::shareIssue, false},
        };
    }

    @MethodSource
    @ParameterizedTest
    void existsNoPath(InitializeTest init, boolean expected) {
        init.apply(manager, session, share, descriptor, UUID.randomUUID().toString(), underTest);
        Mockito.when(descriptor.path()).thenReturn(null);
        assertEquals(expected, underTest.exists());
    }

    static Object[][] exists() {
        Answer<Boolean> t = (i) -> true;
        Answer<Boolean> f = (i) -> false;
        Answer<Boolean> e = (i) -> {
            throw new SMBRuntimeException("exception");
        };
        return new Object[][]{
                {(InitializeTest) SmbResourceTest::happyPath, t, true},
                {(InitializeTest) SmbResourceTest::happyPath, f, false},
                {(InitializeTest) SmbResourceTest::happyPath, e, false},

                {(InitializeTest) SmbResourceTest::alreadyInitialized, t, true},
                {(InitializeTest) SmbResourceTest::alreadyInitialized, f, false},
                {(InitializeTest) SmbResourceTest::alreadyInitialized, e, false},

                {(InitializeTest) SmbResourceTest::sessionIssue, t, false},
                {(InitializeTest) SmbResourceTest::shareIssue, t, false},
        };
    }

    @MethodSource("exists")
    @ParameterizedTest
    void existsFolder(InitializeTest init, Answer<Boolean> a, boolean expected) {
        String path = UUID.randomUUID().toString();
        init.apply(manager, session, share, descriptor, UUID.randomUUID().toString(), underTest);
        Mockito.when(descriptor.path()).thenReturn(path);
        Mockito.when(descriptor.isFolder()).thenReturn(true);
        Mockito.lenient().when(share.folderExists(path)).then(a);
        assertEquals(expected, underTest.exists());
    }

    @MethodSource("exists")
    @ParameterizedTest
    void existsFile(InitializeTest init, Answer<Boolean> a, boolean expected) {
        String path = UUID.randomUUID().toString();
        init.apply(manager, session, share, descriptor, UUID.randomUUID().toString(), underTest);
        Mockito.when(descriptor.path()).thenReturn(path);
        Mockito.when(descriptor.isFolder()).thenReturn(false);
        Mockito.lenient().when(share.fileExists(path)).then(a);
        assertEquals(expected, underTest.exists());
    }

    static Object[][] infoException() {
        return new Object[][]{
                {(InitializeTest) SmbResourceTest::sessionIssue, SESSION_ISSUE},
                {(InitializeTest) SmbResourceTest::shareIssue, SHARE_ISSUE},
                {(InitializeTest) SmbResourceTest::infoIssue, INFO_ISSUE},
        };
    }

    @MethodSource("infoException")
    @ParameterizedTest
    void contentLengthException(InitializeTest init, Exception expected) {
        init.apply(manager, session, share, descriptor, UUID.randomUUID().toString(), underTest);
        assertSame(expected, assertThrows(IOException.class, () -> underTest.contentLength()).getCause());
    }

    static Object[][] contentLength() {
        return new Object[][]{
                {(InitializeTest) SmbResourceTest::happyPath, true, 0},
                {(InitializeTest) SmbResourceTest::happyPath, false, 1000},
                {(InitializeTest) SmbResourceTest::alreadyInitialized, true, 0},
                {(InitializeTest) SmbResourceTest::alreadyInitialized, false, 2500},
        };
    }

    @MethodSource
    @ParameterizedTest
    void contentLength(InitializeTest init, boolean folder, long expected) throws IOException {
        String path = UUID.randomUUID().toString();
        init.apply(manager, session, share, descriptor, UUID.randomUUID().toString(), underTest);
        Mockito.when(standardInfo.isDirectory()).thenReturn(folder);
        Mockito.when(descriptor.path()).thenReturn(path);
        Mockito.when(share.getFileInformation(path)).thenReturn(fileInfo);
        Mockito.when(fileInfo.getStandardInformation()).thenReturn(standardInfo);
        if (!folder) {
            Mockito.when(standardInfo.getEndOfFile()).thenReturn(expected);
        }
        assertEquals(expected, underTest.contentLength());
    }

    @MethodSource("infoException")
    @ParameterizedTest
    void lastModifiedException(InitializeTest init, Exception expected) {
        init.apply(manager, session, share, descriptor, UUID.randomUUID().toString(), underTest);
        assertSame(expected, assertThrows(IOException.class, () -> underTest.lastModified()).getCause());
    }

    static Object[][] basic() {
        return new Object[][]{
                {(InitializeTest) SmbResourceTest::happyPath},
                {(InitializeTest) SmbResourceTest::alreadyInitialized},
        };
    }

    @MethodSource("basic")
    @ParameterizedTest
    void lastModified(InitializeTest init) throws IOException {
        long expected = (long) (Math.random() * 100000L);
        String path = UUID.randomUUID().toString();
        init.apply(manager, session, share, descriptor, UUID.randomUUID().toString(), underTest);
        Mockito.when(descriptor.path()).thenReturn(path);
        Mockito.when(share.getFileInformation(path)).thenReturn(fileInfo);
        Mockito.when(fileInfo.getBasicInformation()).thenReturn(basicInfo);
        Mockito.when(basicInfo.getLastWriteTime()).thenReturn(FileTime.ofEpochMillis(expected));
        assertEquals(expected, underTest.lastModified());
    }

    @MethodSource("basic")
    @ParameterizedTest
    void createRelativeFile(InitializeTest init) {
        String path = UUID.randomUUID().toString();
        init.apply(manager, session, share, descriptor, UUID.randomUUID().toString(), underTest);
        Mockito.when(descriptor.path()).thenReturn(path);
        Mockito.when(share.getFileInformation(path)).thenReturn(fileInfo);
        Mockito.when(fileInfo.getStandardInformation()).thenReturn(standardInfo);
        Mockito.when(standardInfo.isDirectory()).thenReturn(false);
        assertThrows(IOException.class, () -> underTest.createRelative(""));
    }

    @MethodSource("basic")
    @ParameterizedTest
    void createRelativeFolder(InitializeTest init) throws IOException {
        String path = UUID.randomUUID().toString();
        init.apply(manager, session, share, descriptor, UUID.randomUUID().toString(), underTest);
        Mockito.when(descriptor.path()).thenReturn(path);
        Mockito.when(share.getFileInformation(path)).thenReturn(fileInfo);
        Mockito.when(fileInfo.getStandardInformation()).thenReturn(standardInfo);
        Mockito.when(standardInfo.isDirectory()).thenReturn(true);
        SmbResource actual = underTest.createRelative(path);
        Mockito.verify(descriptor).relative(path);
        assertSame(manager, ReflectionTestUtils.getField(actual, "owner"));
    }

    @CsvSource(
            {
                    "/,''",
                    "/path,path",
                    "/filename.txt,filename.txt",
                    "/path/filename.txt,filename.txt",
                    "/path/to,to"
            }
    )
    @ParameterizedTest
    void getFilename(String path, String expected) {
        Mockito.when(descriptor.path()).thenReturn(path);
        assertEquals(expected, underTest.getFilename());
    }

    @Test
    void getDescription() {
        String random = UUID.randomUUID().toString();
        Mockito.when(descriptor.toString()).thenReturn(random);
        assertSame(random, underTest.getDescription());
        assertSame(random, underTest.toString());
    }

    @Test
    void reading() {
    }

    @Test
    void writing() {
    }

    static Object[][] iteratorNoList() {
        return new Object[][]{
                {(InitializeTest) SmbResourceTest::none, false},
                {(InitializeTest) SmbResourceTest::sessionIssue, true},
                {(InitializeTest) SmbResourceTest::shareIssue, true},
                {(InitializeTest) (m, s, sh, d, sn, u) -> {
                    happyPath(m, s, sh, d, sn, u);
                    Mockito.when(sh.list(any())).thenThrow(new SMBRuntimeException(""));
                }, true},
        };
    }

    @MethodSource
    @ParameterizedTest
    void iteratorNoList(InitializeTest init, boolean folder) {
        init.apply(manager, session, share, descriptor, UUID.randomUUID().toString(), underTest);
        Mockito.when(descriptor.isFolder()).thenReturn(folder);
        assertFalse(underTest.iterator().hasNext());
    }

    static Object[][] iterator() {
        return new Object[][]{
                {(InitializeTest) SmbResourceTest::happyPath, Collections.emptyList()},
                {(InitializeTest) SmbResourceTest::alreadyInitialized, Collections.emptyList()},

                {(InitializeTest) SmbResourceTest::happyPath, List.of("1")},
                {(InitializeTest) SmbResourceTest::alreadyInitialized, List.of("1")},

                {(InitializeTest) SmbResourceTest::happyPath, List.of("1", "2")},
                {(InitializeTest) SmbResourceTest::alreadyInitialized, List.of("1", "2")},

        };
    }

    @MethodSource
    @ParameterizedTest
    void iterator(InitializeTest init, List<String> expected) {
        String path = UUID.randomUUID().toString();
        init.apply(manager, session, share, descriptor, UUID.randomUUID().toString(), underTest);
        Mockito.when(descriptor.isFolder()).thenReturn(true);
        Mockito.when(descriptor.path()).thenReturn(path);
        List<FileIdBothDirectoryInformation> list = expected.stream()
                .map(i -> {
                    FileIdBothDirectoryInformation f = Mockito.mock(FileIdBothDirectoryInformation.class);
                    Mockito.when(f.getFileName()).thenReturn(i);
                    return f;
                }).collect(Collectors.toList());
        Mockito.when(share.list(path)).thenReturn(list);
        Iterator<String> actual = underTest.iterator();
        for (String str : expected) {
            assertEquals(str, actual.next());
        }
        assertFalse(actual.hasNext());
    }

    static Object[][] close() {
        return new Object[][]{
                {(InitializeTest) SmbResourceTest::none, 0},
                {(InitializeTest) SmbResourceTest::alreadyInitialized, 1},
        };
    }

    @MethodSource
    @ParameterizedTest
    void close(InitializeTest init, int releases) throws Exception {
        init.apply(manager, session, share, descriptor, UUID.randomUUID().toString(), underTest);
        underTest.close();
        Mockito.verify(manager, Mockito.times(releases)).release(descriptor);
        assertNull(ReflectionTestUtils.getField(underTest, "session"));
        assertNull(ReflectionTestUtils.getField(underTest, "share"));
    }

    private interface InitializeTest {
        void apply(SmbResourceManager manager, Session session, DiskShare share, SmbDescriptor descriptor, String shareName, SmbResource underTest);
    }
}