package com.ibm.build2manage.web;

import org.springframework.boot.web.client.RestTemplateCustomizer;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class TestConfiguration {

    @Bean
    public MockResponseInterceptor interceptor() {
        return new MockResponseInterceptor();
    }

    @Bean
    public RestTemplateCustomizer customizer() {
        return r -> r.getInterceptors().add(interceptor());
    }

    @Bean
    public TestController controller() {
        return new TestController();
    }

}
