package com.ibm.build2manage.web;

import org.junit.jupiter.api.Assertions;
import org.springframework.http.HttpRequest;
import org.springframework.http.client.ClientHttpRequestExecution;
import org.springframework.http.client.ClientHttpRequestInterceptor;
import org.springframework.http.client.ClientHttpResponse;
import org.springframework.lang.NonNull;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class MockResponseInterceptor implements ClientHttpRequestInterceptor {

    private final List<RequestValidation> validations = new ArrayList<>();

    public void reset() {
        validations.clear();
    }

    /**
     * Define a behavior for outgoing requests.
     *
     * @return a new RequestValidation instance to configure
     */
    public RequestValidation when() {
        RequestValidation result = new RequestValidation();
        validations.add(result);
        return result;
    }

    @NonNull
    @Override
    public ClientHttpResponse intercept(@NonNull HttpRequest request, @NonNull byte[] body, @NonNull ClientHttpRequestExecution execution) throws IOException {
        ClientHttpResponse response = null;
        for (int i = 0; i < validations.size() && response == null; i++) {
            response = validations.get(i).apply(request, body);
        }
        if (response == null) {
            Assertions.fail("Unexpected call to " + request.getURI());
        }
        return response;
    }

    public void verify() {
        for (RequestValidation validation : validations) {
            if (!validation.isCalled()) {
                Assertions.fail("Unmatched validation " + validation);
            }
        }
    }
}
