package com.ibm.build2manage.web;

import org.springframework.http.RequestEntity;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class TestController {

    AbstractWebTest.ControllerValidator onRequest;

    @RequestMapping(value = "${test.path}", method = {
            RequestMethod.DELETE,
            RequestMethod.GET,
            RequestMethod.PATCH,
            RequestMethod.HEAD,
            RequestMethod.OPTIONS,
            RequestMethod.POST,
            RequestMethod.PUT,
            RequestMethod.TRACE
    })
    public ResponseEntity<Object> doQuery(RequestEntity<Object> request) {
        return onRequest.apply(request);
    }

    @RequestMapping(value = "${test.path}/{id}", method = {
            RequestMethod.DELETE,
            RequestMethod.GET,
            RequestMethod.PATCH,
            RequestMethod.HEAD,
            RequestMethod.OPTIONS,
            RequestMethod.POST,
            RequestMethod.PUT,
            RequestMethod.TRACE
    })
    public ResponseEntity<Object> doQueryWithId(RequestEntity<Object> request) {
        return onRequest.apply(request);
    }

}
