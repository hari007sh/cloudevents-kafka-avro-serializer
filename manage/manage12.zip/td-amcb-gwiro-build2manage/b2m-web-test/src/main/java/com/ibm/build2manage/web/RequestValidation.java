package com.ibm.build2manage.web;

import lombok.Getter;
import org.springframework.http.HttpRequest;
import org.springframework.http.HttpStatus;
import org.springframework.http.client.ClientHttpResponse;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.function.Consumer;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;

/**
 * An instance allowing to validate an outgoing request. This instance is similar to
 * {@link io.restassured.specification.RequestSpecification} to keep some consistency
 * within tests using {@link io.restassured.RestAssured}.
 */
public class RequestValidation {


    private String method = "";
    private String url = "";
    private final List<Consumer<HttpRequest>> reqValidations = new ArrayList<>();
    private BodyValidator<byte[]> bodyValidator = c -> {
    };

    private final ResponseSpecification response = new ResponseSpecification();

    @Getter
    private boolean called = false;

    public RequestValidation lenient() {
        this.called = true;
        return this;
    }

    public RequestValidation on(String method, String url) {
        this.method = Objects.requireNonNull(method, "Method required");
        this.url = Objects.requireNonNull(url, "URL required");
        return this;
    }

    /**
     * Specify that this {@link RequestValidation} is assigned to a GET request with the provided url.
     *
     * @param url the URL we expect the GET query
     * @return this
     */
    public RequestValidation get(String url) {
        return on("GET", url);
    }

    /**
     * Specify that this {@link RequestValidation} is assigned to a POST request with the provided url.
     *
     * @param url the URL we expect to execute a POST query
     * @return this
     */
    public RequestValidation post(String url) {
        return on("POST", url);
    }

    /**
     * Assert that a header contains the expected values. If not values are provided,
     * this will only validate that the header has a value set.
     *
     * @param name   the name of the header
     * @param values the expected values
     * @return this
     */
    public RequestValidation header(String name, String... values) {
        reqValidations.add(r -> {
            List<String> actual = Objects.requireNonNullElse(r.getHeaders().get(name), Collections.emptyList());
            assertFalse(actual.isEmpty(), "Header not found: " + name);
            if (values.length != 0) {
                assertEquals(values.length, actual.size(), "Wrong number of values for header " + name);
                for (int i = 0; i < values.length; i++) {
                    assertEquals(values[i], actual.get(i), "Wrong value at position " + i);
                }
            }
        });
        return this;
    }

    /**
     * Assert that the body matches the provided
     *
     * @param matcher the predicate that evaluates the body
     * @return this
     */
    public RequestValidation body(BodyValidator<byte[]> matcher) {
        bodyValidator = Objects.requireNonNull(matcher);
        return this;
    }

    /**
     * @return this response specification
     */
    public ResponseSpecification thenReturn(HttpStatus status) {
        return response.statusCode(status);
    }

    /**
     * Apply this validation on an intercepted request.
     *
     * @param request the intercepted {@link HttpRequest}
     * @param body    the content of the body
     * @return the associated response or null if the request did not match.
     */
    public ClientHttpResponse apply(HttpRequest request, byte[] body) throws IOException {
        if (url.equalsIgnoreCase(request.getURI().toString()) &&
                method.equalsIgnoreCase(request.getMethodValue())) {
            called = true;
            reqValidations.forEach(c -> c.accept(request));
            bodyValidator.accept(body);
            return response.get();
        }
        return null;
    }

    @Override
    public String toString() {
        return method + " " + url;
    }

    @FunctionalInterface
    public interface BodyValidator<T> {

        void accept(T content) throws IOException;
    }
}
