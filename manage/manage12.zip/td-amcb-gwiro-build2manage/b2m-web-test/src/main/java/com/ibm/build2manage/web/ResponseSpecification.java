package com.ibm.build2manage.web;

import io.restassured.internal.util.IOUtils;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.client.ClientHttpResponse;
import org.springframework.mock.http.client.MockClientHttpResponse;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.Objects;

/**
 * An instance allowing to create a response for an outgoing request. This instance is
 * similar to {@link io.restassured.specification.ResponseSpecification} to keep some
 * consistency within tests using {@link io.restassured.RestAssured}.
 */
public class ResponseSpecification {

    private static final byte[] EMPTY = new byte[0];
    private HttpStatus status = HttpStatus.I_AM_A_TEAPOT;

    private final HttpHeaders headers = new HttpHeaders();
    private byte[] body = EMPTY;

    /**
     * Specify the status code returned by the call.
     *
     * @param status the status
     * @return this
     */
    public ResponseSpecification statusCode(HttpStatus status) {
        this.status = status;
        return this;
    }

    /**
     * Add a header to the response.
     *
     * @param name  the name of the header
     * @param value the valud of the header
     * @return this
     */
    public ResponseSpecification header(String name, String value) {
        this.headers.add(name, value);
        return this;
    }

    /**
     * Adds a Content-Type header to the response.
     *
     * @param value the content type
     * @return this
     */
    public ResponseSpecification contentType(String value) {
        return header("Content-Type", value);
    }

    /**
     * Stop the response configuration, specifying to return the content of the provided file.
     *
     * @param filename the name of the file, loaded by the {@link ClassLoader}.
     * @throws IOException if unable to read the provided file
     */
    public void file(String filename) throws IOException {
        body(IOUtils.toByteArray(Objects.requireNonNull(AbstractWebTest.class.getResourceAsStream(filename))));
    }

    /**
     * Complete the response configuration, specifying to return the provided bytes as the body.
     *
     * @param body the content of the body
     */
    public void body(byte[] body) {
        this.body = Objects.requireNonNullElse(body, EMPTY);
    }

    /**
     * Complete the response configuration, specifying to return the provided bytes as the body.
     *
     * @param body the content of the body
     */
    public void body(String body) {
        body(body.getBytes(StandardCharsets.UTF_8));
    }

    /**
     * Complete the response configuration, returning nothing (null) in the body.
     */
    public void returnNothing() {
        this.body = EMPTY;
    }

    /**
     * @return the corresponding response
     */
    ClientHttpResponse get() {
        MockClientHttpResponse result = new MockClientHttpResponse(body, status);
        result.getHeaders().addAll(headers);
        return result;
    }
}
