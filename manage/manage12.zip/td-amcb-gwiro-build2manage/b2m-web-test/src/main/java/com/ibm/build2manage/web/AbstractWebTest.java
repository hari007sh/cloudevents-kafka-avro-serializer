package com.ibm.build2manage.web;

import io.restassured.RestAssured;
import io.restassured.specification.RequestSpecification;
import org.junit.jupiter.api.AfterEach;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.context.annotation.Import;
import org.springframework.context.annotation.PropertySource;
import org.springframework.http.RequestEntity;
import org.springframework.http.ResponseEntity;
import org.springframework.test.annotation.DirtiesContext;

import java.util.function.Function;

/**
 * This class helps simplify testing a web application with Spring Boot. It offers capability to validate requests to
 * remote systems and mock their response, or to validate requests received by a controller and mocking their response.
 */

@EnableAutoConfiguration
@Import(TestConfiguration.class)
@PropertySource("classpath:defaults.properties")
public abstract class AbstractWebTest {

    @Autowired
    protected TestController controller;

    @Autowired
    protected MockResponseInterceptor interceptor;

    @LocalServerPort
    private int port;

    /**
     * The path of the mock controller.
     */
    @Value("${test.path}")
    protected String mockPath;

    @AfterEach
    void cleanupState() {
        try {
            interceptor.verify();
        } finally {
            interceptor.reset();
        }
    }

    /**
     * This method is used to retrieve a {@link RestAssured} specification pointing to the current web service port.
     *
     * @return the {@link RestAssured} specification
     */
    protected RequestSpecification given() {
        return RestAssured.given().port(port);
    }

    /**
     * This method is used to simulate a behavior for mock controller. This is mostly used to test Filters or other logic
     * that occurs before reaching the controller.
     *
     * @param onRequest the {@link FunctionalInterface} testing the request and simulating the response
     * @return the {@link RestAssured} specification
     */
    protected RequestSpecification given(ControllerValidator onRequest) {
        controller.onRequest = onRequest;
        return RestAssured.given().port(port);
    }

    /**
     * Functional interface that is used to validate a request received by the controller and simulate the response.
     */
    @FunctionalInterface
    public interface ControllerValidator extends Function<RequestEntity<Object>, ResponseEntity<Object>> {

    }

}
