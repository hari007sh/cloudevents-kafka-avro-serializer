package com.ibm.build2manage.jpa.mongodb;

import com.ibm.build2manage.jpa.UUIDPersistable;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import java.time.OffsetDateTime;
import java.util.UUID;

@Document("test")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class TestBean implements UUIDPersistable {

    @Id
    private UUID id;

    private String field1;

    private OffsetDateTime time;

}
