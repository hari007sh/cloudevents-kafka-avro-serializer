package com.ibm.build2manage.jpa.mongodb;

import org.bson.Document;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.MethodSource;
import org.mockito.Mockito;

import java.time.OffsetDateTime;
import java.util.Date;

import static org.junit.jupiter.api.Assertions.assertEquals;

class OffsetDateTimeCodecTest {

    static Object[][] data() {
        return new Object[][]{
                {"1660136773000", "Z", OffsetDateTime.parse("2022-08-10T13:06:13Z")},
                {"1660136773000", "-04:00", OffsetDateTime.parse("2022-08-10T09:06:13-04:00")},
                {"1660136773000", "-05:00", OffsetDateTime.parse("2022-08-10T08:06:13-05:00")},
        };
    }

    @MethodSource("data")
    @ParameterizedTest
    void decode(long timestamp, String offset, OffsetDateTime expected) {
        Document document = Mockito.mock(Document.class);
        Mockito.when(document.getDate("dateTime")).thenReturn(new Date(timestamp));
        Mockito.when(document.getString("offset")).thenReturn(offset);
        assertEquals(expected, new MongoOffsetDateTimeReader().convert(document));
    }

    @MethodSource("data")
    @ParameterizedTest
    void encode(long timestamp, String offset, OffsetDateTime expected) {
        Document document = new MongoOffsetDateTimeWriter().convert(expected);
        assertEquals(timestamp, document.getDate("dateTime").getTime());
        assertEquals(offset, document.getString("offset"));
    }
}