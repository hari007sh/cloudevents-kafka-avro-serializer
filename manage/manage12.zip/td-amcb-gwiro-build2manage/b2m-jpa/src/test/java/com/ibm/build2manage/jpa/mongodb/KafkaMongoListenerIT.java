package com.ibm.build2manage.jpa.mongodb;

import org.apache.kafka.clients.producer.ProducerRecord;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.data.mongodb.repository.config.EnableMongoRepositories;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.test.annotation.DirtiesContext;

import java.util.UUID;

import static org.junit.jupiter.api.Assertions.assertEquals;


@EnableAutoConfiguration
@EnableMongoRepositories
@SpringBootTest(classes = KafkaMongoListenerConfiguration.class, properties = {
        "spring.mongodb.embedded.version=4.0.12",
        "unit.topic=unit"
})
class KafkaMongoListenerIT {

    @MockBean
    private KafkaTemplate<String, Object> kafka;

    @Autowired
    private TestRepo repo;

    @Autowired
    private KafkaMongoListener underTest;

    @Captor
    private ArgumentCaptor<ProducerRecord<String, Object>> msg;

    private void assertMessage(String id, TestBean2 value) {
        Mockito.verify(kafka).send(msg.capture());
        ProducerRecord<String, Object> actual = msg.getValue();
        assertEquals("unit", actual.topic());
        assertEquals(id, actual.key());
        assertEquals(id, new String(actual.headers().lastHeader("id").value()));
        assertEquals(value, actual.value());
        assertEquals("com.ibm.build2manage.jpa.mongodb.TestBean2", new String(actual.headers().lastHeader("type").value()));
    }

    @Test
    void savingShouldPublishBean() {
        TestBean bean = new TestBean();
        bean.setId(UUID.randomUUID());
        bean.setField1(UUID.randomUUID().toString());
        repo.save(bean);
        assertMessage(bean.getId().toString(), new TestBean2(bean.getId(), bean.getField1(), null));
    }

    @Test
    void deletingShouldPublishNull() {
        TestBean bean = new TestBean();
        bean.setId(UUID.randomUUID());
        bean.setField1("field value");
        repo.delete(bean);
        assertMessage(bean.getId().toString(), null);
    }

}