package com.ibm.build2manage.jpa;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class TaggedEntity<T> implements TaggedPersistable<T> {

    private T tag;
}
