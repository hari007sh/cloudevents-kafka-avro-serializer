package com.ibm.build2manage.jpa.mongodb;

import com.ibm.build2manage.jpa.CustomIdPersistable;
import com.ibm.build2manage.jpa.IdEntity;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import java.util.UUID;

class IdGeneratorTest {

    @Test
    void shouldCreateUUID() {
        CustomIdPersistable<UUID> original = new IdEntity<>(null);
        CustomIdPersistable<UUID> modified = IdGenerator.UUID.onBeforeConvert(original, "unit");
        Assertions.assertSame(original, modified);
        Assertions.assertNotNull(modified.getId());
    }

    @Test
    void shouldKeepUUID() {
        UUID initial = UUID.randomUUID();
        CustomIdPersistable<UUID> original = new IdEntity<>(initial);
        CustomIdPersistable<UUID> modified = IdGenerator.UUID.onBeforeConvert(original, "unit");
        Assertions.assertSame(original, modified);
        Assertions.assertSame(initial, modified.getId());
    }

}