package com.ibm.build2manage.jpa;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class IdEntity<T> implements CustomIdPersistable<T> {

    private T id;
}
