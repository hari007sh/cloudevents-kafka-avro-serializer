package com.ibm.build2manage.jpa;

import org.junit.jupiter.api.Test;

class JpaControllerAdviceTest {

    private static final JpaControllerAdvice UNDER_TEST = new JpaControllerAdvice();

    @Test
    void shouldNotThrowException() {
        UNDER_TEST.preconditionFailed(new TagMismatchException(new TaggedEntity<>("1"), new TaggedEntity<>("2")));
    }


}