package com.ibm.build2manage.jpa.mongodb;

import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.mongodb.repository.config.EnableMongoRepositories;

import java.time.OffsetDateTime;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.assertEquals;

@EnableAutoConfiguration
@EnableMongoRepositories
@SpringBootTest(classes = MongoJpaAutoConfiguration.class, properties = {
        "spring.mongodb.embedded.version=4.0.12"
})
class OffsetDateTimeCodecIT {

    @Autowired
    private TestRepo repo;

    @ValueSource(strings = {
            "2022-12-19T15:40:00.00Z",
            "2022-12-19T10:40:00.00-05:00",
            "2022-07-02T09:01:02.00-04:00"
    })
    @ParameterizedTest
    public void test(String date) {
        UUID id = UUID.randomUUID();
        OffsetDateTime today = OffsetDateTime.parse(date);
        repo.save(new TestBean(id, "123456", today));
        assertEquals(today, repo.findById(id).orElseThrow().getTime());
    }

}