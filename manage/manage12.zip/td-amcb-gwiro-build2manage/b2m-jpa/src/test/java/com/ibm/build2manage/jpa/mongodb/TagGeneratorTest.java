package com.ibm.build2manage.jpa.mongodb;

import com.ibm.build2manage.jpa.TaggedEntity;
import com.ibm.build2manage.jpa.TaggedPersistable;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;

class TagGeneratorTest {

    @ParameterizedTest
    @CsvSource({
            ",1",
            "0,1",
            "1,2"
    })
    void shouldIncrementRevision(Integer initial, Integer expected) {
        TaggedEntity<Integer> original = new TaggedEntity<>(initial);
        TaggedPersistable<Integer> modified = TagGenerator.REVISION.onBeforeConvert(original, "unit");
        Assertions.assertSame(original, modified);
        Assertions.assertEquals(expected, modified.getTag());
    }


}