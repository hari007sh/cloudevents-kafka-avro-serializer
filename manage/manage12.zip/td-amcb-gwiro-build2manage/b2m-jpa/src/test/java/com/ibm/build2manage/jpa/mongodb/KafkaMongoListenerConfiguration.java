package com.ibm.build2manage.jpa.mongodb;

import com.mongodb.MongoClientSettings;
import org.bson.codecs.configuration.CodecRegistries;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.mongo.MongoClientSettingsBuilderCustomizer;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.core.KafkaTemplate;

@Configuration
public class KafkaMongoListenerConfiguration {

    @Bean
    public KafkaMongoListener mongoListener(KafkaTemplate<String, Object> kafka, @Value("${unit.topic}") String topic) {
        KafkaMongoListener listener = new KafkaMongoListener(kafka);
        listener.register(TestBean.class, TestBean2.class, topic, r -> new TestBean2(r.getId(), r.getField1(), null));
        return listener;
    }
}
