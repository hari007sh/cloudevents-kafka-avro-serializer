package com.ibm.build2manage.jpa.mongodb;

import org.apache.kafka.clients.producer.ProducerRecord;
import org.bson.Document;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.MethodSource;
import org.mockito.*;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.data.mongodb.core.mapping.event.AfterDeleteEvent;
import org.springframework.data.mongodb.core.mapping.event.AfterSaveEvent;
import org.springframework.kafka.core.KafkaTemplate;

import java.util.UUID;

import static org.junit.jupiter.api.Assertions.*;

@ExtendWith(MockitoExtension.class)
class KafkaMongoListenerTest {

    private static final String TOPIC = UUID.randomUUID().toString();
    private static final String TOPIC2 = UUID.randomUUID().toString();

    @Mock
    private KafkaTemplate<String, Object> kafka;

    @Mock
    private Document document;

    @InjectMocks
    private KafkaMongoListener underTest;

    @Captor
    private ArgumentCaptor<ProducerRecord<String, Object>> msg;

    @BeforeEach
    void init() {
        underTest.register(TestBean.class, TestBean2.class, TOPIC, r -> new TestBean2(r.getId(), r.getField1(), null));
        underTest.register(TestBean2.class, TestBean.class, TOPIC2, r -> new TestBean(r.getId(), r.getField1(), null));
    }

    private void assertMessage(String id, String topic, String type, Object value) {
        Mockito.verify(kafka).send(msg.capture());
        ProducerRecord<String, Object> actual = msg.getValue();
        assertEquals(topic, actual.topic());
        assertEquals(id, actual.key());
        assertEquals(id, new String(actual.headers().lastHeader("id").value()));
        assertEquals(value, actual.value());
        assertEquals(type, new String(actual.headers().lastHeader("type").value()));
    }

    static Object[][] testCases() {
        UUID id = UUID.randomUUID();
        String other = UUID.randomUUID().toString();
        return new Object[][]{
                {id.toString(), TOPIC, new TestBean(id, other, null), new TestBean2(id, other, null)},
                {id.toString(), TOPIC2, new TestBean2(id, other, null), new TestBean(id, other, null)}
        };
    }

    @ParameterizedTest
    @MethodSource("testCases")
    void shouldSupportUpdateWithMultipleTypes(String id, String topic, Object source, Object expected) {
        Mockito.when(document.get("_id")).thenReturn(id);
        underTest.onAfterSave(new AfterSaveEvent<>(source, document, "irrelevant"));
        assertMessage(id, topic, expected.getClass().getCanonicalName(), expected);
    }

    @ParameterizedTest
    @MethodSource("testCases")
    @SuppressWarnings("unchecked")
    void shouldSupportDeleteWithMultipleTypes(String id, String topic, Object source, Object expected) {
        Mockito.when(document.get("_id")).thenReturn(id);
        underTest.onAfterDelete(new AfterDeleteEvent<>(document, (Class<Object>) source.getClass(), "unused"));
        assertMessage(id, topic, expected.getClass().getCanonicalName(), null);
    }

    @Test
    void redefiningMappingShouldFail() {
        assertThrows(IllegalArgumentException.class, () -> underTest.register(TestBean.class, TestBean.class, TOPIC, r -> r));
    }
}