package com.ibm.build2manage.jpa.mongodb;

import lombok.AllArgsConstructor;
import lombok.Data;

import java.time.OffsetDateTime;
import java.util.UUID;

@Data
@AllArgsConstructor
public class TestBean2 {

    private UUID id;

    private String field1;

    private OffsetDateTime time;
}
