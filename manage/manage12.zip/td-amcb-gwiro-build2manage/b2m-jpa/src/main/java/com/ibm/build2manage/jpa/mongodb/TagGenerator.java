package com.ibm.build2manage.jpa.mongodb;

import com.ibm.build2manage.jpa.TaggedPersistable;
import lombok.RequiredArgsConstructor;
import org.springframework.core.Ordered;
import org.springframework.data.mongodb.core.mapping.event.BeforeConvertCallback;

import java.util.function.Function;

@RequiredArgsConstructor
public class TagGenerator<T> implements BeforeConvertCallback<TaggedPersistable<T>>, Ordered {

    public static final TagGenerator<Integer> REVISION = new TagGenerator<>(e ->
            e.hasTag() ? e.getTag() + 1 : 1
    );
    
    private final Function<TaggedPersistable<T>, T> supplier;

    @Override
    public int getOrder() {
        // Execute after any id generator
        return IdGenerator.ORDER + 1;
    }

    @Override
    public TaggedPersistable<T> onBeforeConvert(TaggedPersistable<T> entity, String collection) {
        entity.setTag(supplier.apply(entity));
        return entity;
    }
}
