package com.ibm.build2manage.jpa;

import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.bind.annotation.ControllerAdvice;

@Configuration
public class JpaAutoConfiguration {

    @Bean
    @ConditionalOnClass(ControllerAdvice.class)
    public JpaControllerAdvice jpaControllerAdvice() {
        return new JpaControllerAdvice();
    }

}
