package com.ibm.build2manage.jpa;

import org.springframework.lang.NonNull;

/**
 * Exception thrown when an operation fails due to a mismatch between the database tag and the expected tag.
 */
public class TagMismatchException extends RuntimeException {

    /**
     * Constructor.
     *
     * @param actual the actual persisted object
     * @param update the object we are trying to persist
     * @param <T> the type of tag
     */
    public <T> TagMismatchException(@NonNull TaggedPersistable<T> actual, @NonNull TaggedPersistable<T> update) {
        super("Invalid tag detected for entity. Persisted tag is <" + actual.getTag() + "> but update was expecting <" + update.getTag() + '>');
    }

}
