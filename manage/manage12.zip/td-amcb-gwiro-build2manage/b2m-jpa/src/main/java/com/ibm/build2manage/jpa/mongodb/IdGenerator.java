package com.ibm.build2manage.jpa.mongodb;

import com.ibm.build2manage.jpa.CustomIdPersistable;
import lombok.RequiredArgsConstructor;
import org.springframework.core.Ordered;
import org.springframework.data.mongodb.core.mapping.event.BeforeConvertCallback;

import java.util.function.Supplier;

/**
 * Implementation of {@link BeforeConvertCallback} that allow to use custom ID with MongoDB. By default, spring is
 * unable to generate some type of ID (e.g. UUID). Using this bean, we are able to generate such identifier
 * before the entity is persisted.
 * <p>
 * This implementation is thread safe as long as the underlying ID supplier is also thread safe.
 *
 * @param <I> the type of identifier
 *
 * @see <a href="https://stackoverflow.com/a/60719710">Slashdot post</a>
 */
@RequiredArgsConstructor
public class IdGenerator<I> implements BeforeConvertCallback<CustomIdPersistable<I>>, Ordered {

    /**
     * Implementation of {@link IdGenerator} returning UUID. Thread safe.
     */
    public static final IdGenerator<java.util.UUID> UUID = new IdGenerator<>(java.util.UUID::randomUUID);

    // Make sure this is executed after AuditingEntityCallback
    static final int ORDER = 101;

    private final Supplier<I> id;

    @Override
    public int getOrder() {
        return ORDER;
    }

    @Override
    public CustomIdPersistable<I> onBeforeConvert(CustomIdPersistable<I> entity, String collection) {
        if (entity.isNew()) {
            entity.setId(id.get());
        }
        return entity;
    }
}
