package com.ibm.build2manage.jpa;

import org.springframework.data.annotation.Transient;
import org.springframework.lang.NonNull;

/**
 * Interface specifying that an entity is versioned.
 *
 * @param <T> the type of tag information
 */
public interface TaggedPersistable<T> {

    T getTag();

    void setTag(@NonNull T tag);

    @Transient
    default boolean hasTag() {
        return getTag() != null;
    }
}
