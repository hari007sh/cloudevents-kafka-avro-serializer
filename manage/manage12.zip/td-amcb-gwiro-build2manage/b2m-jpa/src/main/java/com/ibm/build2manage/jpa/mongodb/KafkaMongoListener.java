package com.ibm.build2manage.jpa.mongodb;

import lombok.RequiredArgsConstructor;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.bson.Document;
import org.springframework.data.mongodb.core.mapping.event.AbstractMongoEventListener;
import org.springframework.data.mongodb.core.mapping.event.AfterDeleteEvent;
import org.springframework.data.mongodb.core.mapping.event.AfterSaveEvent;
import org.springframework.data.mongodb.core.mapping.event.MongoMappingEvent;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.lang.NonNull;

import java.util.*;
import java.util.function.Function;

/**
 * A {@link KafkaMongoListener} is an implementation ob {@link AbstractMongoEventListener} that automatically pushes the
 * changes from MongoDB to a kafka topic.
 */
@RequiredArgsConstructor
public class KafkaMongoListener extends AbstractMongoEventListener<Object> {

    private final KafkaTemplate<String, Object> kafka;

    private final List<Map.Entry<Class<?>, Mapping<?, ?>>> dbClasses = new ArrayList<>(0);

    private Optional<? extends Mapping<?, ?>> getMapping(Class<?> dbClass) {
        return dbClasses.stream()
                .filter(e -> e.getKey().equals(dbClass))
                .map(Map.Entry::getValue)
                .findFirst();
    }

    public synchronized <DB, DTO> void register(Class<DB> dbClass, Class<DTO> dtoClass, String topic, Function<DB, DTO> toDto) {
        if (getMapping(dbClass).isPresent()) {
            throw new IllegalArgumentException(dbClass + " is already registered with this instance");
        }
        dbClasses.add(new AbstractMap.SimpleImmutableEntry<>(dbClass, new Mapping<>(dtoClass, topic, toDto)));
    }

    private void send(Mapping<Object, Object> mapping, MongoMappingEvent<?> event, Object value) {
        Document document = Objects.requireNonNull(event.getDocument(), "Unable to retrieve document");
        String key = Objects.requireNonNull(document.get("_id"), "Unable to retrieve id").toString();
        ProducerRecord<String, Object> result = new ProducerRecord<>(mapping.topic, key, value == null ? null : mapping.toDto.apply(value));
        result.headers()
                .add("id", key.getBytes())
                .add("type", mapping.dtoClass.getCanonicalName().getBytes());
        kafka.send(result);
    }

    @Override
    @SuppressWarnings("unchecked")
    public void onAfterSave(AfterSaveEvent<Object> event) {
        getMapping(event.getSource().getClass()).ifPresent(value -> send((Mapping<Object, Object>) value, event, event.getSource()));
    }

    @Override
    @SuppressWarnings("unchecked")
    public void onAfterDelete(AfterDeleteEvent<Object> event) {
        getMapping(event.getType()).ifPresent(value -> send((Mapping<Object, Object>) value, event, null));
    }


    @RequiredArgsConstructor
    private static class Mapping<DB, DTO> {
        @NonNull
        private final Class<DTO> dtoClass;
        @NonNull
        public final String topic;
        @NonNull
        private final Function<DB, DTO> toDto;
    }
}
