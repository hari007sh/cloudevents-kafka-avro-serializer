package com.ibm.build2manage.jpa.mongodb;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.ResourceLoader;
import org.springframework.core.io.support.ResourcePatternUtils;
import org.springframework.data.mongodb.core.convert.MongoCustomConversions;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.repository.init.Jackson2RepositoryPopulatorFactoryBean;

import java.io.IOException;
import java.util.List;

@Configuration
@ConditionalOnClass({MongoRepository.class})
public class MongoJpaAutoConfiguration {

    @Bean
    @ConditionalOnClass(Jackson2RepositoryPopulatorFactoryBean.class)
    @ConditionalOnProperty(name = "b2m.jpa.mongo.preload")
    public Jackson2RepositoryPopulatorFactoryBean mongoPopulator(ResourceLoader loader, @Value("${b2m.jpa.mongo.preload}") String pattern) throws IOException {
        Jackson2RepositoryPopulatorFactoryBean bean = new Jackson2RepositoryPopulatorFactoryBean();
        bean.setResources(ResourcePatternUtils.getResourcePatternResolver(loader).getResources("classpath*:" + pattern));
        return bean;
    }

    @Bean
    @ConditionalOnMissingBean(MongoCustomConversions.class)
    MongoCustomConversions conversions() {
        return new MongoCustomConversions(List.of(
                new MongoOffsetDateTimeWriter(),
                new MongoOffsetDateTimeReader()
        ));
    }
}
