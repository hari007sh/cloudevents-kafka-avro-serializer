package com.ibm.build2manage.jpa;

import java.util.UUID;

/**
 * Interface removing generics for a UUID based {@link CustomIdPersistable}.
 */
public interface UUIDPersistable extends CustomIdPersistable<UUID> {
}
