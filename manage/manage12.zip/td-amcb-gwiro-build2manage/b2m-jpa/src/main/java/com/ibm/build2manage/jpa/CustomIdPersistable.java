package com.ibm.build2manage.jpa;

import org.springframework.data.annotation.Transient;
import org.springframework.data.domain.Persistable;
import org.springframework.lang.NonNull;

/**
 * Interface specifying that a {@link Persistable} uses a custom ID that cannot be generated automatically by Spring.
 *
 * @param <I> the type of id
 */
public interface CustomIdPersistable<I> extends Persistable<I> {

    void setId(@NonNull I id);

    @Override
    @Transient
    default boolean isNew() {
        return getId() == null;
    }
}
