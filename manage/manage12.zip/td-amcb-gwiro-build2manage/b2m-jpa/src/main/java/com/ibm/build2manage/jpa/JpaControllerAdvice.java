package com.ibm.build2manage.jpa;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.dao.DataAccessException;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;

/**
 * Class responsible for managing common JPA exceptions and returns the appropriate error.
 */
@ControllerAdvice
public class JpaControllerAdvice {

    private static final Logger LOG = LogManager.getLogger(JpaControllerAdvice.class);

    /**
     * Returns 412 - Precondition Failed when a tag mismatch is detected.
     *
     * @param ex the exception
     */
    @ExceptionHandler(TagMismatchException.class)
    @ResponseStatus(HttpStatus.PRECONDITION_FAILED)
    public void preconditionFailed(TagMismatchException ex) {
        LOG.atWarn().withThrowable(ex).log("Precondition failed: {}", ex);
    }

    @ExceptionHandler(DataAccessException.class)
    public void dbNetworkError(DataAccessException ex) {
        LOG.atError().withThrowable(ex).log("Error contacting db: {}", ex);
    }
}
