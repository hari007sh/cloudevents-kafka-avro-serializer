package com.ibm.build2manage.errors;

import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;

import java.util.Locale;

import static org.junit.jupiter.api.Assertions.*;

class ErrorSourceTest {

    @ParameterizedTest
    @CsvSource({
            "12,12 - this is the error param: something",
            "11,11"
    })
    void testNoDefaultMessage(int code, String expected) {
        SpringErrorSource underTest = new SpringErrorSource(Locale.ENGLISH, "messages/errors");
        assertEquals(expected, underTest.get(code, null, "something"));
    }

    @ParameterizedTest
    @CsvSource({
            "12,12 - this is the error param: something",
            "11,11 - default"
    })
    void testWithDefaultMessage(int code, String expected) {
        SpringErrorSource underTest = new SpringErrorSource(Locale.ENGLISH, "messages/errors");
        assertEquals(expected, underTest.get(code, "default", "something"));
    }

}