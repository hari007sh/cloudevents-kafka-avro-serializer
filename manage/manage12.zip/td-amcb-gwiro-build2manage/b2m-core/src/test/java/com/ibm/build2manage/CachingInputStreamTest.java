package com.ibm.build2manage;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.mockito.Mockito;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;

import static org.junit.jupiter.api.Assertions.*;

@ExtendWith(MockitoExtension.class)
class CachingInputStreamTest {

    @Spy
    private ByteArrayInputStream source = new ByteArrayInputStream("123456789".getBytes(StandardCharsets.UTF_8));


    @CsvSource({
            "5,3,3,123",
            "5,15,9,12345",
            "15,15,9,123456789"
    })
    @ParameterizedTest
    public void readAndFillCache(int max, int skip, int read, String expected) throws IOException {
        CachingInputStream underTest = new CachingInputStream(source, max);
        // We use skip as this will do multiple read
        assertEquals(read, underTest.skip(skip));
        assertArrayEquals(expected.getBytes(StandardCharsets.UTF_8), underTest.getCache());
    }

    @CsvSource({
            "5,0,12345,49",
            "5,3,12345,52",
            "15,15,123456789,-1"
    })
    @ParameterizedTest
    public void fillCache(int max, int skip, String expected, int nextRead) throws IOException {
        CachingInputStream underTest = new CachingInputStream(source, max);
        // We use skip as this will do multiple read
        underTest.skip(skip);
        assertArrayEquals(expected.getBytes(StandardCharsets.UTF_8), underTest.fillAndGet());
        assertEquals(nextRead, underTest.read());
    }

    @Test
    public void resetWhileInCache() throws IOException {
        CachingInputStream underTest = new CachingInputStream(source, 6);
        // We use skip as this will do multiple read
        assertEquals(5, underTest.skip(5));
        assertArrayEquals("12345".getBytes(StandardCharsets.UTF_8), underTest.getCache());
        underTest.reset();
        byte[] tmp = new byte[9];
        assertEquals(9, underTest.read(tmp));
        assertArrayEquals("123456789".getBytes(StandardCharsets.UTF_8), tmp);
    }

    @Test
    public void resetWhileNotInCache() throws IOException {
        CachingInputStream underTest = new CachingInputStream(source, 5);
        // We use skip as this will do multiple read
        assertEquals(9, underTest.skip(25));
        assertThrows(IOException.class, underTest::reset);
    }

    @Test
    public void testClose() throws IOException {
        CachingInputStream underTest = new CachingInputStream(source);
        // We use skip as this will do multiple read
        assertEquals(5, underTest.skip(5));
        assertArrayEquals("12345".getBytes(StandardCharsets.UTF_8), underTest.getCache());
        underTest.close();

        // close source stream and cache still available
        Mockito.verify(source).close();
        assertArrayEquals("12345".getBytes(StandardCharsets.UTF_8), underTest.getCache());
    }
}