package com.ibm.build2manage;

import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.MethodSource;
import org.mockito.Mockito;

import java.util.Objects;
import java.util.function.Function;

import static org.junit.jupiter.api.Assertions.*;

class ArrayUtilsTest {

    @SuppressWarnings("unchecked")
    static Object[][] testToString() {
        Object o1 = new Object();
        Object o2 = new Object();
        Function<Object, String> fct = Mockito.mock(Function.class);
        Mockito.when(fct.apply(o1)).thenReturn("o1");
        Mockito.when(fct.apply(o2)).thenReturn("o2");
        return new Object[][]{
                {null, Function.identity(), "null"},
                {new String[0], Function.identity(), "[]"},
                {new String[]{"item1"}, Function.identity(), "[item1]"},
                {new String[]{"item1", "item2"}, Function.identity(), "[item1,item2]"},
                {new Object[]{o1, o2}, fct, "[o1,o2]"},
        };
    }

    @ParameterizedTest
    @MethodSource
    void testToString(Object[] array, Function<Object, String> fct, String expected) {
        assertEquals(expected, ArrayUtils.toString(array, fct));
    }

}