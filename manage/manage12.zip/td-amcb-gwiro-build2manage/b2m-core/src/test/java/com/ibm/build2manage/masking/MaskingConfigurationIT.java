package com.ibm.build2manage.masking;

import com.ibm.build2manage.Build2ManageAutoConfiguration;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.util.ReflectionTestUtils;

import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Test validating the default configuration where masking is enable by default but users can specify some keys to left
 * unmasked.
 */
@EnableAutoConfiguration
@SpringBootTest(classes = Build2ManageAutoConfiguration.class, properties = {
        "b2m.masking.something=false",
        "b2m.masking.something.else=false"
})
class MaskingConfigurationIT {

    @Autowired
    private MaskingConfiguration underTest;

    @Test
    void defaultIsFalseWhenNotProvided() {
        assertEquals(true, ReflectionTestUtils.getField(underTest, "defMasking"));
    }

    @Test
    @SuppressWarnings("unchecked")
    void configurationSupported() {
        Object actual = ReflectionTestUtils.getField(underTest, "masking");
        assertTrue(actual instanceof Map);
        assertEquals(false, ((Map<String, Boolean>) actual).get("something"));
    }

    @Test
    @SuppressWarnings("unchecked")
    void configurationSupportsMultiLevel() {
        Object actual = ReflectionTestUtils.getField(underTest, "masking");
        assertTrue(actual instanceof Map);
        assertEquals(false, ((Map<String, Boolean>) actual).get("something.else"));
    }
}