package com.ibm.build2manage.encoding;

import static com.ibm.build2manage.encoding.EncodingFactoryTest.ENCODER;

public class EncoderOnly extends EncodingFormat<Object> {

    static final String NAME = "encoder";

    public EncoderOnly() {
        super(NAME, ENCODER, null);
    }
}
