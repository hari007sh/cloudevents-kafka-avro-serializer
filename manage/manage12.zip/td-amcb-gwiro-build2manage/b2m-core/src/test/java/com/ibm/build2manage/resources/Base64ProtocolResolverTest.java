package com.ibm.build2manage.resources;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.junit.jupiter.params.provider.MethodSource;
import org.junit.jupiter.params.provider.ValueSource;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.core.io.FileSystemResource;
import org.springframework.core.io.Resource;
import org.springframework.core.io.ResourceLoader;
import org.springframework.util.FileCopyUtils;

import java.io.IOException;
import java.util.Base64;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.*;

@ExtendWith(MockitoExtension.class)
class Base64ProtocolResolverTest {

    private static final Base64ProtocolResolver UNDER_TEST = new Base64ProtocolResolver(null, null);

    @Mock
    private ResourceLoader loader;

    @ValueSource(strings = {"\r","\f","\n", " ", "     ", "\t", ""})
    @ParameterizedTest
    void withPrefix(String separator) throws IOException {
        // Leave it here so we can distinguish the tests, which is not possible with JUnit
        System.out.println("Testing with separator '" + separator + "'");
        String expected = UUID.randomUUID().toString();
        String base64 = Base64.getEncoder().encodeToString(expected.getBytes());
        Resource actual = UNDER_TEST.resolve("base64:" + base64.substring(0, 10) + separator + base64.substring(10), loader);
        assertTrue(actual instanceof FileSystemResource);
        byte[] tmp = FileCopyUtils.copyToByteArray(actual.getFile());
        assertEquals(expected, new String(tmp));
        Mockito.verifyNoInteractions(loader);
    }

    @Test
    void noPrefix() {
        String expected = UUID.randomUUID().toString();
        Resource actual = UNDER_TEST.resolve(Base64.getEncoder().encodeToString(expected.getBytes()), loader);
        assertNull(actual);
        Mockito.verifyNoInteractions(loader);
    }
}