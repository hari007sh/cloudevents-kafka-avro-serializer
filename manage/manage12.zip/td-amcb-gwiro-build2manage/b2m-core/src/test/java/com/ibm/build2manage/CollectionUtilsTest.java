package com.ibm.build2manage;

import lombok.NonNull;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.MethodSource;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

import static java.util.Collections.emptyList;
import static org.junit.jupiter.api.Assertions.assertEquals;

class CollectionUtilsTest {

    static Object[][] testDiff() {
        return new Object[][]{
                {Arrays.asList(1, 2, 3, 4, 5), Arrays.asList(4, 5, 6),
                        new ArrayList<>(), new ArrayList<>(), List.of(6), Arrays.asList(1, 2, 3)},
                {Arrays.asList(1, 2, 3, 4, 5), Arrays.asList(1, 2, 3, 4, 5),
                        new ArrayList<>(), new ArrayList<>(), Collections.emptyList(), Collections.emptyList()},
                {Arrays.asList("a", "b", "c"), Collections.emptyList(),
                        new ArrayList<>(), new ArrayList<>(), Collections.emptyList(), Arrays.asList("a", "b", "c")},
                {null, Arrays.asList("a", "b", "c"),
                        new ArrayList<>(), new ArrayList<>(), Arrays.asList("a", "b", "c"), Collections.emptyList()}
        };
    }

    @ParameterizedTest
    @MethodSource
    void testDiff(List<Object> original, List<Object> modified, @NonNull List<Object> added,
                  @NonNull List<Object> removed, List<Object> expectedAdded, List<Object> expectedRemoved) {
        CollectionUtils.Diff(original, modified, added, removed);
        assertEquals(added, expectedAdded);
        assertEquals(removed, expectedRemoved);
    }

    static Object[][] stream() {
        return new Object[][]{
                {null, emptyList()},
                {List.of(), emptyList()},
                {List.of("string"), List.of("string")},
                {List.of("string", "filtered"), List.of("string")},
                {List.of("string", "string2"), List.of("string", "string2")},
        };
    }

    @ParameterizedTest
    @MethodSource
    void stream(List<String> ids, List<String> expected) {
        assertEquals(expected, CollectionUtils.stream(ids, c -> !"filtered".equals(c)).collect(Collectors.toList()));
    }
}