package com.ibm.build2manage.masking;

import com.ibm.build2manage.Build2ManageAutoConfiguration;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.util.ReflectionTestUtils;

import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Test validating the reverse behavior where masking is disabled by default but users can specify some keys to mask.
 */
@EnableAutoConfiguration
@SpringBootTest(classes = Build2ManageAutoConfiguration.class, properties = {
        "b2m.masking.default=false",
        "b2m.masking.something=true",
        "b2m.masking.something.else=true"
})
class MaskingConfigurationReverseLogicIT {

    @Autowired
    private MaskingConfiguration underTest;

    @Test
    void defaultIsOverridable() {
        assertEquals(false, ReflectionTestUtils.getField(underTest, "defMasking"));
    }

    @Test
    @SuppressWarnings("unchecked")
    void configurationSupported() {
        Object actual = ReflectionTestUtils.getField(underTest, "masking");
        assertTrue(actual instanceof Map);
        assertEquals(true, ((Map<String, Boolean>) actual).get("something"));
    }

    @Test
    @SuppressWarnings("unchecked")
    void configurationSupportsMultiLevel() {
        Object actual = ReflectionTestUtils.getField(underTest, "masking");
        assertTrue(actual instanceof Map);
        assertEquals(true, ((Map<String, Boolean>) actual).get("something.else"));
    }
}