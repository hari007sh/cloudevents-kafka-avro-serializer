package com.ibm.build2manage.resources;

import com.ibm.build2manage.Build2ManageAutoConfiguration;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.core.io.FileSystemResource;
import org.springframework.core.io.Resource;
import org.springframework.core.io.ResourceLoader;
import org.springframework.util.FileCopyUtils;

import java.io.IOException;
import java.util.Base64;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.*;

@EnableAutoConfiguration
@SpringBootTest(classes = Build2ManageAutoConfiguration.class, properties = {
        "base64.test=base64:dGhpcyBpcyBhIHRlc3Q="
})
class Base64ProtocolResolverIT {

    @Value("${base64.test}")
    private Resource underTest;

    @Test
    void fileShouldExists() throws IOException {
        assertNotNull(underTest);
        byte[] tmp = FileCopyUtils.copyToByteArray(underTest.getFile());
        assertEquals("this is a test", new String(tmp));
    }
}