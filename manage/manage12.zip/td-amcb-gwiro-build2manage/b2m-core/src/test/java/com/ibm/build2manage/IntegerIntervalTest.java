package com.ibm.build2manage;

import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;

import static org.junit.jupiter.api.Assertions.*;

class IntegerIntervalTest {

    @ParameterizedTest
    @CsvSource({
            "100-200,100,200",
            "[100-200,100,200",
            "]100-200,101,200",
            "(100-200,101,200",
            "100-200],100,200",
            "100-200[,100,199",
            "100-200),100,199",
            "[100-200[,100,199",
            "[100-200),100,199",
            "[100-200],100,200",
            "]100-200[,101,199",
            "(100-200[,101,199",
            "]100-200),101,199",
            "(100-200),101,199",
            "]100-200],101,200",
            "(100-200],101,200"
    })
    void testContainsLong(String str, int min, int max) {
        IntegerInterval range = IntegerInterval.fromString(str);
        assertFalse(range.contains(min - 1), String.valueOf(min - 1));
        assertEquals(min, range.getFrom());
        assertEquals(max, range.getTo());
        for (int i = min; i <= max; i++)
            assertTrue(range.contains(i), String.valueOf(i));
        assertFalse(range.contains(max + 1), String.valueOf(max + 1));
    }

    @ParameterizedTest
    @CsvSource({
            "100-200,100,200",
            "[100-200,100,200",
            "]100-200,101,200",
            "(100-200,101,200",
            "100-200],100,200",
            "100-200[,100,199",
            "100-200),100,199",
            "[100-200[,100,199",
            "[100-200),100,199",
            "[100-200],100,200",
            "]100-200[,101,199",
            "(100-200[,101,199",
            "]100-200),101,199",
            "(100-200),101,199",
            "]100-200],101,200",
            "(100-200],101,200"
    })
    void testContainsDouble(String str, double min, double max) {
        IntegerInterval range = IntegerInterval.fromString(str);
        assertFalse(range.contains(min - 0.001), String.valueOf(min - 0.001));
        for (double i = min; i <= max; i += 0.1)
            assertTrue(range.contains(i), String.valueOf(i));
        assertFalse(range.contains(max + 0.001), String.valueOf(max + 0.001));
    }

}