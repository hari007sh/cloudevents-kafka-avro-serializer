package com.ibm.build2manage.resources;

import org.assertj.core.util.Streams;
import org.awaitility.Awaitility;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.core.io.FileSystemResource;
import org.springframework.core.io.Resource;
import org.springframework.test.util.ReflectionTestUtils;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.WatchService;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

class FileSystemListableResourceTest {

    private static File parent;

    private static final List<File> files = new ArrayList<>(10);

    @BeforeAll
    static void createFolder() throws IOException {
        parent = Files.createTempDirectory("unit-" + UUID.randomUUID()).toFile();
        for (int i = 0; i < 10; i++) {
            createTmp();
        }
    }

    private static File createTmp() throws IOException {
        File file = File.createTempFile("something", ".tmp", parent);
        files.add(file);
        return file;
    }

    @AfterAll
    static void deleteAll() {
        for (File f : files) {
            f.delete();
        }
        parent.delete();
    }

    @Test
    synchronized void iterator() throws IOException {
        files.sort(null);
        ListableResource r = ListableResource.of(new FileSystemResource(parent));
        int i = 0;
        List<String> actual = Streams.stream(r.iterator()).sorted().collect(Collectors.toList());
        for (String s : actual) {
            assertEquals(files.get(i).getName(), s, "File " + i);
            i++;
        }
    }

    @Test
    void stopWatchingIsNullSafe() throws IOException {
        ListableResource r = ListableResource.of(new FileSystemListableResource(parent));
        r.stopWatching();
    }

    @Test
    synchronized void watch() throws IOException {
        List<Resource> resources = new ArrayList<>();
        ResourceProcessor consumer = Mockito.mock(ResourceProcessor.class, i -> {
            resources.add(i.getArgument(0, Resource.class));
            return null;
        });

        ListableResource r = ListableResource.of(new FileSystemResource(parent));
        r.watch(consumer);
        // Nothing called before
        Mockito.verifyNoInteractions(consumer);
        List<String> expected = new ArrayList<>(10);
        for (int i = 0; i < 10; i++) {
            expected.add(createTmp().getAbsolutePath());
        }
        Awaitility.await().atMost(30, TimeUnit.SECONDS).until(() -> resources.size() == 10);
        r.stopWatching();
        for (Resource s : resources) {
            assertTrue(expected.contains(s.getFile().getAbsolutePath()), s.toString());
        }
    }

    @Test
    synchronized void watchServiceClosedDuringProcessing() throws IOException, InterruptedException {
        ListableResource r = new FileSystemListableResource(parent);
        CountDownLatch ready = new CountDownLatch(1);
        CountDownLatch await = new CountDownLatch(1);
        ResourceProcessor consumer = Mockito.mock(ResourceProcessor.class, i -> {
            ready.countDown();
            await.await();
            return null;
        });

        r.watch(consumer);
        // Nothing called before
        Mockito.verifyNoInteractions(consumer);

        Thread t = (Thread) ReflectionTestUtils.getField(r,"t");
        WatchService service = (WatchService) ReflectionTestUtils.getField(r, "service");

        createTmp();

        // Wait for consumer to be in process. This means we can
        // invalidate the key.
        assertTrue(ready.await(30, TimeUnit.SECONDS));

        assertTrue(t.isAlive());
        service.close();

        await.countDown();

        Awaitility.await().atMost(30, TimeUnit.SECONDS).until(() -> !t.isAlive());
    }
}