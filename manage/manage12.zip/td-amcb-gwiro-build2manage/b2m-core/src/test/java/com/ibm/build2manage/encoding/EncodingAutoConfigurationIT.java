package com.ibm.build2manage.encoding;

import com.ibm.build2manage.Build2ManageAutoConfiguration;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.test.context.SpringBootTest;

import java.io.IOException;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.*;

@EnableAutoConfiguration
@SpringBootTest(classes = Build2ManageAutoConfiguration.class)
class EncodingAutoConfigurationIT {

    @Test
    void testJacksonEncodingFormat() throws IOException {
        TestBean expected = new TestBean(UUID.randomUUID().toString());
        byte[] encoded = (byte[]) EncodingFactory.getEncoder(JacksonEncodingAutoConfiguration.FORMAT).encode(expected, TestBean.class);
        Assertions.assertEquals(expected, EncodingFactory.getDecoder(JacksonEncodingAutoConfiguration.FORMAT).decode(encoded, TestBean.class));
    }

    @Test
    void testAvroEncodingFormat() throws IOException {
        AvroBean expected = AvroBean.newBuilder().setId(UUID.randomUUID().toString()).build();
        byte[] encoded = (byte[]) EncodingFactory.getEncoder(AvroEncodingAutoConfiguration.FORMAT).encode(expected, AvroBean.class);
        assertEquals(expected, EncodingFactory.getDecoder(AvroEncodingAutoConfiguration.FORMAT).decode(encoded, AvroBean.class));
    }

}