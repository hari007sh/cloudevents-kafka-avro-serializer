package com.ibm.build2manage.masking;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.MethodSource;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Map;

import static com.ibm.build2manage.masking.MaskingConfiguration.STARS;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;

@ExtendWith(MockitoExtension.class)
class DataMaskerTest {

    @Mock
    private EncodingStrategy strategy;

    private static final String UNMASKED = "unmasked";
    private static final String GRANULAR = "granular";
    private static final String UNMASKED_GRANULAR = UNMASKED + GRANULAR;

    private static final MaskingConfiguration MASK_CONFIG = new MaskingConfiguration(Map.of(
            "clear", false
    ));

    private static final DataMasker MASK = new DataMasker(MASK_CONFIG);

    private static final MaskingConfiguration CLEAR_CONFIG = new MaskingConfiguration(Map.of(
            "default", false,
            "mask", true
    ));

    private static final DataMasker CLEAR = new DataMasker(CLEAR_CONFIG);

    @BeforeEach
    void initStrategy() {
        Mockito.lenient().when(strategy.customMasking()).thenReturn(true);
        Mockito.lenient().when(strategy.mask(any())).thenReturn(GRANULAR);
        Mockito.lenient().when(strategy.encode(any())).thenReturn(UNMASKED_GRANULAR);
    }

    static Object[][] maskUC() {
        return new Object[][]{
                {"anything", STARS, UNMASKED},
                {"clear", UNMASKED, UNMASKED},
                {"mask", STARS, STARS}
        };
    }

    @Test
    void noKeyShouldUseDefaultConfiguration() {
        assertEquals(STARS, MASK.mask(UNMASKED), "Should returned a masked string");
        assertEquals(STARS, MASK.wrap(UNMASKED).toString(), "Should return a masked PI");
        assertEquals(UNMASKED, CLEAR.mask(UNMASKED), "Should return an unmasked string");
        assertEquals(UNMASKED, CLEAR.wrap(UNMASKED).toString(), "Should return an unmasked PI");
    }

    @ParameterizedTest
    @MethodSource("maskUC")
    void shouldUseKeyConfiguration(String key, String maskExpected, String clearExpected) {
        assertEquals(maskExpected, MASK.mask(UNMASKED, key), "Should return clear test depending on key");
        assertEquals(maskExpected, MASK.wrap(UNMASKED, key).toString(), "Should return clear PI depending on key");
        assertEquals(clearExpected, CLEAR.mask(UNMASKED, key), "Should mask depending on key");
        assertEquals(clearExpected, CLEAR.wrap(UNMASKED, key).toString(), "Should provide masked PI depending on key");
    }

    static Object[][] maskers() {
        return new Object[][]{
                {MASK, GRANULAR},
                {CLEAR, UNMASKED_GRANULAR}
        };
    }

    @ParameterizedTest
    @MethodSource("maskers")
    void noKeyMaskingShouldCallGranularStrategy(DataMasker masker, String expected) {
        assertEquals(expected, masker.mask(UNMASKED, strategy));
    }

    @ParameterizedTest
    @MethodSource("maskers")
    void noKeyPIShouldCallGranularStrategyOnToString(DataMasker masker, String expected) {
        DataMasker.EncodingObject wrappedObject = masker.wrap(UNMASKED, strategy);
        Mockito.verify(strategy, Mockito.atMostOnce()).customMasking();
        Mockito.verifyNoMoreInteractions(strategy);
        assertEquals(expected, wrappedObject.toString());
    }

    static Object[][] keyAndMaskers() {
        return new Object[][]{
                {"anything", MASK, GRANULAR},
                {"clear", MASK, UNMASKED_GRANULAR},
                {"mask", MASK, GRANULAR},
                {"anything", CLEAR, UNMASKED_GRANULAR},
                {"clear", CLEAR, UNMASKED_GRANULAR},
                {"mask", CLEAR, GRANULAR}
        };
    }

    @ParameterizedTest
    @MethodSource("keyAndMaskers")
    void withKeyProvidedShouldCallGranularStrategy(String key, DataMasker masker, String expected) {
        assertEquals(expected, masker.mask(UNMASKED, key, strategy));
    }

    @ParameterizedTest
    @MethodSource("keyAndMaskers")
    void withKeyPIShouldCallGranularStrategyOnToString(String key, DataMasker masker, String expected) {
        DataMasker.EncodingObject wrappedObject = masker.wrap(UNMASKED, key, strategy);
        Mockito.verify(strategy, Mockito.atMostOnce()).customMasking();
        Mockito.verifyNoMoreInteractions(strategy);
        assertEquals(expected, wrappedObject.toString());
    }
}