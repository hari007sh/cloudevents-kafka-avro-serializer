package com.ibm.build2manage.encoding;

import org.junit.jupiter.api.Test;

import java.io.UnsupportedEncodingException;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.*;


class EncodingFactoryTest {

    static Encoder<Object> ENCODER = new Encoder<>() {
        @Override
        public <T> Object encode(T source, Class<T> tClass) {
            return null;
        }
    };

    static Decoder<Object> DECODER = new Decoder<>() {
        @Override
        public <T> T decode(Object source, Class<T> tClass) {
            return null;
        }
    };

    @Test
    void unknownFormat() {
        String format = UUID.randomUUID().toString();
        assertEquals(format, assertThrows(UnsupportedEncodingException.class, () -> EncodingFactory.getEncoder(format)).getMessage());
        assertEquals(format, assertThrows(UnsupportedEncodingException.class, () -> EncodingFactory.getDecoder(format)).getMessage());
    }

    @Test
    void encoderOnly() throws UnsupportedEncodingException {
        assertSame(ENCODER, EncodingFactory.getEncoder(EncoderOnly.NAME));
        assertEquals(EncoderOnly.NAME, assertThrows(UnsupportedEncodingException.class, () -> EncodingFactory.getDecoder(EncoderOnly.NAME)).getMessage());
    }

    @Test
    void decoderOnly() throws UnsupportedEncodingException {
        assertEquals(DecoderOnly.NAME, assertThrows(UnsupportedEncodingException.class, () -> EncodingFactory.getEncoder(DecoderOnly.NAME)).getMessage());
        assertSame(DECODER, EncodingFactory.getDecoder(DecoderOnly.NAME));
    }

    @Test
    void bothDecoderAndEncoder() throws UnsupportedEncodingException {
        assertSame(ENCODER, EncodingFactory.getEncoder(BothInstances.NAME));
        assertSame(DECODER, EncodingFactory.getDecoder(BothInstances.NAME));
    }

}