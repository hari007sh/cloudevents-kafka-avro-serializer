package com.ibm.build2manage.masking;

import com.ibm.build2manage.Build2ManageAutoConfiguration;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.util.ReflectionTestUtils;

import static org.junit.jupiter.api.Assertions.assertEquals;

/**
 * Test starting a spring context when no properties are defined.
 */
@EnableAutoConfiguration
@SpringBootTest(classes = Build2ManageAutoConfiguration.class)
class NonConfiguredMaskingIT {

    @Autowired
    private MaskingConfiguration underTest;

    @Test
    void defaultIsFalseWhenNotProvided() {
        assertEquals(true, ReflectionTestUtils.getField(underTest, "defMasking"));
    }
}