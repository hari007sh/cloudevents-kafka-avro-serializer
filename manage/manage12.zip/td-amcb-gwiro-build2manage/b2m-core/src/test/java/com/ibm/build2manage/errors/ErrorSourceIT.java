package com.ibm.build2manage.errors;

import com.ibm.build2manage.Build2ManageAutoConfiguration;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.annotation.DirtiesContext;

import static org.junit.jupiter.api.Assertions.assertEquals;


@EnableAutoConfiguration
@SpringBootTest(classes = Build2ManageAutoConfiguration.class)
class ErrorSourceIT {

    @Autowired
    private SpringErrorSource errors;

    @Test
    void testNoDefaultMessage() {
        assertEquals("12 - this is the error param: something", errors.get(12, null, "something"));
    }

}