package com.ibm.build2manage.encoding;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import java.io.IOException;
import java.util.List;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.*;

class EncodingAutoConfigurationTest {

    @Test
    void testJacksonEncodingFormat() throws IOException {
        JacksonEncodingAutoConfiguration underTest = new JacksonEncodingAutoConfiguration();
        EncodingFormat<byte[]> tmp = underTest.kafkaJacksonEncoder();
        assertSame(tmp.getEncoder(), EncodingFactory.getEncoder(tmp.getName()));
        assertSame(tmp.getDecoder(), EncodingFactory.getDecoder(tmp.getName()));
        TestBean expected = new TestBean(UUID.randomUUID().toString());
        byte[] encoded = tmp.getEncoder().encode(expected, TestBean.class);
        Assertions.assertEquals(expected, tmp.getDecoder().decode(encoded, TestBean.class));
    }

    @Test
    void testJacksonEncodingFormatList() throws IOException {
        JacksonEncodingAutoConfiguration underTest = new JacksonEncodingAutoConfiguration();
        EncodingFormat<byte[]> tmp = underTest.kafkaJacksonEncoder();
        assertSame(tmp.getEncoder(), EncodingFactory.getEncoder(tmp.getName()));
        assertSame(tmp.getDecoder(), EncodingFactory.getDecoder(tmp.getName()));
        List<TestBean> expected = List.of(
                new TestBean(UUID.randomUUID().toString()),
                new TestBean(UUID.randomUUID().toString()));
        byte[] encoded = tmp.getEncoder().encodeList(expected, TestBean.class);
        List<TestBean> actual = tmp.getDecoder().decodeList(encoded, TestBean.class);
        Assertions.assertEquals(expected, actual);
    }

    @Test
    void testAvroEncodingFormat() throws IOException {
        AvroEncodingAutoConfiguration underTest = new AvroEncodingAutoConfiguration();
        EncodingFormat<byte[]> tmp = underTest.kafkaAvroEncoder();
        assertSame(tmp.getEncoder(), EncodingFactory.getEncoder(tmp.getName()));
        assertSame(tmp.getDecoder(), EncodingFactory.getDecoder(tmp.getName()));
        AvroBean expected = AvroBean.newBuilder().setId(UUID.randomUUID().toString()).build();
        byte[] encoded = tmp.getEncoder().encode(expected, AvroBean.class);
        assertEquals(expected, tmp.getDecoder().decode(encoded, AvroBean.class));
    }

}