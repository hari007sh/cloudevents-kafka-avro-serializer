package com.ibm.build2manage.encoding;

import static com.ibm.build2manage.encoding.EncodingFactoryTest.DECODER;
import static com.ibm.build2manage.encoding.EncodingFactoryTest.ENCODER;

public class BothInstances extends EncodingFormat<Object> {

    static final String NAME = "both";

    public BothInstances() {
        super(NAME, ENCODER, DECODER);
    }
}
