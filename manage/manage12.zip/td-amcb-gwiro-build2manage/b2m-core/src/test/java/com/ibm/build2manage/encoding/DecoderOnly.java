package com.ibm.build2manage.encoding;

import static com.ibm.build2manage.encoding.EncodingFactoryTest.DECODER;

public class DecoderOnly extends EncodingFormat<Object> {

    static final String NAME = "decoder";

    public DecoderOnly() {
        super(NAME, null, DECODER);
    }
}
