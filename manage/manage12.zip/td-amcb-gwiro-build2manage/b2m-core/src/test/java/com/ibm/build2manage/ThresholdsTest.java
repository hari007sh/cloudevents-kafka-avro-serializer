package com.ibm.build2manage;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class ThresholdsTest {

    @ParameterizedTest
    @CsvSource({
            "0.0,default",
            "5.0,5.0",
            "7.5,5.0",
            "10.0,10.0",
            "12.5,10.0",
            "15.0,15.0",
            "20.0,15.0",
    })
    void testThreshold(double value, String expected) {
        List<Double> thresholds = new ArrayList<>(Arrays.asList(5.0, 10.0, 15.0));
        Collections.shuffle(thresholds);
        Thresholds<String> underTest = new Thresholds<>("default", 3);
        for (Double d : thresholds) {
            underTest.with(d, String.valueOf(d));
        }
        assertEquals(expected, underTest.get(value));
    }

    @Test
    void replaceThreshold() {
        Thresholds<String> underTest = new Thresholds<>("default", 2)
                .with(5.0, "oldValue")
                .with(10.0, "tooHigh")
                .with(5.0, "newValue");

        assertEquals("default", underTest.get(0.0));
        assertEquals("newValue", underTest.get(5.0));
        assertEquals("tooHigh", underTest.get(10.0));
    }

}