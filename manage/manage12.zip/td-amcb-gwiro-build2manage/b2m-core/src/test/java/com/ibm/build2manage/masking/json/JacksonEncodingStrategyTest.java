package com.ibm.build2manage.masking.json;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ibm.build2manage.annotations.Mask;
import com.ibm.build2manage.masking.MaskingConfiguration;
import com.ibm.build2manage.masking.json.JacksonEncodingStrategy;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.MethodSource;

import java.util.Map;

import static com.ibm.build2manage.masking.MaskingConfiguration.STARS;
import static java.util.Collections.emptyMap;
import static org.junit.jupiter.api.Assertions.*;

class JacksonEncodingStrategyTest {

    private static final TestObject OBJ = new TestObject()
            .clear("clear")
            .masked("masked")
            .withKey("withKey")
            .child(new TestObject()
                    .clear("child.clear")
                    .masked("child.masked")
                    .withKey("child.withKey")
            );

    private static final String UNMASKED = "{\"clear\":\"clear\",\"masked\":\"masked\",\"withKey\":\"withKey\",\"child\":{\"clear\":\"child.clear\",\"masked\":\"child.masked\",\"withKey\":\"child.withKey\",\"child\":null}}";

    static Object[][] data() {
        return new Object[][]{
                {emptyMap(), "{\"clear\":\"clear\",\"masked\":\"" + STARS + "\",\"withKey\":\"" + STARS + "\",\"child\":\"" + STARS + "\"}"},
                {Map.of("default", false), UNMASKED},
                {Map.of("masked", false), "{\"clear\":\"clear\",\"masked\":\"masked\",\"withKey\":\"" + STARS + "\",\"child\":\"" + STARS + "\"}"},
                {Map.of("somethingelse", false), "{\"clear\":\"clear\",\"masked\":\"" + STARS + "\",\"withKey\":\"withKey\",\"child\":\"" + STARS + "\"}"},
                {Map.of("child", false), "{\"clear\":\"clear\",\"masked\":\"" + STARS + "\",\"withKey\":\"" + STARS + "\",\"child\":{\"clear\":\"child.clear\",\"masked\":\"" + STARS + "\",\"withKey\":\"" + STARS + "\",\"child\":null}}"},
        };
    }

    @ParameterizedTest
    @MethodSource("data")
    void testEncodingAndMasking(Map<String, Boolean> config, String expected) {
        JacksonEncodingStrategy underTest = new JacksonEncodingStrategy(new MaskingConfiguration(config));
        assertEquals(UNMASKED, underTest.encode(OBJ), "Encoding failed");
        assertEquals(expected, underTest.mask(OBJ), "Masking failed");
    }

    @Test
    void isCustomMasker() {
        JacksonEncodingStrategy underTest = new JacksonEncodingStrategy(new MaskingConfiguration(emptyMap()));
        assertTrue(underTest.customMasking());
    }

    @Test
    void shouldBeResilientToException() {
        JacksonEncodingStrategy underTest = new JacksonEncodingStrategy(new ObjectMapper(), new MaskingConfiguration(emptyMap()));
        assertEquals("", underTest.encode(OBJ));
        assertEquals("", underTest.mask(OBJ));
    }

    @Accessors(fluent = true)
    @Data
    @NoArgsConstructor
    private static class TestObject {

        private String clear;

        @Mask
        private String masked;

        @Mask(key = "somethingelse")
        private String withKey;

        @Mask
        private TestObject child;

        @JsonIgnore
        @Mask
        private String ignored = "ignored";
    }

}