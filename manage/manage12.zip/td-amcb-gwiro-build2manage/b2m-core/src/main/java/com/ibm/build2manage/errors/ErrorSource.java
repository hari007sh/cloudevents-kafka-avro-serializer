package com.ibm.build2manage.errors;

import org.springframework.lang.Nullable;

import java.text.MessageFormat;

public interface ErrorSource {
    /**
     * Generate the proper error message for a given error code with the provided parameters. The error is formatted as
     * &lt;errorCode&gt; - &lt;message&gt;.
     * <p>
     * If no message is found in the configuration, the default message is used. If both are null, only the error code
     * is returned.
     *
     * @param code the error code
     * @param defaultMessage the message to use if no message is found. Can be null
     * @param args the {@link MessageFormat} arguments. Can be null
     *
     * @return the error message
     */
    String get(int code, @Nullable String defaultMessage, Object... args);

    /**
     * Throws a {@link CodedException} containing all the information required to retrieve the error message associated
     * with it.
     *
     * @param code the error code
     * @param defaultMessage the message to use if no message is found. Can be null
     * @param args the {@link MessageFormat} arguments. Can be null
     * @param <T> any type allowing to use the method in a return statement
     *
     * @return will never return anything
     *
     * @throws CodedException with the provided message code information
     */
    <T> T fatal(int code, @Nullable String defaultMessage, Object... args) throws CodedException;

}
