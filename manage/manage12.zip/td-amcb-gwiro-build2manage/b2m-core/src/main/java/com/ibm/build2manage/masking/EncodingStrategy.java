package com.ibm.build2manage.masking;

/**
 * An {@link EncodingStrategy} is a way to recover a string representation from an object. An implementation can execute
 * the masking at
 */
@FunctionalInterface
public interface EncodingStrategy {

    /**
     * Flag to indicate that this {@link EncodingStrategy} manages masking by itself.
     *
     * @return true if the strategy manages masking by itself
     */
    default boolean customMasking() {
        return false;
    }

    /**
     * Mask the provided object using custom masking.
     *
     * @param o the object to encode
     *
     * @return the string representation of the object
     */
    default String mask(Object o) {
        throw new UnsupportedOperationException("Strategy does not support masking");
    }

    /**
     * Apply the encoding on the provided object
     *
     * @param o the object to encode
     *
     * @return the string representation of the object
     */
    String encode(Object o);

}
