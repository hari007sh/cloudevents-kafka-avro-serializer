package com.ibm.build2manage.resources;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.SpringApplicationRunListener;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.core.io.FileSystemResource;
import org.springframework.core.io.ProtocolResolver;
import org.springframework.core.io.Resource;
import org.springframework.core.io.ResourceLoader;
import org.springframework.lang.NonNull;

/**
 * Implementation of {@link ProtocolResolver} that allows to specify we want to create a {@link FileSystemResource}. To
 * specify the need for a {@link FileSystemResource}, the configuration value should start with <code>fs:</code>.
 */
public class FileSystemProtocolResolver implements ProtocolResolver, SpringApplicationRunListener {

    private static final String FILESYSTEM_URL_PREFIX = "fs:";

    /**
     * Constructor required by the spring framework.
     *
     * @param app  the spring application
     * @param args the command line arguments
     */
    public FileSystemProtocolResolver(SpringApplication app, String[] args) {
        // Ignored but required by spring framework
    }

    @Override
    public void contextPrepared(ConfigurableApplicationContext context) {
        context.addProtocolResolver(this);
    }

    @Override
    public Resource resolve(@NonNull String location, @NonNull ResourceLoader resourceLoader) {
        if (location.startsWith(FILESYSTEM_URL_PREFIX)) {
            return new FileSystemResource(location.substring(FILESYSTEM_URL_PREFIX.length()));
        }
        return null;
    }
}
