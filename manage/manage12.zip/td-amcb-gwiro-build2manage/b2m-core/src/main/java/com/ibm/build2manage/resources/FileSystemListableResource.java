package com.ibm.build2manage.resources;

import lombok.extern.log4j.Log4j2;
import org.springframework.core.io.FileSystemResource;
import org.springframework.core.io.Resource;
import org.springframework.lang.NonNull;

import java.io.File;
import java.io.IOException;
import java.nio.file.*;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.stream.Stream;

/**
 * A {@link FileSystemListableResource} is a modification of {@link FileSystemResource} that implements the
 * {@link ListableResource} interface and also fixes some issues that happens with {@link FileSystemResource} like the
 * creation of a relative requiring the path to finish by / to detect if the resource is a folder.
 */
@Log4j2
public class FileSystemListableResource extends FileSystemResource implements ListableResource, DeletableResource {

    private Thread t;
    private WatchService service;
    private final List<ResourceProcessor> processors = new ArrayList<>(0);

    /**
     * Constructor.
     *
     * @param file the underlying {@link File}
     */
    public FileSystemListableResource(File file) {
        super(file);
    }

    /**
     * Runnable responsible for managing {@link FileSystem} events.
     */
    private void monitor() {
        try {
            while (!Thread.currentThread().isInterrupted()) {
                WatchKey key = service.take();
                if (key != null && key.isValid()) {
                    for (WatchEvent<?> e : key.pollEvents()) {
                        if (StandardWatchEventKinds.OVERFLOW.equals(e.kind())) {
                            log.atError().log("Messages were dropped during watch");
                        } else {
                            Resource r = createRelative(e.context().toString());
                            processors.forEach(c -> c.created(r));
                        }
                    }
                    if (!key.reset()) {
                        Thread.currentThread().interrupt();
                    }
                }
            }
        } catch (InterruptedException e) {
            // do nothing, we are done
        }
    }

    @NonNull
    @Override
    public Resource createRelative(@NonNull String relativePath) {
        if (getFile().isFile()) {
            return super.createRelative(relativePath);
        }
        return new FileSystemResource(getPath() + "/" + relativePath);
    }

    @Override
    public Iterator<String> iterator() {
        String[] tmp = getFile().list();
        if (tmp == null || tmp.length == 0) {
            return Collections.emptyIterator();
        }
        return Stream.of(tmp).iterator();
    }

    @Override
    public void watch(ResourceProcessor processor) throws IOException {
        File f = getFile();
        if (!f.isDirectory()) {
            throw new IOException("Unable to monitor files");
        }
        if (t == null) {
            Path p = f.toPath();
            service = FileSystems.getDefault().newWatchService();
            p.register(service, StandardWatchEventKinds.ENTRY_CREATE, StandardWatchEventKinds.OVERFLOW);
            t = new Thread(this::monitor);
            t.start();
        }
        processors.add(processor);
    }

    @Override
    public void stopWatching() {
        if (t != null) {
            t.interrupt();
            try {
                t.join();
            } catch (InterruptedException e) {
                // We continue and hope for the best
            }
        }
        if (service != null) {
            try {
                service.close();
            } catch (IOException e) {
                log.atError().withThrowable(e).log("Unable to close WatchService properly");
            }
        }
    }

    @Override
    public boolean delete() {
        return getFile().delete();
    }
}
