package com.ibm.build2manage.resources;

import org.springframework.core.io.Resource;

import java.io.IOException;

/**
 * A {@link DeletableResource} is an interface used to identify a {@link Resource} that supports deletion.
 */
public interface DeletableResource extends Resource {

    /**
     * Deletes the file or directory denoted by this resource. If this resource denotes a directory, then the directory
     * must be empty in order to be deleted.
     *
     * @return <code>true</code> if and only if the resource is
     * successfully deleted; <code>false</code> otherwise
     * @throws SecurityException If a security manager exists and denies delete access to the resource
     */
    boolean delete() throws IOException;

}
