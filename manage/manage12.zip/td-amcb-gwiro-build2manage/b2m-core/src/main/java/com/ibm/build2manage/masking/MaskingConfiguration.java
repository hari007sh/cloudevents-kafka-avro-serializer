package com.ibm.build2manage.masking;

import com.ibm.build2manage.annotations.Mask;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.ConstructorBinding;

import java.util.Collections;
import java.util.Map;

/**
 * Configuration of the masking module.
 */
@ConstructorBinding
@ConfigurationProperties(prefix = "b2m")
public class MaskingConfiguration {

    public static final String DEFAULT_KEY = "default";
    public static final String UNDEFINED = "!@#$%^&*()";
    public static final String STARS = "*************";

    /**
     * Map allowing to turn on or off the masking for specific mapping keys.
     * If no key is specified, or if the provided key is not specified, the
     * value of the key "default" is used.
     */
    private final Map<String, Boolean> masking;
    private final Boolean defMasking;

    /**
     * Constructor.
     *
     * @param masking the masking configuration
     */
    public MaskingConfiguration(Map<String, Boolean> masking) {
        this.masking = Collections.unmodifiableMap(masking);
        this.defMasking = masking.getOrDefault(DEFAULT_KEY, true);
    }

    /**
     * @return true if the element should be masked
     */
    public boolean shouldMask() {
        return defMasking;
    }

    /**
     * Determines if we should mask elements based on the configuration key.
     *
     * @param key the configuration key
     *
     * @return true if the element should be masked
     */
    public boolean shouldMask(String key) {
        Boolean b = masking.get(key);
        return b == null ? defMasking : b;
    }

    /**
     * Determines if we should mask a field value based on the {@link Mask} annotation.
     *
     * @param annotation the annotation
     * @param undefinedKey the key to use when not defined
     *
     * @return true if the field value should be masked
     */
    public boolean shouldMask(Mask annotation, String undefinedKey) {
        if (annotation == null) {
            return false;
        }
        if (UNDEFINED.equals(annotation.key())) {
            return shouldMask(undefinedKey);
        }
        return shouldMask(annotation.key());
    }
}
