package com.ibm.build2manage.encoding;

import java.io.IOException;
import java.util.List;

/**
 * An {@link Encoder} is a functional interface that apply some encoding logic to transfer the representation of an object
 * into another representation. It is expected that using the result of this {@link Encoder} with the associated {@link Decoder}
 * are will recover the original entity.
 * <p>
 * All implementations are expected to be thread safe
 * </p>
 *
 * @param <E> the encoded format
 */
@FunctionalInterface
public interface Encoder<E> {

    /**
     * Encode the source object into the required representation.
     *
     * @param source the source object
     * @param tClass the class of the entity type
     * @param <T>    the type of the entity to encode
     * @return the encoded representation
     * @throws IOException if we are unable to encode
     */
    <T> E encode(T source, Class<T> tClass) throws IOException;

    default <T> E encodeList(List<T> source, Class<T> tClass) throws IOException {
        throw new UnsupportedOperationException();
    }
}
