package com.ibm.build2manage.annotations;

import com.ibm.build2manage.masking.MaskingConfiguration;

import java.lang.annotation.*;

/**
 * Annotation used to identify a field as containing personal information that should be masked in logs.
 */
@Documented
@Target(ElementType.FIELD)
@Retention(RetentionPolicy.RUNTIME)
public @interface Mask {

    /**
     * @return the key of the configuration to use when masking this field
     */
    String key() default MaskingConfiguration.UNDEFINED;
}
