package com.ibm.build2manage.resources;

import org.springframework.core.io.Resource;
import org.springframework.lang.NonNull;

import java.io.IOException;

/**
 * A {@link ListableResource} is an interface used to identify a {@link Resource} that supports complex operations with
 * child resources like watching and listing.
 */
public interface ListableResource extends Resource, Iterable<String> {


    /**
     * Using this method allows to specify a {@link ResourceProcessor} to be called when there is a new event on this
     * resource. Passing a resource to a {@link ResourceProcessor} does not mean that this resource is usable, simply
     * that something happened to it. It is the responsibility of the processor to support situations where the resource
     * may not yet be ready for processing (e.g. file created but still being written to).
     *
     * @param processor the processor to call when a change occurs
     * @throws IOException if we are unable to start watching this resource
     */
    void watch(ResourceProcessor processor) throws IOException;

    /**
     * Specify that we want to stop watching the current resource. This will stop watching for <b>all</b>
     * {@link ResourceProcessor} currently watching.
     */
    void stopWatching();

    /**
     * Safe way to transform a {@link Resource} into a {@link ListableResource}. If the {@link Resource} cannot be
     * listed, this will return an instance that returns an empty {@link java.util.Iterator}.
     *
     * @param resource the resource we want to list
     * @return the {@link ListableResource} associated to this resource.
     * @throws IOException if an error occurs while creating the {@link ListableResource} from this resource
     */
    @NonNull
    static ListableResource of(Resource resource) throws IOException {
        if (resource instanceof ListableResource) {
            return (ListableResource) resource;
        } else if (resource.isFile() && resource.getFile().isDirectory()) {
            return new FileSystemListableResource(resource.getFile());
        }
        throw new IOException("Unable to create " + ListableResource.class + " from " + resource);
    }
}
