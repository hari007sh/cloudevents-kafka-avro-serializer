package com.ibm.build2manage;

import com.ibm.build2manage.errors.ErrorConfiguration;
import com.ibm.build2manage.errors.ErrorSource;
import com.ibm.build2manage.errors.SpringErrorSource;
import com.ibm.build2manage.masking.DataMasker;
import com.ibm.build2manage.masking.MaskingConfiguration;
import com.ibm.build2manage.resources.Base64ProtocolResolver;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;

@Configuration(proxyBeanMethods = false)
@PropertySource("classpath:errors.properties")
@PropertySource("classpath:masking.properties")
@EnableConfigurationProperties({MaskingConfiguration.class, ErrorConfiguration.class})
public class Build2ManageAutoConfiguration {

    @Bean
    @ConditionalOnMissingBean(IntegerIntervalConverter.class)
    public IntegerIntervalConverter rangeConverter() {
        return new IntegerIntervalConverter();
    }

    @Bean
    @ConditionalOnMissingBean(ErrorSource.class)
    public ErrorSource errors(ErrorConfiguration config) {
        return new SpringErrorSource(config.getLocale(), config.getBasenames());
    }

    @Bean
    @ConditionalOnMissingBean(DataMasker.class)
    public DataMasker dataMasker(MaskingConfiguration config) {
        return new DataMasker(config);
    }
}