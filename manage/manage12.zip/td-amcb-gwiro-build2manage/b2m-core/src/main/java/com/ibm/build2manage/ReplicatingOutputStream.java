package com.ibm.build2manage;

import org.springframework.lang.NonNull;

import java.io.IOException;
import java.io.OutputStream;
import java.util.Arrays;
import java.util.List;

/**
 * Small utility that replicate an output stream. BEWARE: NOT production ready.
 */
public class ReplicatingOutputStream extends OutputStream {

    private final List<OutputStream> streams;

    public ReplicatingOutputStream(OutputStream... streams) {
        if (streams.length < 2) {
            throw new IllegalArgumentException("Should have at least 2 output streams");
        }
        this.streams = Arrays.asList(streams);
    }

    @Override
    public void write(int b) throws IOException {
        for (OutputStream stream : streams) {
            stream.write(b);
        }
    }

    @Override
    public void write(@NonNull byte[] b) throws IOException {
        for (OutputStream stream : streams) {
            stream.write(b);
        }
    }

    @Override
    public void write(@NonNull byte[] b, int off, int len) throws IOException {
        for (OutputStream stream : streams) {
            stream.write(b, off, len);
        }
    }

    @Override
    public void flush() throws IOException {
        for (OutputStream stream : streams) {
            stream.flush();
        }
    }

    @Override
    public void close() throws IOException {
        for (OutputStream stream : streams) {
            stream.close();
        }
    }
}
