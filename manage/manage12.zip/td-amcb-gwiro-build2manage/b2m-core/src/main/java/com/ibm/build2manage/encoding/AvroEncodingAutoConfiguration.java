package com.ibm.build2manage.encoding;

import org.apache.avro.io.*;
import org.apache.avro.specific.SpecificDatumReader;
import org.apache.avro.specific.SpecificDatumWriter;
import org.springframework.boot.autoconfigure.AutoConfigureBefore;
import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
import org.springframework.boot.autoconfigure.kafka.KafkaAutoConfiguration;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.io.ByteArrayOutputStream;
import java.io.IOException;

/**
 * Autoconfiguration class responsible for setting up {@link EncodingFormat} for AVRO content type.
 */
@Configuration(proxyBeanMethods = false)
@ConditionalOnClass(EncoderFactory.class)
@AutoConfigureBefore(KafkaAutoConfiguration.class)
public class AvroEncodingAutoConfiguration {

    public static final String FORMAT = "application/octet-stream+avro";

    @Bean
    public EncodingFormat<byte[]> kafkaAvroEncoder() {
        return EncodingFactory.register(new EncodingFormat<>(FORMAT, new AvroEncoder(), new AvroDecoder()));
    }

    /**
     * Implementation of {@link Encoder} for avro format.
     */
    public static class AvroEncoder implements Encoder<byte[]> {

        private final EncoderFactory encoder = EncoderFactory.get();

        @Override
        public <T> byte[] encode(T source, Class<T> tClass) throws IOException {
            DatumWriter<T> writer = new SpecificDatumWriter<>(tClass);
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            BinaryEncoder binary = encoder.binaryEncoder(out, null);
            writer.write(source, binary);
            binary.flush();
            return out.toByteArray();
        }
    }

    /**
     * Implementation of {@link Decoder} for avro format.
     */
    public static class AvroDecoder implements Decoder<byte[]> {
        private final DecoderFactory decoder = DecoderFactory.get();

        @Override
        public <T> T decode(byte[] source, Class<T> tClass) throws IOException {
            DatumReader<T> reader = new SpecificDatumReader<>(tClass);
            return reader.read(null, decoder.binaryDecoder(source, null));
        }
    }
}
