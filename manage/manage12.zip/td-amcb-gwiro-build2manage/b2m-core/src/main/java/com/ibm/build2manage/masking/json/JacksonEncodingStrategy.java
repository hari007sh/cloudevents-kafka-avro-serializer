package com.ibm.build2manage.masking.json;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.PropertyAccessor;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.AnnotationIntrospector;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ibm.build2manage.masking.EncodingStrategy;
import com.ibm.build2manage.annotations.Mask;
import com.ibm.build2manage.masking.MaskingConfiguration;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.lang.NonNull;

import java.util.Objects;

/**
 * Implementation of {@link EncodingStrategy} that encode the object using Jackson. It has the following behavior:
 * <ul>
 *     <li>Jackson annotations are processed before masking. This means a field marked with {@link JsonIgnore} will never be encoded or masked</li>
 *     <li>All masked field will be encoded as string, including complex types</li>
 *     <li>Only serialization is supported</li>
 *     <li>If the key is undefined in the {@link Mask} annotation, the field name is used</li>
 *     <li>Field hierarchy is not kept when resolving the field name</li>
 *     <li>If an error happens during encoding, an empty string is returned</li>
 * </ul>
 */
public class JacksonEncodingStrategy implements EncodingStrategy {

    private static final Logger LOG = LogManager.getLogger(JacksonEncodingStrategy.class);
    private static final ObjectMapper STATIC = new ObjectMapper()
            .setVisibility(PropertyAccessor.ALL, JsonAutoDetect.Visibility.NONE)
            .setVisibility(PropertyAccessor.FIELD, JsonAutoDetect.Visibility.ANY);

    private final ObjectMapper unmasked;

    private final ObjectMapper masked;

    private static ObjectMapper createMasked(ObjectMapper unmasked, MaskingConfiguration config) {
        MaskDataAnnotationIntrospector introspector = new MaskDataAnnotationIntrospector(Objects.requireNonNull(config, "Missing masking configuration"));
        ObjectMapper tmp = unmasked.copy();
        return tmp.setAnnotationIntrospectors(
                AnnotationIntrospector.pair(tmp.getSerializationConfig().getAnnotationIntrospector(), introspector),
                tmp.getDeserializationConfig().getAnnotationIntrospector()
        );
    }

    /**
     * Constructor using a built-in {@link ObjectMapper}.
     *
     * @param config the masking configuration
     */
    public JacksonEncodingStrategy(@NonNull MaskingConfiguration config) {
        unmasked = STATIC;
        masked = createMasked(STATIC, config);
    }

    /**
     * Constructor using a pre-configured {@link ObjectMapper}. This {@link ObjectMapper} will be cloned to avoid cross
     * contamination.
     *
     * @param mapper the customized configuration mapper
     * @param config the masking configuration
     */
    public JacksonEncodingStrategy(@NonNull ObjectMapper mapper, @NonNull MaskingConfiguration config) {
        unmasked = Objects.requireNonNull(mapper, "Mapper instance must be provided").copy();
        masked = createMasked(mapper, config);
    }

    @Override
    public boolean customMasking() {
        return true;
    }

    @Override
    public String mask(Object o) {
        try {
            return masked.writeValueAsString(o);
        } catch (JsonProcessingException e) {
            LOG.atError().withThrowable(e).log("Unable to encode: {}", e);
            return "";
        }
    }

    @Override
    public String encode(Object o) {
        try {
            return unmasked.writeValueAsString(o);
        } catch (JsonProcessingException e) {
            LOG.atError().withThrowable(e).log("Unable to encode: {}", e);
            return "";
        }
    }
}
