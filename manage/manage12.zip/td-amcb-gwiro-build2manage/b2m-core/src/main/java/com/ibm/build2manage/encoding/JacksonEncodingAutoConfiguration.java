package com.ibm.build2manage.encoding;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JavaType;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.RequiredArgsConstructor;
import org.springframework.boot.autoconfigure.AutoConfigureBefore;
import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
import org.springframework.boot.autoconfigure.kafka.KafkaAutoConfiguration;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.io.IOException;
import java.util.List;

/**
 * Autoconfiguration class responsible for setting up {@link EncodingFormat} for JSON content type using Jackson library.
 */
@Configuration(proxyBeanMethods = false)
@ConditionalOnClass(ObjectMapper.class)
@AutoConfigureBefore(KafkaAutoConfiguration.class)
public class JacksonEncodingAutoConfiguration {

    public static final String FORMAT = "application/json";

    @Bean
    public EncodingFormat<byte[]> kafkaJacksonEncoder() {
        ObjectMapper mapper = new ObjectMapper();
        return EncodingFactory.register(new EncodingFormat<>(FORMAT, new JacksonEncoder(mapper), new JacksonDecoder(mapper)));
    }

    /**
     * Implementation of {@link Encoder} for json format backed by Jackson library.
     */
    @RequiredArgsConstructor
    public static class JacksonEncoder implements Encoder<byte[]> {
        private final ObjectMapper mapper;

        @Override
        public <T> byte[] encode(T source, Class<T> tClass) throws IOException {
            return mapper.writeValueAsBytes(source);
        }

        @Override
        public <T> byte[] encodeList(List<T> source, Class<T> tClass) throws IOException {
            return mapper.writeValueAsBytes(source);
        }
    }

    /**
     * Implementation of {@link Decoder} for json format backed by Jackson library.
     */
    @RequiredArgsConstructor
    public static class JacksonDecoder implements Decoder<byte[]> {
        private final ObjectMapper mapper;

        @Override
        public <T> T decode(byte[] source, Class<T> tClass) throws IOException {
            return mapper.readValue(source, tClass);
        }

        @Override
        public <T> List<T> decodeList(byte[] source, Class<T> tClass) throws IOException {
            return mapper.readValue(source, mapper.getTypeFactory().constructCollectionType(List.class, tClass));
        }
    }

}
