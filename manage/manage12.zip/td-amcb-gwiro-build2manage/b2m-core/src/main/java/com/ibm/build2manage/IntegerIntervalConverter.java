package com.ibm.build2manage;

import org.springframework.boot.context.properties.ConfigurationPropertiesBinding;
import org.springframework.core.convert.converter.Converter;
import org.springframework.lang.NonNull;

/**
 * Spring {@link Converter} to convert strings from properties to {@link IntegerInterval}.
 */
@ConfigurationPropertiesBinding
public class IntegerIntervalConverter implements Converter<String, IntegerInterval> {

    @Override
    public IntegerInterval convert(@NonNull String source) {
        return IntegerInterval.fromString(source);
    }
}
