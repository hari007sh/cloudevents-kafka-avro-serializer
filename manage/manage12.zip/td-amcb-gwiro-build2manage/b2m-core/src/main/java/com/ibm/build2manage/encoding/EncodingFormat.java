package com.ibm.build2manage.encoding;

import lombok.Getter;
import lombok.RequiredArgsConstructor;

/**
 * An {@link EncodingFormat} is a way to easily encode and decode elements of the provided format.
 *
 * @param <E> the encoded type
 */
@RequiredArgsConstructor
public class EncodingFormat<E> {

    @Getter
    private final String name;

    @Getter
    private final Encoder<E> encoder;

    @Getter
    private final Decoder<E> decoder;
}
