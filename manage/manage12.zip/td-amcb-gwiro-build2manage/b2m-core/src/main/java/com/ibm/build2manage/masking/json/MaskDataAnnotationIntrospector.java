package com.ibm.build2manage.masking.json;

import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.databind.SerializerProvider;
import com.fasterxml.jackson.databind.introspect.Annotated;
import com.fasterxml.jackson.databind.introspect.NopAnnotationIntrospector;
import com.fasterxml.jackson.databind.ser.std.StdSerializer;
import com.ibm.build2manage.annotations.Mask;
import com.ibm.build2manage.masking.MaskingConfiguration;
import lombok.RequiredArgsConstructor;

import java.io.IOException;

/**
 * Jackson annotation introspector that detects the {@link Mask} annotation and prevent serializing masked data.
 */
@RequiredArgsConstructor
class MaskDataAnnotationIntrospector extends NopAnnotationIntrospector {

    private static final StdSerializer<Object> MASKED = new StdSerializer<>(Object.class) {
        @Override
        public void serialize(Object value, JsonGenerator gen, SerializerProvider provider) throws IOException {
            gen.writeString(MaskingConfiguration.STARS);
        }
    };

    private final transient MaskingConfiguration config;

    @Override
    public Object findSerializer(Annotated am) {
        if (config.shouldMask(am.getAnnotation(Mask.class), am.getName())) {
            return MASKED;
        }
        return null;
    }
}
