package com.ibm.build2manage;

import lombok.AccessLevel;
import lombok.NoArgsConstructor;
import lombok.NonNull;

import java.util.List;
import java.util.function.Predicate;
import java.util.stream.Stream;

@NoArgsConstructor(access = AccessLevel.PRIVATE)
public final class CollectionUtils {

    /**
     * Compares and returns added and removed items from two lists.
     *
     * @param original The original list being compared. If null, any item in the modified list is considered as added.
     * @param modified The modified list being compared. If null, any item in original list is considered as removed.
     * @param added List that contain added items to original list
     * @param removed List that contain removed items from original list
     * @param <T> The type of list objects to work on
     */
    public static <T> void Diff(List<T> original, List<T> modified, @NonNull List<T> added, @NonNull List<T> removed) {

        // Check for removed items
        if (!org.springframework.util.CollectionUtils.isEmpty(original)) {
            for (T item : original) {
                if (org.springframework.util.CollectionUtils.isEmpty(modified) || !modified.contains(item)) {
                    removed.add(item);
                }
            }
        }

        // Check for added items
        if (!org.springframework.util.CollectionUtils.isEmpty(modified)) {
            for (T item : modified) {
                if (org.springframework.util.CollectionUtils.isEmpty(original) || !original.contains(item)) {
                    added.add(item);
                }
            }
        }
    }

    /**
     * Null safe way of retrieving a stream from a list.
     *
     * @param aList the list to stream
     * @param <T>   the type of elements in the list
     * @return a non-null stream with the filtered elements
     */
    public static <T> Stream<T> stream(List<T> aList) {
        if (org.springframework.util.CollectionUtils.isEmpty(aList)) {
            return Stream.empty();
        }
        return aList.stream();
    }

    /**
     * Null safe way of retrieving a filtered stream from a list.
     *
     * @param aList  the list to stream
     * @param filter the filter to apply
     * @param <T>    the type of elements in the list
     * @return a non-null stream with the filtered elements
     */
    public static <T> Stream<T> stream(List<T> aList, Predicate<T> filter) {
        return stream(aList).filter(filter);
    }
}
