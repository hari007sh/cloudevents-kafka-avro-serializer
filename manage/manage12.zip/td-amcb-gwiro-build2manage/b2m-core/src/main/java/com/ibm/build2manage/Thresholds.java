package com.ibm.build2manage;

import lombok.AllArgsConstructor;
import org.springframework.lang.NonNull;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Objects;

/**
 * Utility class allowing to return a value based on a threshold. Note that this implementation will always compare a
 * threshold using a positive approach: e.g. is the current value greater than the threshold value. It is the
 * responsibility of the using class of properly define their threshold values in such a way that it returns the proper
 * result.
 *
 * @param <T> the type of value returned based on the threshold
 */
public class Thresholds<T> {

    private final List<ThresholdValue> values;
    private final T defElement;

    /**
     * Constructor.
     *
     * @param defElement the element to return if no threshold are matched
     * @param size initial number of thresholds
     */
    public Thresholds(T defElement, int size) {
        this.defElement = defElement;
        this.values = new ArrayList<>(size);
    }

    /**
     * Retrieve the element associated to the threshold corresponding to the provided value
     *
     * @param value the current value
     *
     * @return the element associated with the threshold for this value. Can be null depending on the configuration.
     */
    public T get(double value) {
        for (ThresholdValue t : values) {
            if (value >= t.threshold) {
                return t.value;
            }
        }
        return defElement;
    }

    /**
     * Adds an element for the provided threshold.
     *
     * @param threshold the threshold
     * @param element the element to add
     *
     * @return this
     */
    public Thresholds<T> with(double threshold, T element) {
        for (ThresholdValue t : values) {
            if (threshold - t.threshold == 0) {
                t.value = element;
                return this;
            }
        }
        values.add(new ThresholdValue(threshold, element));
        values.sort(Collections.reverseOrder());
        return this;
    }

    @AllArgsConstructor
    private class ThresholdValue implements Comparable<ThresholdValue> {

        private final double threshold;
        private T value;

        @Override
        public int compareTo(@NonNull ThresholdValue o) {
            Objects.requireNonNull(o);
            return (int) Math.signum(threshold - o.threshold);
        }

        @Override
        public int hashCode() {
            return Objects.hashCode(threshold);
        }

        @Override
        @SuppressWarnings("unchecked")
        public boolean equals(Object obj) {
            if (obj instanceof Thresholds.ThresholdValue) {
                return compareTo((ThresholdValue) obj) == 0;
            }
            return false;
        }
    }
}
