package com.ibm.build2manage;

import lombok.Getter;
import lombok.RequiredArgsConstructor;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * An {@link IntegerInterval} is a range of integer, allowing to simplify verification if a number is between two
 * numbers. The name must be read using the the mathematical meaning of integer, not the java meaning.
 */
@RequiredArgsConstructor
public class IntegerInterval implements Interval {

    private static final Pattern PATTERN = Pattern.compile("([\\[\\]\\(])?(\\d+)-(\\d+)([\\[\\]\\)])?");

    /**
     * The lower bound of the range, included.
     */
    @Getter
    private final long from;
    /**
     * The upper bound of the range, included.
     */
    @Getter
    private final long to;

    @Override
    public boolean contains(long value) {
        return from <= value && value <= to;
    }

    @Override
    public boolean contains(double value) {
        return from <= value && value <= to;
    }

    /**
     * Parse an integer range from a string. The format uses an approach similar to the interval notation for sets from
     * <a href="https://en.wikipedia.org/wiki/ISO_31-11#Sets">ISO_31-11</a> with some changes:
     * <ul>
     *     <li>The interval uses a dash '-' instead of comma ','. This allows to define a list of IntRange which are separated with comma ','</li>
     *     <li>The brackets are optional. If a bracket is omitted, it is assumed that the part is closed</li>
     * </ul>
     * The table below gives an overview of the format compared to <a href="https://en.wikipedia.org/wiki/ISO_31-11#Sets">ISO_31-11</a>
     * <table>
     *    <caption>Examples</caption>
     *    <tr>
     *        <th>Description</th>
     *        <th><a href="https://en.wikipedia.org/wiki/ISO_31-11#Sets">ISO_31-11</a></th>
     *        <th>{@link IntegerInterval}</th>
     *    </tr>
     *    <tr>
     *        <td>Closed interval from <br>
     *            a (included) to <br>
     *            b (included)</td>
     *        <td>[a,b]</td>
     *        <td>a-b<br>
     *            [a-b<br>
     *            a-b]<br>
     *            [a-b]<br>
     *        </td>
     *    </tr>
     *    <tr>
     *        <td>Left half-open interval from <br>
     *            a (excluded) to <br>
     *            b (included)</td>
     *        <td>]a,b]<br>
     *            (a,b]</td>
     *        <td>]a-b<br>
     *            (a-b<br>
     *            ]a-b]<br>
     *            (a-b]<br>
     *        </td>
     *    </tr>
     *    <tr>
     *        <td>Right half-open interval from <br>
     *            a (included) to <br>
     *            b (excluded)</td>
     *        <td>[a,b[<br>
     *            [a,b)</td>
     *        <td>a-b[<br>
     *            a-b)<br>
     *            [a-b[<br>
     *            [a-b)<br>
     *        </td>
     *    <tr>
     *        <td>Open interval from <br>
     *            a (excluded) to <br>
     *            b (excluded)</td>
     *        <td>]a,b[<br>
     *            (a,b)</td>
     *        <td>]a-b[<br>
     *            ]a-b)<br>
     *            (a-b[<br>
     *            (a-b)<br>
     *        </td>
     *    </tr>
     * </table>
     *
     * @param source the source string
     * @return the IntRange for the string
     */
    public static IntegerInterval fromString(String source) {
        Matcher m = PATTERN.matcher(source);
        if (m.matches()) {
            int from = Integer.parseInt(m.group(2));
            int to = Integer.parseInt(m.group(3));
            String s = m.group(1);
            if ("]".equals(s) || "(".equals(s)) {
                from++;
            }
            s = m.group(4);
            if ("[".equals(s) || ")".equals(s)) {
                to--;
            }
            return new IntegerInterval(from, to);
        }
        throw new IllegalArgumentException(source + " does not match proper format");
    }
}
