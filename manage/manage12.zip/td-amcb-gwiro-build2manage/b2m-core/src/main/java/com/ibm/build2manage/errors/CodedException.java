package com.ibm.build2manage.errors;

import lombok.AccessLevel;
import lombok.Getter;
import lombok.RequiredArgsConstructor;

@Getter
@RequiredArgsConstructor(access = AccessLevel.PACKAGE)
public class CodedException extends RuntimeException {

    private final transient int errorCode;
    private final transient String defaultMessage;
    private final transient Object[] args;

}
