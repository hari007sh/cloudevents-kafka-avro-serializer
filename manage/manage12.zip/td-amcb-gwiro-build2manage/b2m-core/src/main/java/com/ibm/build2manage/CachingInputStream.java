package com.ibm.build2manage;

import lombok.RequiredArgsConstructor;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;

@RequiredArgsConstructor
public class CachingInputStream extends InputStream {

    private final UnsafeByteArrayOutputStream cache = new UnsafeByteArrayOutputStream();

    private final InputStream in;

    private int pos = 0;
    private int max = Integer.MAX_VALUE;

    private int eof = Integer.MAX_VALUE;

    public CachingInputStream(InputStream in, int max) {
        this(in);
        // Count is the index that we should stop while max is the amount. Since
        // pos starts at 0, it means last index is max+1
        this.max = max;
    }

    /**
     * @return true if current position is in cache only, meaning we can reset without impacting the actual stream
     */
    private boolean posInCacheOnly() {
        return pos <= max || eof <= max;
    }

    public byte[] getCache() {
        return cache.toByteArray();
    }

    public byte[] fillAndGet() throws IOException {
        if (eof == Integer.MAX_VALUE && pos <= max) {
            int start = pos;
            skip(max - pos);
            pos = start;
        }
        return getCache();
    }

    @Override
    public int read() throws IOException {
        int res = -1;
        // We are reading from cache
        if (pos < cache.size()) {
            res = cache.get(pos);
            pos++;
        } else if (pos == eof) {
            return -1;
        } else {
            res = in.read();
            pos++;
            if (res == -1) {
                eof = pos;
                // Cache if we still have space in the cache
            } else if (cache.size() < max) {
                cache.write(res);
            }
        }
        return res;
    }

    @Override
    public void close() throws IOException {
        in.close();
    }

    @Override
    public synchronized void reset() throws IOException {
        // Accept reset only if we are still in cache
        // This avoids complexity of dealing with
        // mark for initial implementation
        if (posInCacheOnly()) {
            pos = 0;
        } else {
            super.reset();
        }
    }

    private static class UnsafeByteArrayOutputStream extends ByteArrayOutputStream {
        int get(int i) {
            return buf[i];
        }
    }
}
