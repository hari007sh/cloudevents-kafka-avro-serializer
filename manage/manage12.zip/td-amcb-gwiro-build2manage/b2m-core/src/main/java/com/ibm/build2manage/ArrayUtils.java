package com.ibm.build2manage;

import lombok.AccessLevel;
import lombok.NoArgsConstructor;

import java.util.Arrays;
import java.util.function.Function;

@NoArgsConstructor(access = AccessLevel.PRIVATE)
public final class ArrayUtils {

    private static final String NULL = "null";
    private static final String EMPTY = "[]";

    /**
     * Returns a string representation of the contents of the specified array. Contrary to {@link
     * Arrays#toString(Object[])}, the objects are converted to String using the provided function. It is recommended to
     * use {@link Arrays#toString(Object[])} instead of passing the {@link Object#toString()} method reference to avoid
     * wasting resources.
     *
     * <p>The value returned by this method is equal to the value that would
     * be returned by {@code Arrays.asList(a).toString()}, unless {@code a}
     * is {@code null}, in which case {@code "null"} is returned.
     *
     * @param a the array whose string representation to return
     * @param toString the function to transform a single value into a String
     * @param <T> the type of value to turn into a String
     *
     * @return a string representation of {@code a}
     *
     * @see Arrays#toString(Object[])
     */
    public static <T> String toString(T[] a, Function<T, String> toString) {
        if (a == null) {
            return NULL;
        }
        if (a.length == 0) {
            return EMPTY;
        }
        StringBuilder sb = new StringBuilder().append('[');
        for (T value : a) {
            sb.append(toString.apply(value)).append(',');
        }
        sb.setCharAt(sb.length() - 1, ']');
        return sb.toString();
    }
}