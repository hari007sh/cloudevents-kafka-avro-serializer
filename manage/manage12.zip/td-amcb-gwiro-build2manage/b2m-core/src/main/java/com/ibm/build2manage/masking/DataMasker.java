package com.ibm.build2manage.masking;

import lombok.AccessLevel;
import lombok.RequiredArgsConstructor;

import java.util.Objects;

/**
 * DataMasker allows to determine if an information should be masked before output to a logging facility. This instance
 * is designed to be thread safe and immutable, preventing unexpected behavior at runtime.
 */
@RequiredArgsConstructor
public class DataMasker {

    private static final EncodingObject MASKED = new EncodingObject(MaskingConfiguration.STARS);
    private static final EncodingStrategy MASKED_STRING = o -> MaskingConfiguration.STARS;
    private static final EncodingStrategy TO_STRING = Objects::toString;

    private final MaskingConfiguration config;

    private String mask(boolean shouldMask, Object o, EncodingStrategy strategy) {
        if (shouldMask) {
            if (strategy.customMasking()) {
                return strategy.mask(o);
            }
            return MASKED_STRING.encode(o);
        }
        return strategy.encode(o);
    }

    /**
     * Returns a masked representation of an object using default masking configuration.
     *
     * @param object the object to mask
     *
     * @return the string representation of the object based on the default masking configuration
     */
    public String mask(Object object) {
        return mask(config.shouldMask(), object, TO_STRING);
    }

    /**
     * Determines if the object should be masked or not based on the default masking configuration. If the object should
     * not be masked, or if the encoding strategy does masking at the granular level, it will be called.
     *
     * @param object the object to mask
     * @param strategy the encoding strategy
     *
     * @return the string representation of the object, encoded with the strategy, based on the default masking configuration
     */
    public String mask(Object object, EncodingStrategy strategy) {
        return mask(config.shouldMask(), object, strategy);
    }

    /**
     * Returns a masked representation of an object based on its configuration key. If no configuration is associated
     * with config key, config uses the default configuration.
     *
     * @param object the object to mask
     * @param key the configuration key to use
     *
     * @return the string representation of the object based on the key masking configuration
     */
    public String mask(Object object, String key) {
        return mask(config.shouldMask(key), object, TO_STRING);
    }

    /**
     * Determines if the object should be masked or not based on its configuration key. If the object should
     * not be masked, or if the encoding strategy does masking at the granular level, it will be called.
     *
     * @param object the object to mask
     * @param key the configuration key to use
     * @param strategy the encoding strategy
     *
     * @return the string representation of the object, encoded with the strategy, based on the key masking configuration
     */
    public String mask(Object object, String key, EncodingStrategy strategy) {
        return mask(config.shouldMask(key), object, strategy);
    }

    // ************************************************* PI returning ***************************************************
    public EncodingObject wrap(boolean shouldMask, Object object, EncodingStrategy strategy) {
        if (shouldMask) {
            if (strategy.customMasking()) {
                return new MaskingObject(object, strategy);
            }
            return MASKED;
        }
        return new EncodingObject(object, strategy);
    }

    /**
     * Wrap the object into a PI based on the default configuration.
     *
     * @param object the object to mask
     *
     * @return a wrapper which would return the the string representation of the object based on the default masking
     * configuration
     */
    public EncodingObject wrap(Object object) {
        return wrap(config.shouldMask(), object, TO_STRING);
    }

    /**
     * Determines if the object should be masked or not based on the default masking configuration. If the object
     * should not be masked, or if the encoding strategy does masking at the granular level, the object will be wrapped
     * into a PI that will use the provided strategy to represent the object.
     *
     * @param object the object to mask
     * @param strategy the encoding strategy
     *
     * @return a wrapper which would return the string representation of the object, encoded with the strategy,
     * based on the default masking configuration
     */
    public EncodingObject wrap(Object object, EncodingStrategy strategy) {
        return wrap(config.shouldMask(), object, strategy);
    }

    /**
     * Wrap the object into a PI based on its configuration key. If no configuration is associated
     * with config key, config uses the default configuration.
     *
     * @param object the object to mask
     * @param key the configuration key to use
     *
     * @return a wrapper which would return the the string representation of the object based on the key masking configuration
     */
    public EncodingObject wrap(Object object, String key) {
        return wrap(config.shouldMask(key), object, TO_STRING);
    }

    /**
     * Determines if the object should be masked or not based on the default masking configuration. If the object
     * should not be masked, or if the encoding strategy does masking at the granular level, the object will be wrapped
     * into a PI that will use the provided strategy to represent the object.
     *
     * @param object the object to mask
     * @param key the configuration key to user
     * @param strategy the encoding strategy
     *
     * @return a wrapper which would return the string representation of the object, encoded with the strategy,
     * based on the key masking configuration
     */
    public EncodingObject wrap(Object object, String key, EncodingStrategy strategy) {
        return wrap(config.shouldMask(key), object, strategy);
    }

    /**
     * Simple wrapper that keeps the object and the strategy and generate a string representation of the
     * entity when toString is called. This is useful to encode the entity only when it is required to display the
     * object without validating if it should be encoded or not.
     */
    @RequiredArgsConstructor(access = AccessLevel.PUBLIC)
    public static class EncodingObject {

        protected final Object o;

        protected final EncodingStrategy strategy;

        protected String asString;

        /**
         * Constructor returning a static string instead of going through encoding.
         *
         * @param asString the string representation
         */
        private EncodingObject(String asString) {
            this(null, null);
            this.asString = asString;
        }

        @Override
        public String toString() {
            if (asString == null) {
                asString = strategy.encode(o);
            }
            return asString;
        }
    }

    /**
     * {@link EncodingObject} implementation that uses {@link EncodingStrategy#mask(Object)} to
     * generate the string representation.
     */
    private static class MaskingObject extends EncodingObject {

        /**
         * Constructor.
         *
         * @param o the object to encode
         * @param strategy the encoding strategy
         */
        public MaskingObject(Object o, EncodingStrategy strategy) {
            super(o, strategy);
        }

        @Override
        public String toString() {
            if (asString == null) {
                asString = strategy.mask(o);
            }
            return asString;
        }

    }
}
