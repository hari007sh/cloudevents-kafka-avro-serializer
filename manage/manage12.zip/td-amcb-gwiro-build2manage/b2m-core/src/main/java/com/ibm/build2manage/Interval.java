package com.ibm.build2manage;

/**
 * An interval is a set of numbers that contains all numbers lying between two member of the set.
 * It was decided not to use Apache commons lang3 Range to represent intervals as this would involve a lot of boxing and
 * unboxing when working with primitives which would be resource intensive in a cloud environment.
 */
public interface Interval {

    /**
     * Determine if the integer value is contained withing the range.
     *
     * @param value the value
     *
     * @return true if the value is included in the range
     */
    boolean contains(long value);

    /**
     * Determine if the floating point value is contained withing the range.
     *
     * @param value the value
     *
     * @return true if the value is included in the range
     */
    boolean contains(double value);
}
