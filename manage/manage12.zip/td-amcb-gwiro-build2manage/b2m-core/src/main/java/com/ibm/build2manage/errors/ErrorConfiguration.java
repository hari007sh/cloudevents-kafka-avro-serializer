package com.ibm.build2manage.errors;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.ConstructorBinding;
import org.springframework.context.support.AbstractResourceBasedMessageSource;

import java.util.Locale;

/**
 * Configuration of the error module.
 */
@Data
@ConstructorBinding
@ConfigurationProperties(prefix = "b2m.error")
public class ErrorConfiguration {

    /**
     * Set an array of basenames to retrieve the error messages from. Each basename must follow
     * the basic ResourceBundle convention of not specifying file extension or language codes.
     * See {@link AbstractResourceBasedMessageSource#setBasenames(String...)} for details.
     */
    private final String[] basenames;

    /**
     * Specify the locale for the error messages.
     */
    private final Locale locale;
}

