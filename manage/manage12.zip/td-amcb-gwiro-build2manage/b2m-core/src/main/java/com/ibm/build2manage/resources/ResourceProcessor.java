package com.ibm.build2manage.resources;

import org.springframework.core.io.Resource;

/**
 * A {@link ResourceProcessor} is an instance that act when certain situation happens on a resource.
 */
public interface ResourceProcessor {

    /**
     * A new resource is created.
     *
     * @param r the new resource
     */
    void created(Resource r);

}
