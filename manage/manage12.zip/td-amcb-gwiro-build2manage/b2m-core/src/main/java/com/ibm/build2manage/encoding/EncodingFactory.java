package com.ibm.build2manage.encoding;

import lombok.AccessLevel;
import lombok.NoArgsConstructor;

import java.io.UnsupportedEncodingException;
import java.util.HashMap;
import java.util.Map;
import java.util.ServiceLoader;

/**
 * Factory responsible for creating the {@link Encoder} and {@link Decoder} for the requested format.
 * This implementation is very basic and stores the instances in a map.
 */
@NoArgsConstructor(access = AccessLevel.PRIVATE)
public class EncodingFactory {

    private static final Map<String, EncodingFormat<?>> ENCODERS = new HashMap<>();

    static {
        ServiceLoader
                .load(EncodingFormat.class)
                .forEach(EncodingFactory::register);
    }

    /**
     * Register an {@link EncodingFormat} with this factory
     *
     * @param format the {@link EncodingFormat}
     * @param <T>    the encoded type
     * @return the registered format
     */
    public static <T> EncodingFormat<T> register(EncodingFormat<T> format) {
        ENCODERS.put(format.getName(), format);
        return format;
    }

    /**
     * Retrieve the encoder for the provided format name
     *
     * @param name the name of the format
     * @param <E>  the encoded type
     * @return the {@link Encoder}
     * @throws UnsupportedEncodingException if no {@link Encoder} available for the format name
     */
    @SuppressWarnings("unchecked")
    public static <E> Encoder<E> getEncoder(String name) throws UnsupportedEncodingException {
        EncodingFormat<?> tmp = ENCODERS.get(name);
        if (tmp == null || tmp.getEncoder() == null) {
            throw new UnsupportedEncodingException(name);
        }
        return (Encoder<E>) tmp.getEncoder();
    }

    /**
     * Retrieve the decoder for the provided format name
     *
     * @param name the name of the format
     * @param <E>  the encoded type
     * @return the {@link Decoder}
     * @throws UnsupportedEncodingException if no {@link Decoder} available for the format name
     */
    @SuppressWarnings("unchecked")
    public static <E> Decoder<E> getDecoder(String name) throws UnsupportedEncodingException {
        EncodingFormat<?> tmp = ENCODERS.get(name);
        if (tmp == null || tmp.getDecoder() == null) {
            throw new UnsupportedEncodingException(name);
        }
        return (Decoder<E>) tmp.getDecoder();
    }
}
