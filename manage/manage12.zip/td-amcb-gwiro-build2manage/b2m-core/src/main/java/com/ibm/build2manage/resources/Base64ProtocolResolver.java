package com.ibm.build2manage.resources;

import lombok.extern.log4j.Log4j2;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.SpringApplicationRunListener;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.core.io.FileSystemResource;
import org.springframework.core.io.ProtocolResolver;
import org.springframework.core.io.Resource;
import org.springframework.core.io.ResourceLoader;
import org.springframework.lang.NonNull;
import org.springframework.util.FileCopyUtils;

import java.io.File;
import java.io.IOException;
import java.util.Base64;

/**
 * Implementation of {@link ProtocolResolver} that receives the content of a file through a Base64 string. This allows
 * storing binary files in vault or config server.  To specify the need for a Base64 resource, the configuration value
 * should start with <code>base64:</code>, following with the Base64 content of the Resource.
 */
@Log4j2
public class Base64ProtocolResolver implements ProtocolResolver, SpringApplicationRunListener {

    private static final String BASE64_URL_PREFIX = "base64:";
    private static final Base64.Decoder DECODER = Base64.getDecoder();

    /**
     * Constructor required by the spring framework.
     *
     * @param app  the spring application
     * @param args the command line arguments
     */
    public Base64ProtocolResolver(SpringApplication app, String[] args) {
        // Ignored but required by spring framework
    }

    @Override
    public void contextPrepared(ConfigurableApplicationContext context) {
        context.addProtocolResolver(this);
    }

    @Override
    public Resource resolve(String location, @NonNull ResourceLoader resourceLoader) {
        try {
            if (location.startsWith(BASE64_URL_PREFIX)) {
                String content = location.substring(BASE64_URL_PREFIX.length()).replaceAll("\\s+", "");
                byte[] tmp = DECODER.decode(content);
                File f = File.createTempFile("base64", null);
                f.deleteOnExit();
                FileCopyUtils.copy(tmp, f);
                return new FileSystemResource(f);
            }
        } catch (IllegalArgumentException e) {
            log.error("Unable to parse Base64 resource", e);
            throw e;
        } catch (IOException e) {
            log.error("Unable to parse Base64 resource", e);
            throw new IllegalArgumentException(e);
        }
        return null;
    }
}
