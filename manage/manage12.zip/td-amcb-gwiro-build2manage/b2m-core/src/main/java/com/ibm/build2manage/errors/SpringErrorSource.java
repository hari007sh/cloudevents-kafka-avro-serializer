package com.ibm.build2manage.errors;

import org.springframework.context.support.ResourceBundleMessageSource;
import org.springframework.lang.Nullable;

import java.util.Locale;

/**
 * Utility to standardize and simplify management of errors. The idea is to let the developer worry about managing the
 * parameters and selecting the proper error code, leaving the error message as a configuration.
 */
public class SpringErrorSource implements ErrorSource {

    private final ResourceBundleMessageSource source;
    private final Locale locale;

    /**
     * Constructor.
     *
     * @param locale the Locale the error messages are in
     * @param basenames the base name where to find the messages associated to an error code
     */
    public SpringErrorSource(Locale locale, String... basenames) {
        source = new ResourceBundleMessageSource();
        source.setBasenames(basenames);
        source.setDefaultLocale(locale);
        this.locale = locale;
    }

    @Override
    public String get(int code, @Nullable String defaultMessage, Object... args) {
        StringBuilder result = new StringBuilder().append(code);
        String tmp = source.getMessage(result.toString(), args, defaultMessage, locale);
        if (tmp == null) {
            return result.toString();
        }
        return result.append(" - ").append(tmp).toString();
    }

    @Override
    public <T> T fatal(int code, @Nullable String defaultMessage, Object... args) throws CodedException {
        throw new CodedException(code, defaultMessage, args);
    }
}
