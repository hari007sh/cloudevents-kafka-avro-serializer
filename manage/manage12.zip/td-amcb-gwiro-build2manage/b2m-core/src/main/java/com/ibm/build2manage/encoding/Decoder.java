package com.ibm.build2manage.encoding;

import java.io.IOException;
import java.util.List;

/**
 * A {@link Decoder} is a functional interface that apply some encoding logic to transfer the representation of an object
 * into another representation. It is expected that using the result of this {@link Decoder} with the associated {@link Encoder}
 * are will recover the original encoded format.
 * <p>
 * All implementations are expected to be thread safe
 * </p>
 *
 * @param <E> the encoded format
 */
@FunctionalInterface
public interface Decoder<E> {

    /**
     * Decode the provided representation into the provided.
     *
     * @param source the encoded representation of the object
     * @param tClass the class of the entity type
     * @param <T>    the type of the entity to encode
     * @return the entity
     * @throws IOException if we are unable to encode
     */
    <T> T decode(E source, Class<T> tClass) throws IOException;

    default <T> List<T> decodeList(E source, Class<T> tClass) throws IOException {
        throw new UnsupportedOperationException();
    }
}
