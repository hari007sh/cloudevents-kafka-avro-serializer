#!/bin/bash
mvn install -Dtest.unit.skipTests=true -Dtest.integration.skipTests=true
