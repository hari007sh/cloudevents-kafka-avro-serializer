package com.ibm.build2manage.mapping;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.MethodSource;
import org.junit.jupiter.params.provider.NullSource;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.UUID;
import java.util.function.ToIntFunction;

import static org.junit.jupiter.api.Assertions.*;

class CommonMapperTest {

    static Object[][] shouldMapUUID() {
        UUID random = UUID.randomUUID();
        return new Object[][]{
                {null, null},
                {random.toString(), random}
        };
    }

    @ParameterizedTest
    @MethodSource
    void shouldMapUUID(String in, UUID expected) {
        Assertions.assertEquals(expected, CommonMapper.MAPPER.map(in));
    }

    @ParameterizedTest
    @MethodSource("shouldMapUUID")
    void shouldMapObject(String expected, UUID in) {
        Assertions.assertEquals(expected, CommonMapper.MAPPER.map(in));
    }

    static Object[][] shouldMapHex() {
        ToIntFunction<String> toInt = Integer::parseInt;
        return new Object[][]{
                {Collections.emptyList(), toInt, ""},
                {List.of("1"), toInt, "1"},
                {Arrays.asList(null, "1"), toInt, ",1"},
                {Arrays.asList("1", null), toInt, "1,"},
                {Collections.singletonList(null), toInt, ""},
                {List.of("1", "2", "15"), toInt, "1,2,f"},
        };
    }

    @ParameterizedTest
    @MethodSource
    <T> void shouldMapHex(Iterable<T> iterable, ToIntFunction<T> toInt, String expected) {
        assertEquals(expected, CommonMapper.toHex(iterable, toInt));
    }

}