package com.ibm.build2manage.mapping;

import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;
import org.springframework.lang.NonNull;

import java.nio.ByteBuffer;
import java.util.UUID;
import java.util.function.Function;
import java.util.function.ToIntFunction;

/**
 * Mapper for common types.
 */
@Mapper(componentModel = "spring")
public interface CommonMapper {

    CommonMapper MAPPER = Mappers.getMapper(CommonMapper.class);

    /**
     * Maps a string into a UUID. This should eventually be <a href="https://github.com/mapstruct/mapstruct/issues/2391">integrated
     * inside MapStruct</a> so it may be removed in the future.
     *
     * @param value the string value of the UUID
     * @return the UUID
     */
    default java.util.UUID map(String value) {
        return value == null ? null : UUID.fromString(value);
    }

    /**
     * Maps an UUID into a string.
     *
     * @param value the value
     * @return null or the UUID as string
     */
    default String map(UUID value) {
        return value == null ? null : value.toString();
    }

    /**
     * Maps a UUID into its byte representation.
     *
     * @param value the UUID
     * @return null or the UUID binary representation
     */
    default byte[] toBytes(UUID value) {
        return value == null ?
                null :
                ByteBuffer
                        .wrap(new byte[16])
                        .putLong(value.getMostSignificantBits())
                        .putLong(value.getLeastSignificantBits())
                        .array();
    }

    /**
     * Maps a UUID from its binary representation.
     *
     * @param bytes the binary representation
     * @return the UUID
     */
    default UUID fromBytes(byte[] bytes) {
        if (bytes == null) {
            return null;
        } else if (bytes.length != 16) {
            throw new IllegalArgumentException("UUID binary representation should be 16 bytes in length");
        }
        ByteBuffer buffer = ByteBuffer.wrap(bytes);
        return new UUID(buffer.getLong(), buffer.getLong());
    }

    /**
     * Converts an integer into its hexadecimal representation.
     *
     * @param i the integer value
     * @return the hexadecimal representation in lowercase
     */
    static String toHex(int i) {
        return Integer.toHexString(i);
    }

    /**
     * Converts an iterable of object into a String. The provided function will be called on each element to extract
     * the integer value that needs to be transformed. If a null element is provided, the value will be omitted but the
     * comma will be added (e.g. 0,,0).
     *
     * @param iterable the list of element
     * @param fct      the function to convert the provided element in an integer.
     * @param <T>      the type of element to transform
     * @return the hexadecimal representations in lowercase
     */
    static <T> String toHex(@NonNull Iterable<T> iterable, @NonNull ToIntFunction<T> fct) {
        StringBuilder sb = new StringBuilder();
        for (T i : iterable) {
            sb.append(i == null ? "" : toHex(fct.applyAsInt(i))).append(',');
        }
        // Remove the last comma
        if (sb.length() != 0) {
            sb.setLength(sb.length() - 1);
        }
        return sb.toString();
    }

}
