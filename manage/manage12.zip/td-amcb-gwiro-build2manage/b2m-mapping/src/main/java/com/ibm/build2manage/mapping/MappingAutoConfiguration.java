package com.ibm.build2manage.mapping;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

/**
 * Auto configuration for mapping utilities. Since most of the utilities are generated using the mapstruct annotations,
 * this module uses {@link ComponentScan} to make those beans available to spring. This may, in the future, cause some
 * issues by making applications fat. If this occurs, the module may need refactoring to specify which component is
 * required.
 */
@Configuration
@ComponentScan
public class MappingAutoConfiguration {
}
