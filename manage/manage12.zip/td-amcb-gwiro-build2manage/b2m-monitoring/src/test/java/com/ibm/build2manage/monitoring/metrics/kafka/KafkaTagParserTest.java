package com.ibm.build2manage.monitoring.metrics.kafka;

import io.micrometer.core.instrument.Meter;
import io.micrometer.core.instrument.Tags;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.kafka.listener.ContainerProperties;
import org.springframework.kafka.support.TopicPartitionOffset;

import java.util.ArrayList;
import java.util.regex.Pattern;

import static org.junit.jupiter.api.Assertions.*;

@ExtendWith(MockitoExtension.class)
class KafkaTagParserTest {

    private static final KafkaTagParser UNDER_TEST = new KafkaTagParser();

    void assertContainerTags(Tags tags, String topics, String pattern, String partitions, String groupId) {
        // Easier to test through Meter.Id.getTag()
        Meter.Id actual = new Meter.Id("", tags, null, null, Meter.Type.COUNTER);
        assertEquals(topics, actual.getTag("topics"));
        assertEquals(pattern, actual.getTag("pattern"));
        assertEquals(partitions, actual.getTag("partitions"));
        assertEquals(groupId, actual.getTag("groupId"));
    }

    void assertConsumerRecordTags(Tags tags, String topic, int partition) {
        Meter.Id actual = new Meter.Id("", tags, null, null, Meter.Type.COUNTER);
        assertEquals(topic, actual.getTag("topic"));
        assertEquals(String.valueOf(partition), actual.getTag("partition"));
    }

    @ParameterizedTest
    @CsvSource(value = {
            "something,something",
            "'something,else','[something,else]'",
    }, nullValues = "null")
    void testTopics(String topics, String expected) {
        Tags tags = Tags.of(UNDER_TEST.addTags(new ArrayList<>(), new ContainerProperties(topics.split(","))));
        assertContainerTags(tags, expected, null, null, null);
    }

    @ParameterizedTest
    @CsvSource(value = {
            "something,something",
    }, nullValues = "null")
    void testTopicPattern(String pattern, String expected) {
        Tags tags = Tags.of(UNDER_TEST.addTags(new ArrayList<>(), new ContainerProperties(Pattern.compile(pattern))));
        assertContainerTags(tags, null, expected, null, null);
    }

    @ParameterizedTest
    @CsvSource(value = {
            "something,2,10,'TopicPartitionOffset{topicPartition=something-2, offset=10, relativeToCurrent=false}'",
            "'something,else','2,4','1000,2500','[TopicPartitionOffset{topicPartition=something-2, offset=1000, relativeToCurrent=false},TopicPartitionOffset{topicPartition=else-4, offset=2500, relativeToCurrent=false}]'",
    }, nullValues = "null")
    void testPartitions(String topics, String partitions, String offsets, String expected) {
        String[] t = topics.split(",");
        String[] p = partitions.split(",");
        String[] o = offsets.split(",");
        assertEquals(t.length, o.length, "Parameters size do not match");
        assertEquals(p.length, o.length, "Parameters size do not match");
        TopicPartitionOffset[] tpo = new TopicPartitionOffset[t.length];
        for (int i = 0; i < t.length; i++) {
            tpo[i] = new TopicPartitionOffset(t[i], Integer.parseInt(p[i]), Long.parseLong(o[i]));
        }
        ContainerProperties prop = new ContainerProperties(tpo);
        Tags tags = Tags.of(UNDER_TEST.addTags(new ArrayList<>(), prop));
        assertContainerTags(tags, null, null, expected, null);
    }

    @ParameterizedTest
    @CsvSource(value = {
            "'',''",
            "something,something",
    }, nullValues = "null")
    void testGroupId(String groupId, String expected) {
        ContainerProperties prop = new ContainerProperties("topics");
        prop.setGroupId(groupId);
        Tags tags = Tags.of(UNDER_TEST.addTags(new ArrayList<>(), prop));
        assertContainerTags(tags, "topics", null, null, expected);
    }

    @ParameterizedTest
    @CsvSource(value = {
            "'',0",
            "'',1",
            "something,1",
            "something,0",
    }, nullValues = "null")
    void testTopic(String topic, int partition) {
        ConsumerRecord<Object, Object> consumerRecord = new ConsumerRecord<>(topic, partition, 0, null, null);
        Tags tags = Tags.of(UNDER_TEST.addTags(new ArrayList<>(), consumerRecord));
        assertConsumerRecordTags(tags, topic, partition);
    }
}