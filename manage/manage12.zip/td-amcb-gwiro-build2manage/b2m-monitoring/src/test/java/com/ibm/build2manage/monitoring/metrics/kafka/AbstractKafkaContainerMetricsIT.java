package com.ibm.build2manage.monitoring.metrics.kafka;

import com.ibm.build2manage.kafka.KafkaTest;
import com.ibm.build2manage.kafka.PublishSpecification;
import com.ibm.build2manage.monitoring.metrics.MetricAssertions;
import lombok.RequiredArgsConstructor;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Import;
import org.springframework.kafka.config.ConcurrentKafkaListenerContainerFactory;
import org.springframework.kafka.config.KafkaListenerEndpointRegistry;

import javax.annotation.PostConstruct;

@KafkaTest
@RequiredArgsConstructor
@Import(MetricAssertions.class)
abstract class AbstractKafkaContainerMetricsIT {

    private final String max;
    private final String active;

    @Value("${spring.application.name}")
    private String topic;

    @Autowired
    private MetricAssertions metrics;

    @Autowired
    private KafkaContainerMetrics<Object, Object> underTest;

    @Autowired
    private KafkaListenerEndpointRegistry registry;

    @Autowired
    private ConcurrentKafkaListenerContainerFactory<Object, Object> factory;

    @PostConstruct
    public void initCustomizer() {
        factory.setContainerCustomizer(underTest);
    }

    @Test
    void metersAreRegistered() {
        PublishSpecification.given(topic)
                .then(registry, factory);
        metrics.assertGauge(1.0, max, "topics", topic);
        metrics.assertGauge(1.0, active, "topics", topic);
    }

}
