package com.ibm.build2manage.monitoring.metrics;

import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest(classes = MetricsAutoConfiguration.class, properties = {
        "b2m-monitoring-test.valid=changed",
        "b2m-monitoring-test.deprecated=changed",
        "b2m-monitoring-test.deprecation=changed",
})
class ConfigurationMetricsOverriddenIT extends AbstractConfigurationMetricsIT {

    ConfigurationMetricsOverriddenIT() {
        super(2, -1, -1);
    }
}