package com.ibm.build2manage.monitoring.metrics;

import lombok.RequiredArgsConstructor;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.aop.target.PoolingConfig;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.annotation.Import;

import org.springframework.boot.autoconfigure.EnableAutoConfiguration;

@EnableAutoConfiguration
@RequiredArgsConstructor
@Import(MetricAssertions.class)
abstract class AbstractPoolUtilizationMetricsIT {

    @MockBean(name = "pool1")
    private PoolingConfig pool1;

    @MockBean(name = "pool2")
    private PoolingConfig pool2;

    @Autowired
    private MetricAssertions metrics;

    private final String active;
    private final String max;
    private final String tagName;

    AbstractPoolUtilizationMetricsIT() {
        this("pooling active", "pooling max", "name");
    }

    @Test
    void validatePool1ActiveCount() {
        int i = (int) (Math.random() * 10000);
        Mockito.when(pool1.getActiveCount()).thenReturn(i);
        metrics.assertGauge(i, active, tagName, "pool1");
    }

    @Test
    void validatePool2ActiveCount() {
        int i = (int) (Math.random() * 10000);
        Mockito.when(pool2.getActiveCount()).thenReturn(i);
        metrics.assertGauge(i, active, tagName, "pool2");
    }

    @Test
    void validatePool1MaxCount() {
        int i = (int) (Math.random() * 10000);
        Mockito.when(pool1.getMaxSize()).thenReturn(i);
        metrics.assertGauge(i, max, tagName, "pool1");
    }

    @Test
    void validatePool2MaxCount() {
        int i = (int) (Math.random() * 10000);
        Mockito.when(pool2.getMaxSize()).thenReturn(i);
        metrics.assertGauge(i, max, tagName, "pool2");
    }
}