package com.ibm.build2manage.monitoring.metrics.kafka;

import com.ibm.build2manage.kafka.KafkaTest;
import com.ibm.build2manage.kafka.PublishSpecification;
import com.ibm.build2manage.monitoring.metrics.KafkaMetricsAutoConfiguration;
import com.ibm.build2manage.monitoring.metrics.MetricAssertions;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.annotation.Import;
import org.springframework.kafka.config.ConcurrentKafkaListenerContainerFactory;
import org.springframework.kafka.config.KafkaListenerEndpointRegistry;

@KafkaTest
@SpringBootTest(classes = KafkaMetricsAutoConfiguration.class, properties = {
        "spring.kafka.consumer.auto-offset-reset=earliest"
})
@Import(MetricAssertions.class)
class SpringKafkaListenerTagsIT {

    @Value("${spring.application.name}")
    private String topic;

    @Autowired
    private KafkaListenerEndpointRegistry registry;

    @Autowired
    private ConcurrentKafkaListenerContainerFactory<Object, Object> factory;

    @Autowired
    private MetricAssertions metrics;

    @Test
    void metersAreModified() {
        PublishSpecification.given(topic)
                .then(registry, factory);
        // If we find a meter by topic name, it means the filter was applied
        Assertions.assertNotNull(metrics.getMeter("spring.kafka.listener", "topics", topic));
    }

}
