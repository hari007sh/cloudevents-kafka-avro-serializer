package com.ibm.build2manage.monitoring.metrics;

import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest(classes = MetricsAutoConfiguration.class, properties = {
        "b2m-monitoring.metrics.pool-active=active",
        "b2m-monitoring.metrics.pool-max=max",
        "b2m-monitoring.metrics.pool-tag-name=something"
})
public class PoolUtilizationMetricsConfigChangesIT extends AbstractPoolUtilizationMetricsIT {

    PoolUtilizationMetricsConfigChangesIT() {
        super("active", "max", "something");
    }

}
