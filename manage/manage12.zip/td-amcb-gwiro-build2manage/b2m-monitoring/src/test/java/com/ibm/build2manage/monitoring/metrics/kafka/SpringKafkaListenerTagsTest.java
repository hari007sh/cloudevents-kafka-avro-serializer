package com.ibm.build2manage.monitoring.metrics.kafka;

import io.micrometer.core.instrument.Meter;
import io.micrometer.core.instrument.Tag;
import io.micrometer.core.instrument.Tags;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.MethodSource;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.kafka.config.KafkaListenerEndpointRegistry;
import org.springframework.kafka.listener.ContainerProperties;
import org.springframework.kafka.listener.MessageListenerContainer;

import java.util.Collections;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;

@ExtendWith(MockitoExtension.class)
class SpringKafkaListenerTagsTest {

    @Mock
    private KafkaListenerEndpointRegistry registry;

    @Mock
    private MessageListenerContainer container;

    @Mock
    private KafkaTagParser parser;

    @InjectMocks
    private SpringKafkaListenerTags underTest;

    private final String id = UUID.randomUUID().toString();

    private final String name = id + "-" + ((int) (Math.random() * 10));

    @Test
    void testTagsAdded() {
        ContainerProperties prop = Mockito.mock(ContainerProperties.class);

        Tag expected = Tag.of(UUID.randomUUID().toString(),
                UUID.randomUUID().toString());

        Mockito.when(container.getListenerId()).thenReturn(id);
        Mockito.when(registry.getListenerContainers()).thenReturn(Collections.singleton(container));
        Mockito.when(container.getContainerProperties()).thenReturn(prop);
        Mockito.when(parser.addTags(any(), eq(prop))).thenReturn(Collections.singletonList(expected));

        Meter.Id actual = underTest.map(new Meter.Id("spring.kafka.listener", Tags.of("name", name), null, null, Meter.Type.COUNTER));
        assertEquals(name, actual.getTag("name"));
        assertEquals(expected.getValue(), actual.getTag(expected.getKey()));
    }

    static Object[][] shouldNotModify() {
        return new Object[][]{
                {new Meter.Id(UUID.randomUUID().toString(), Tags.empty(), null, null, Meter.Type.COUNTER)},
                {new Meter.Id("spring.kafka.listener", Tags.empty(), null, null, Meter.Type.COUNTER)},
        };
    }

    @MethodSource
    @ParameterizedTest
    void shouldNotModify(Meter.Id expected) {
        assertSame(expected, underTest.map(expected));
    }

    @Test
    void shouldNotModifyWhenNoContainerFound() {
        Meter.Id expected = new Meter.Id("spring.kafka.listener", Tags.of("name", UUID.randomUUID().toString()), null, null, Meter.Type.COUNTER);
        Mockito.when(registry.getListenerContainers()).thenReturn(Collections.singletonList(container));
        assertSame(expected, underTest.map(expected));
    }
}