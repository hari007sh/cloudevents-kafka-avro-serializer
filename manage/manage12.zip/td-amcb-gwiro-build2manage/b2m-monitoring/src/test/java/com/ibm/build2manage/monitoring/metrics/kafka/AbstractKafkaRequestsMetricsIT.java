package com.ibm.build2manage.monitoring.metrics.kafka;

import com.google.common.util.concurrent.AtomicDouble;
import com.ibm.build2manage.kafka.EventValidation;
import com.ibm.build2manage.kafka.KafkaTest;
import com.ibm.build2manage.kafka.PublishSpecification;
import com.ibm.build2manage.monitoring.metrics.MetricAssertions;
import lombok.RequiredArgsConstructor;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Import;
import org.springframework.kafka.config.ConcurrentKafkaListenerContainerFactory;
import org.springframework.kafka.config.KafkaListenerEndpointRegistry;
import org.springframework.kafka.core.KafkaTemplate;

import javax.annotation.PostConstruct;
import java.util.concurrent.TimeUnit;

import static org.junit.jupiter.api.Assertions.assertEquals;

@KafkaTest
@RequiredArgsConstructor
@Import(MetricAssertions.class)
abstract class AbstractKafkaRequestsMetricsIT {

    @Value("${spring.application.name}")
    private String topic;

    @Autowired
    private MetricAssertions metrics;

    private final String activeCount;
    private final String lastOffset;

    @Autowired
    private KafkaRequestsMetrics<Object, Object> underTest;

    @Autowired
    private KafkaListenerEndpointRegistry registry;

    @Autowired
    private KafkaTemplate<Object, Object> kafka;

    @Autowired
    private ConcurrentKafkaListenerContainerFactory<Object, Object> factory;

    @PostConstruct
    public void initInterceptor() {
        factory.setRecordInterceptor(underTest);
    }

    @Test
    void shouldRecordLastOffset() {
        final AtomicDouble count = new AtomicDouble();
        EventValidation<Object, Object> tmp = PublishSpecification.given(topic)
                .send(kafka)
                .onEvent(r -> {
                    count.set(metrics.getGauge(activeCount, "topic", topic).value());
                })
                .then(registry, factory)
                .waitAtMost(10, TimeUnit.SECONDS);
        assertEquals(1.0, count.get());
        metrics.assertGauge(0.0, activeCount, "topic", topic);
        metrics.assertGauge(tmp.getData().offset(), lastOffset, "topic", topic);
    }
}