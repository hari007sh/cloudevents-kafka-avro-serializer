package com.ibm.build2manage.monitoring.metrics.web;

import io.micrometer.core.instrument.Tags;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpHeaders;

import javax.servlet.http.HttpServletRequest;

import static org.junit.jupiter.api.Assertions.*;

@ExtendWith(MockitoExtension.class)
class OriginTagContributorTest {

    private static final OriginTagContributor UNDER_TEST = new OriginTagContributor();

    @Mock
    private HttpServletRequest request;

    @ParameterizedTest
    @CsvSource(value = {
            "null,unknown",
            "agent,agent",
            "agent(with comment no space),agent",
            "agent (with comment and space),agent",
            "agent            (with comment and spaces),agent",
            "agent (with) multiple (comments),agent",
            "agent (with) multiple (comments),agent",
            "agent/version,agent/version",
            "agent/version(with comment no space),agent/version",
            "agent/version (with comment and space),agent/version",
            "agent/version            (with comment and spaces),agent/version",
            "agent/version (with) multiple (comments),agent/version",
            "agent/version (with) multiple (comments),agent/version",
    }, nullValues = "null")
    void testGetTags(String header, String expected) {
        Mockito.when(request.getHeader(HttpHeaders.USER_AGENT)).thenReturn(header);
        assertEquals(Tags.of("origin", expected), UNDER_TEST.getTags(request, null, null, null));
    }

    @Test
    void doesNotSupportLongRequests() {
        assertNull(UNDER_TEST.getLongRequestTags(request, null));
    }

}