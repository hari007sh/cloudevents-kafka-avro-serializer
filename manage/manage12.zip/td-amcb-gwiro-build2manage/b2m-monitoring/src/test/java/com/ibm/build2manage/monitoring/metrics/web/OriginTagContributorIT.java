package com.ibm.build2manage.monitoring.metrics.web;

import com.ibm.build2manage.monitoring.metrics.MetricAssertions;
import com.ibm.build2manage.monitoring.metrics.WebMetricsAutoConfiguration;
import com.ibm.build2manage.web.AbstractWebTest;
import io.micrometer.core.instrument.search.MeterNotFoundException;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.annotation.Import;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;

import java.util.UUID;

import static org.junit.jupiter.api.Assertions.*;

@EnableAutoConfiguration
@Import(MetricAssertions.class)
@SpringBootTest(classes = WebMetricsAutoConfiguration.class, properties = {
        "spring.application.name=OriginTagContributorIT",
        "test.path=/origin-tag"
}, webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
class OriginTagContributorIT extends AbstractWebTest {

    private final String agent = UUID.randomUUID().toString();

    @Autowired
    private MetricAssertions metrics;

    @Test
    void doSomething() {
        // Verify that the meter does not exists prior to request
        assertThrows(MeterNotFoundException.class, () -> metrics.getMeter("http.server.requests.histogram", "origin", "unknown"));
        assertEquals("Success!",
                given(r -> ResponseEntity.ok("Success!"))
                        .header(HttpHeaders.USER_AGENT, agent)
                        .when()
                        .get(mockPath)
                        .then()
                        .statusCode(200)
                        .and().extract().body().asString());
        // Verify that the origin tag was added to the meter
        assertNotNull(metrics.getMeter("http.server.requests.histogram", "origin", agent));
    }

}
