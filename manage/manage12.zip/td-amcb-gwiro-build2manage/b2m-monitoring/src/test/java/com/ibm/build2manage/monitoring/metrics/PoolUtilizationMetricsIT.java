package com.ibm.build2manage.monitoring.metrics;

import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest(classes = MetricsAutoConfiguration.class)
public class PoolUtilizationMetricsIT extends AbstractPoolUtilizationMetricsIT {

}
