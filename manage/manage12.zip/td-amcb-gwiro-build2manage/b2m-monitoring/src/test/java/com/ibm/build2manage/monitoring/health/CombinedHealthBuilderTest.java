package com.ibm.build2manage.monitoring.health;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.boot.actuate.health.Health;

import java.util.UUID;

import static org.springframework.boot.actuate.health.Status.*;

class CombinedHealthBuilderTest {

    private final String k1 = UUID.randomUUID().toString();
    private final String k2 = UUID.randomUUID().toString();

    private CombinedHealthBuilder create() {
        return new CombinedHealthBuilder(StatusComparatorTest.UNDER_TEST);
    }

    private void assertEquals(Health.Builder expected, CombinedHealthBuilder actual) {
        Assertions.assertEquals(expected.build(), actual.build());
    }

    @Test
    void noUpdateReturnsUP() {
        assertEquals(Health.up(), create());
    }

    @Test
    void updateWithOneComponent() {
        assertEquals(Health.down().withDetail(k1, DOWN),
                create().update(k1, DOWN));
    }

    @Test
    void updateDownToUpShouldStaysDown() {
        assertEquals(Health.down().withDetail(k1, DOWN).withDetail(k2, UP),
                create().update(k1, DOWN).update(k2, UP));
    }

}