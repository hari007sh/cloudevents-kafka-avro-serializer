package com.ibm.build2manage.monitoring.metrics.kafka;

import com.ibm.build2manage.monitoring.metrics.KafkaMetricsAutoConfiguration;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest(classes = KafkaMetricsAutoConfiguration.class, properties = {
        "spring.kafka.consumer.auto-offset-reset=earliest",
        "b2m-monitoring.metrics.kafka-requests-last-offset=something else",
        "b2m-monitoring.metrics.kafka-requests-alive-count=another alive count"
})
public class KafkaRequestsMetricsConfigChangedIT extends AbstractKafkaRequestsMetricsIT {

    public KafkaRequestsMetricsConfigChangedIT() {
        super("another alive count", "something else");
    }
}
