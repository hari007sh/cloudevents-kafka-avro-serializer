package com.ibm.build2manage.monitoring.health;

import com.ibm.build2manage.Thresholds;
import com.ibm.build2manage.monitoring.health.MetricBasedHealthIndicator.MetricHealthIndicator;
import io.micrometer.core.instrument.*;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.MethodSource;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.boot.actuate.health.Health;
import org.springframework.boot.actuate.health.Status;

import java.util.Collections;
import java.util.List;

import static com.ibm.build2manage.monitoring.health.ComparisonMethod.RATIO;
import static com.ibm.build2manage.monitoring.health.ComparisonMethod.RAW;
import static java.util.Arrays.asList;
import static java.util.Collections.singletonList;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.springframework.boot.actuate.health.Status.*;

@ExtendWith(MockitoExtension.class)
class MetricBasedHealthIndicatorTest {

    private static final StatusComparator COMPARATOR = new StatusComparator(asList("down", "degraded", "unknown", "up"));
    private static final Thresholds<Status> THRESHOLDS = new Thresholds<>(UP, 1)
            .with(5.0, DOWN);

    private static final Counter C0 = counter(0.0, Tags.empty());
    private static final Gauge G0 = gauge(0.0, Tags.empty());
    private static final Counter C0_TAGGED = counter(0.0, Tags.of("key", "value"));
    private static final Gauge G0_TAGGED = gauge(0.0, Tags.of("key", "value"));

    private static final Counter C1 = counter(1.0, Tags.empty());
    private static final Gauge G1 = gauge(1.0, Tags.empty());
    private static final Counter C1_TAGGED = counter(1.0, Tags.of("key", "value"));
    private static final Gauge G1_TAGGED = gauge(1.0, Tags.of("key", "value"));

    private static final Counter C5 = counter(5.0, Tags.empty());
    private static final Gauge G5 = gauge(5.0, Tags.empty());
    private static final Counter C5_TAGGED = counter(5.0, Tags.of("key", "value"));
    private static final Gauge G5_TAGGED = gauge(5.0, Tags.of("key", "value"));

    @Mock
    private MeterRegistry registry;

    private static Gauge gauge(double v, Tags tags) {
        Gauge g = Mockito.mock(Gauge.class);
        Mockito.when(g.value()).thenReturn(v);
        Mockito.when(g.getId()).thenReturn(new Meter.Id("Gauge", tags, null, null, Meter.Type.GAUGE));
        return g;
    }

    private static Counter counter(double v, Tags tags) {
        Counter c = Mockito.mock(Counter.class);
        Mockito.when(c.count()).thenReturn(v);
        Mockito.when(c.getId()).thenReturn(new Meter.Id("Counter", tags, null, null, Meter.Type.COUNTER));
        return c;
    }

    static MetricHealthIndicator indicator(String name, String comparedTo, ComparisonMethod method) {
        return new MetricHealthIndicator(name, comparedTo, method, THRESHOLDS);
    }

    static Object[][] singleRawIndicator() {
        return new Object[][]{
                {singletonList(indicator("Counter", null, RAW)), singletonList(C0), Health.up().withDetail(C0.getId().toString(), UP)},
                {singletonList(indicator("Gauge", null, RAW)), singletonList(G0), Health.up().withDetail(G0.getId().toString(), UP)},
                {singletonList(indicator("Counter", null, RAW)), singletonList(C5), Health.status(DOWN).withDetail(C5.getId().toString(), DOWN)},
                {singletonList(indicator("Gauge", null, RAW)), singletonList(G5), Health.status(DOWN).withDetail(G5.getId().toString(), DOWN)},

                // Multiple meters with different tags
                {singletonList(indicator("Counter", null, RAW)), asList(C0, C0_TAGGED), Health.up().withDetail(C0.getId().toString(), UP).withDetail(C0_TAGGED.getId().toString(), UP)},
                {singletonList(indicator("Counter", null, RAW)), asList(C0_TAGGED, C0), Health.up().withDetail(C0.getId().toString(), UP).withDetail(C0_TAGGED.getId().toString(), UP)},
                {singletonList(indicator("Gauge", null, RAW)), asList(G0, G0_TAGGED), Health.up().withDetail(G0.getId().toString(), UP).withDetail(G0_TAGGED.getId().toString(), UP)},
                {singletonList(indicator("Gauge", null, RAW)), asList(G0_TAGGED, G0), Health.up().withDetail(G0.getId().toString(), UP).withDetail(G0_TAGGED.getId().toString(), UP)},

                // Test combined health
                {singletonList(indicator("Counter", null, RAW)), asList(C0, C5_TAGGED), Health.status(DOWN).withDetail(C0.getId().toString(), UP).withDetail(C5_TAGGED.getId().toString(), DOWN)},
                {singletonList(indicator("Gauge", null, RAW)), asList(G0, G5_TAGGED), Health.status(DOWN).withDetail(G0.getId().toString(), UP).withDetail(G5_TAGGED.getId().toString(), DOWN)},
        };
    }

    static Object[][] dualRawIndicators() {
        return new Object[][]{
                {asList(indicator("Counter", null, RAW), indicator("Gauge", null, RAW)), asList(C0, G0), Health.up().withDetail(C0.getId().toString(), UP).withDetail(G0.getId().toString(), UP)},
                {asList(indicator("Counter", null, RAW), indicator("Gauge", null, RAW)), asList(C5, G0), Health.down().withDetail(C5.getId().toString(), DOWN).withDetail(G0.getId().toString(), UP)},

                // Test returns with two set of tags
                {asList(indicator("Counter", null, RAW), indicator("Gauge", null, RAW)), asList(C0, C0_TAGGED, G0, G0_TAGGED), Health.up()
                        .withDetail(C0.getId().toString(), UP)
                        .withDetail(C0_TAGGED.getId().toString(), UP)
                        .withDetail(G0.getId().toString(), UP)
                        .withDetail(G0_TAGGED.getId().toString(), UP)},
                {asList(indicator("Counter", null, RAW), indicator("Gauge", null, RAW)), asList(C5, C0_TAGGED, G0, G5_TAGGED), Health.down()
                        .withDetail(C5.getId().toString(), DOWN)
                        .withDetail(C0_TAGGED.getId().toString(), UP)
                        .withDetail(G0.getId().toString(), UP)
                        .withDetail(G5_TAGGED.getId().toString(), DOWN)},
        };
    }

    static Object[][] ratioIndicators() {
        return new Object[][]{
                {singletonList(indicator("Counter", "Gauge", RATIO)), asList(C0, G1), Health.up().withDetail(C0.getId().toString() + " relative to " + G1.getId().toString(), UP)},
                {singletonList(indicator("Gauge", "Counter", RATIO)), asList(G5, C1), Health.down().withDetail(G5.getId().toString() + " relative to " + C1.getId().toString(), DOWN)},

                {singletonList(indicator("Counter", "Gauge", RATIO)), asList(C0, C5_TAGGED, G1, G1_TAGGED), Health.down().withDetail(C0.getId().toString() + " relative to " + G1.getId().toString(), UP).withDetail(C5_TAGGED.getId().toString() + " relative to " + G1_TAGGED.getId().toString(), DOWN)},
                {singletonList(indicator("Gauge", "Counter", RATIO)), asList(G1, G5_TAGGED, C1, C1_TAGGED), Health.down().withDetail(G5_TAGGED.getId().toString() + " relative to " + C1_TAGGED.getId().toString(), DOWN).withDetail(G1.getId().toString() + " relative to " + C1.getId().toString(), UP)},

                {asList(indicator("Counter", "Gauge", RATIO), indicator("Gauge", "Counter", RATIO)), asList(C1, G1), Health.up().withDetail(C1.getId().toString() + " relative to " + G1.getId().toString(), UP).withDetail(G1.getId().toString() + " relative to " + C1.getId().toString(), UP)},
                {asList(indicator("Counter", "Gauge", RATIO), indicator("Gauge", "Counter", RATIO)), asList(C5, G1), Health.down().withDetail(C5.getId().toString() + " relative to " + G1.getId().toString(), DOWN).withDetail(G1.getId().toString() + " relative to " + C5.getId().toString(), UP)},
        };
    }

    static Object[][] errors() {
        return new Object[][]{
                {singletonList(indicator("Gauge", null, RAW)), singletonList(C1), Health.unknown().withDetail("Gauge", UNKNOWN)},
                {singletonList(indicator("Gauge", "Counter", RATIO)), singletonList(G1), Health.unknown().withDetail(G1.getId().toString(), UNKNOWN)},
                {singletonList(indicator("Gauge", "Counter", RATIO)), asList(G1_TAGGED, C1), Health.unknown().withDetail(G1_TAGGED.getId().toString(), UNKNOWN)},
                {singletonList(indicator("Gauge", "Counter", RATIO)), asList(G1, G1_TAGGED, C1), Health.unknown().withDetail(G1.getId().toString() + " relative to " + C1.getId().toString(), UP).withDetail(G1_TAGGED.getId().toString(), UNKNOWN)},
        };
    }

    void assertHealth(Health.Builder expected, List<MetricHealthIndicator> indicators) {
        MetricBasedHealthIndicator underTest = new MetricBasedHealthIndicator(registry, indicators, COMPARATOR);
        assertEquals(expected.build(), underTest.health());
    }

    @Test
    void noIndicatorReturnsHealthy() {
        assertHealth(Health.up(), Collections.emptyList());
    }

    @ParameterizedTest
    @MethodSource({
            "singleRawIndicator",
            "dualRawIndicators",
            "ratioIndicators",
            "errors"
    })
    void validateHealth(List<MetricHealthIndicator> indicators, List<Meter> meters, Health.Builder expected) {
        Mockito.when(registry.getMeters()).thenReturn(meters);
        Mockito.when(registry.get(any())).thenCallRealMethod();
        assertHealth(expected, indicators);
    }
}