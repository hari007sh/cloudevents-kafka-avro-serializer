package com.ibm.build2manage.monitoring.metrics;

import lombok.RequiredArgsConstructor;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Import;

import org.springframework.boot.autoconfigure.EnableAutoConfiguration;

@EnableAutoConfiguration
@RequiredArgsConstructor
@Import(MetricAssertions.class)
abstract class AbstractConfigurationMetricsIT {

    @Autowired
    private MetricAssertions metrics;

    private final String name;

    private final String tagName;

    private final int valid;

    private final int deprecated;

    private final int deprecation;

    AbstractConfigurationMetricsIT(int valid, int deprecated, int deprecation) {
        this("service configuration status", "property", valid, deprecated, deprecation);
    }

    @Test
    void validConfiguration() {
        metrics.assertCounter(valid, name, tagName, "b2m-monitoring-test.valid");
    }

    @Test
    void deprecatedConfiguration() {
        metrics.assertCounter(deprecated, name, tagName, "b2m-monitoring-test.deprecated");
    }

    @Test
    void deprecationConfiguration() {
        metrics.assertCounter(deprecation, name, tagName, "b2m-monitoring-test.deprecation");
    }
}