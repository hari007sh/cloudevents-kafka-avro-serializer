package com.ibm.build2manage.monitoring.metrics.kafka;

import io.micrometer.core.instrument.MeterRegistry;
import io.micrometer.core.instrument.Tag;
import org.apache.kafka.clients.consumer.Consumer;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.function.ToDoubleFunction;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;

@ExtendWith(MockitoExtension.class)
class KafkaRequestsMetricsTest {

    private final String activeCount = UUID.randomUUID().toString();

    private final String lastProcessed = UUID.randomUUID().toString();

    private final String topic = UUID.randomUUID().toString();

    private final int partition = (int) (Math.random() * 1000);

    private final long offset = (int) (Math.random() * 1000);

    private final ConsumerRecord<Object, Object> consumerRecord = new ConsumerRecord<>(topic, partition, offset, null, null);

    private final List<Tag> tags = new ArrayList<>();

    @Captor
    private ArgumentCaptor<Object> target;

    @Captor
    private ArgumentCaptor<ToDoubleFunction<Object>> fct;

    @Mock
    private MeterRegistry registry;

    @Mock
    private KafkaTagParser parser;

    @Mock
    private Consumer<Object, Object> consumer;

    private KafkaRequestsMetrics<Object, Object> underTest;

    @BeforeEach
    void init() {
        underTest = new KafkaRequestsMetrics<>(registry, parser, activeCount, lastProcessed);
        Mockito.when(parser.addTags(any(), any(ConsumerRecord.class))).thenReturn(tags);
    }

    private double getValue() {
        return fct.getValue().applyAsDouble(target.getValue());
    }

    @Test
    void incrementActiveOnIntercept() {
        assertSame(consumerRecord, underTest.intercept(consumerRecord));
        Mockito.verify(registry, Mockito.times(1)).gauge(eq(activeCount), eq(tags), target.capture(), fct.capture());
        assertEquals(1.0, getValue());
    }

    @Test
    void decrementActiveAfterRecord() {
        incrementActiveOnIntercept();
        underTest.afterRecord(consumerRecord, consumer);
        assertEquals(0.0, getValue());
    }

    @Test
    void activeDoesNotGoNegative() {
        underTest.afterRecord(consumerRecord, consumer);
        Mockito.verify(registry, Mockito.times(1)).gauge(eq(activeCount), eq(tags), target.capture(), fct.capture());
        assertEquals(0.0, getValue());
    }

    @Test
    void nonExistingGaugeCreated() {
        underTest.afterRecord(consumerRecord, consumer);
        Mockito.verify(registry, Mockito.times(1)).gauge(eq(lastProcessed), eq(tags), target.capture(), fct.capture());
        assertEquals(offset, getValue());
    }

    @Test
    void existingNotRecreated() {
        nonExistingGaugeCreated();
        Mockito.reset(registry);
        underTest.afterRecord(consumerRecord, consumer);
        Mockito.verifyNoInteractions(registry);
    }

    @Test
    void offsetUpdatedOnlyIfMoreRecent() {
        nonExistingGaugeCreated();
        underTest.afterRecord(new ConsumerRecord<>(topic, partition, offset - 10, null, null), consumer);
        assertEquals(offset, getValue());
    }

    @Test
    void differentTopicCreatesNewGauge() {
        underTest.afterRecord(consumerRecord, consumer);
        underTest.afterRecord(new ConsumerRecord<>(UUID.randomUUID().toString(), partition, offset, null, null), consumer);
        Mockito.verify(registry, Mockito.times(2)).gauge(eq(lastProcessed), eq(tags), any(), any());
    }

    @Test
    void differentPartitionCreatesNewGauge() {
        underTest.afterRecord(consumerRecord, consumer);
        underTest.afterRecord(new ConsumerRecord<>(topic, partition + 10, offset, null, null), consumer);
        Mockito.verify(registry, Mockito.times(2)).gauge(eq(lastProcessed), eq(tags), any(), any());
    }

}