package com.ibm.build2manage.monitoring.health;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.springframework.boot.actuate.health.Status;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class StatusComparatorTest {

    private static final List<String> STATUSES = Arrays.asList("down", "out-of-service", "degraded", "unknown", "up");

    public static final StatusComparator UNDER_TEST = new StatusComparator(STATUSES);

    @ParameterizedTest
    @CsvSource({
            "down,nonexistent,-1",
            "down,degraded,-1",
            "nonexistent,down,1",
            "degraded,down,1",
            "down,down,0",
            "nonexistent,other nonexistent,0"
    })
    void verifyIntValue(String code1, String code2, int expected) {
        assertEquals(expected, UNDER_TEST.compare(new Status(code1), new Status(code2)), "Both statuses lowercase");
        assertEquals(expected, UNDER_TEST.compare(new Status(code1.toUpperCase()), new Status(code2)), "First status uppercase");
        assertEquals(expected, UNDER_TEST.compare(new Status(code1), new Status(code2.toUpperCase())), "Second status uppercase");
        assertEquals(expected, UNDER_TEST.compare(new Status(code1.toUpperCase()), new Status(code2.toUpperCase())), "Both statuses uppercase");
    }

    @Test
    void verifySortingWithComparatorWorks() {
        List<Status> expected = new ArrayList<>(STATUSES.size());
        for (String s : STATUSES) {
            expected.add(new Status(s));
        }
        List<Status> actual = new ArrayList<>(expected);
        Collections.shuffle(actual);
        actual.sort(UNDER_TEST);
        assertEquals(expected, actual);
    }

}