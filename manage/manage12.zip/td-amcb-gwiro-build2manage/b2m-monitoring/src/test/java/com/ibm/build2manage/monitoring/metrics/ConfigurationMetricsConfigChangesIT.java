package com.ibm.build2manage.monitoring.metrics;

import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest(classes = MetricsAutoConfiguration.class, properties = {
        "b2m-monitoring.metrics.config-status=bob",
        "b2m-monitoring.metrics.config-tag-name=whatever",
        "b2m-monitoring-test.valid=changed",
        "b2m-monitoring-test.deprecated=changed",
        "b2m-monitoring-test.deprecation=changed",
})
class ConfigurationMetricsConfigChangesIT extends AbstractConfigurationMetricsIT {

    ConfigurationMetricsConfigChangesIT() {
        super("bob", "whatever", 2, -1, -1);
    }
}