package com.ibm.build2manage.monitoring.metrics.kafka;

import io.micrometer.core.instrument.MeterRegistry;
import io.micrometer.core.instrument.Tag;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.mockito.*;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.kafka.listener.ConcurrentMessageListenerContainer;
import org.springframework.kafka.listener.ContainerProperties;
import org.springframework.kafka.listener.KafkaMessageListenerContainer;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.function.ToDoubleFunction;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;

@ExtendWith(MockitoExtension.class)
class KafkaContainerMetricsTest {

    private final String concurrency = UUID.randomUUID().toString();

    private final String activeCount = UUID.randomUUID().toString();

    private final String containerName = UUID.randomUUID().toString();

    @Mock
    private MeterRegistry registry;

    @Mock
    private KafkaTagParser parser;

    @Mock
    private ConcurrentMessageListenerContainer<String, String> container;

    @Mock
    private ContainerProperties properties;

    @Captor
    private ArgumentCaptor<Iterable<Tag>> tags;

    @Captor
    private ArgumentCaptor<ToDoubleFunction<ConcurrentMessageListenerContainer<String, String>>> fct;

    private KafkaContainerMetrics<String, String> underTest;

    @BeforeEach
    void init() {
        underTest = new KafkaContainerMetrics<>(registry, parser, concurrency, activeCount);
        Mockito.when(container.getContainerProperties()).thenReturn(properties);
        Mockito.when(container.getListenerId()).thenReturn(containerName);
        Mockito.when(parser.addTags(any(), eq(properties))).thenAnswer(i -> i.getArgument(0, List.class));
    }

    private void assertTags(Iterable<Tag> value) {
        assertTrue(value instanceof List);
        List<Tag> actual = (List<Tag>) value;
        assertTrue(actual.contains(Tag.of("name", containerName)));
    }

    @Test
    void verifyConcurrency() {
        underTest.configure(container);
        Mockito.verify(registry).gauge(eq(concurrency), tags.capture(), eq(container), fct.capture());
        assertTags(tags.getValue());
        int i = (int) (Math.random() * 10000);
        Mockito.when(container.getConcurrency()).thenReturn(i);
        assertEquals(i, fct.getValue().applyAsDouble(container));
    }

    @ParameterizedTest
    @CsvSource({
            "true,1.0",
            "false,0.0",
            "'true,true',2.0",
            "'false,true',1.0",
            "'true,false',1.0",
            "'false,false',0.0",
    })
    @SuppressWarnings("unchecked")
    void verifyAliveCount(String values, double expected) {
        underTest.configure(container);
        Mockito.verify(registry).gauge(eq(activeCount), tags.capture(), eq(container), fct.capture());
        assertTags(tags.getValue());
        assertEquals(0, fct.getValue().applyAsDouble(container));
        List<KafkaMessageListenerContainer<String, String>> containers = new ArrayList<>(2);
        for (String value : values.split(",")) {
            KafkaMessageListenerContainer<String, String> c = Mockito.mock(KafkaMessageListenerContainer.class);
            containers.add(c);
            Mockito.when(c.isRunning()).thenReturn(Boolean.parseBoolean(value));
        }
        Mockito.when(container.getContainers()).thenReturn(containers);
        assertEquals(expected, fct.getValue().applyAsDouble(container));
    }
}