package com.ibm.build2manage.monitoring.metrics;

import io.micrometer.core.instrument.MeterRegistry;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.info.ProjectInfoAutoConfiguration;
import org.springframework.boot.test.context.SpringBootTest;

import static org.junit.jupiter.api.Assertions.assertEquals;

@EnableAutoConfiguration
@SpringBootTest(classes = {ProjectInfoAutoConfiguration.class, MetricsAutoConfiguration.class}, properties = "b2m-monitoring.metrics.build-time=blob")
class BuildInfoMetricsConfigChangesIT {

    @Autowired
    private MeterRegistry registry;

    @Test
    void testBuildDate() {
        Assertions.assertEquals(ExpectedBuildInfo.TIME.getEpochSecond(), registry.counter("blob").count());
    }

}