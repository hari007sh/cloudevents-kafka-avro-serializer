package com.ibm.build2manage.monitoring.metrics.kafka;

import com.ibm.build2manage.monitoring.metrics.KafkaMetricsAutoConfiguration;
import org.springframework.boot.autoconfigure.kafka.KafkaAutoConfiguration;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest(classes = {KafkaAutoConfiguration.class, KafkaMetricsAutoConfiguration.class}, properties = {
        "spring.application.name=KafkaContainerMetricsConfigChangedIT",
        "spring.kafka.consumer.auto-offset-reset=earliest",
        "b2m-monitoring.metrics.kafka-listeners-max-concurrency=something max",
        "b2m-monitoring.metrics.kafka-listeners-alive-count=whatever active"
})
class KafkaContainerMetricsConfigChangedIT extends AbstractKafkaContainerMetricsIT {

    public KafkaContainerMetricsConfigChangedIT() {
        super("something max", "whatever active");
    }

}
