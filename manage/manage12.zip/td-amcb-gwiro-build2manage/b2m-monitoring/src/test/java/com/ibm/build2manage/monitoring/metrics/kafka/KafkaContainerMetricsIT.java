package com.ibm.build2manage.monitoring.metrics.kafka;

import com.ibm.build2manage.monitoring.metrics.KafkaMetricsAutoConfiguration;
import org.springframework.boot.autoconfigure.kafka.KafkaAutoConfiguration;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest(classes = {KafkaAutoConfiguration.class, KafkaMetricsAutoConfiguration.class}, properties = {
        "spring.application.name=KafkaContainerMetricsIT",
        "spring.kafka.consumer.auto-offset-reset=earliest",
        "spring.kafka.consumer.group-id=container-metrics"
})
public class KafkaContainerMetricsIT extends AbstractKafkaContainerMetricsIT {

    public KafkaContainerMetricsIT() {
        super("kafka listener max requests", "kafka listener alive count");
    }
}
