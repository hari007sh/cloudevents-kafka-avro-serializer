package com.ibm.build2manage.monitoring.health;

import com.ibm.build2manage.web.AbstractWebTest;
import io.micrometer.core.instrument.MeterRegistry;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.core.env.Environment;
import org.springframework.test.context.TestPropertySource;

import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest(classes = HealthAutoConfiguration.class,
        webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT,
        properties = {
                "spring.application.name=MetricBasedHealthIndicatorIT",
                "test.path=/health-metrics",
                "b2m-monitoring.health.metric.test-metric.thresholds.degraded=200",
                "b2m-monitoring.health.metric.test-metric.thresholds.down=400"
        })
class MetricBasedHealthIndicatorIT extends AbstractWebTest {

    @Autowired
    private MeterRegistry registry;

    @Autowired
    private MetricBasedHealthIndicator underTest;

    @Autowired
    private Environment env;

    //    @ParameterizedTest
//    @CsvSource({
//            "100,200,OK",
//            "250,303,DEGRADED",
//            "450,503,DOWN"
//    })
    @Test
    void doNothing() {
        System.out.println(underTest.toString());
    }

}