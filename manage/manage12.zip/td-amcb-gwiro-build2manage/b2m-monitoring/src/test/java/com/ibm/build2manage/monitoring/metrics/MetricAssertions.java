package com.ibm.build2manage.monitoring.metrics;

import io.micrometer.core.instrument.Gauge;
import io.micrometer.core.instrument.Meter;
import io.micrometer.core.instrument.MeterRegistry;
import lombok.RequiredArgsConstructor;
import org.junit.jupiter.api.Assertions;
import org.springframework.stereotype.Component;

import java.util.Collection;

import static org.junit.jupiter.api.Assertions.assertEquals;

@Component
@RequiredArgsConstructor
public class MetricAssertions {

    private final MeterRegistry registry;

    private <T extends Meter> T getMeter(Collection<T> meters, String tagName, String tag) {
        for (T t : meters) {
            if (tag.equals(t.getId().getTag(tagName))) {
                return t;
            }
        }
        return Assertions.fail("Unable to find required meter");
    }

    public Gauge getGauge(String name, String tagName, String tag) {
        return getMeter(registry.get(name).gauges(), tagName, tag);
    }

    public Meter getMeter(String name, String tagName, String tag) {
        return getMeter(registry.get(name).meters(), tagName, tag);
    }

    public void assertCounter(double expected, String name, String tagName, String tag) {
        assertEquals(expected, getMeter(registry.get(name).counters(), tagName, tag).count());
    }

    public void assertGauge(double expected, String name, String tagName, String tag) {
        assertEquals(expected, getMeter(registry.get(name).gauges(), tagName, tag).value());
    }

}
