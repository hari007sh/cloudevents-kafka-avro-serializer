package com.ibm.build2manage.monitoring.metrics.kafka;

import com.ibm.build2manage.monitoring.metrics.KafkaMetricsAutoConfiguration;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest(classes = KafkaMetricsAutoConfiguration.class, properties = {
        "spring.kafka.consumer.auto-offset-reset=earliest",
        "spring.kafka.consumer.group-id=last-processed"
})
public class KafkaRequestsMetricsIT extends AbstractKafkaRequestsMetricsIT {

    public KafkaRequestsMetricsIT() {
        super("kafka requests alive count", "kafka requests last offset");
    }
}
