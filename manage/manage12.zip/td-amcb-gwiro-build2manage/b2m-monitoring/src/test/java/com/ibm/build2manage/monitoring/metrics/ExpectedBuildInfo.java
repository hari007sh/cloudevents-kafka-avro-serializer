package com.ibm.build2manage.monitoring.metrics;

import java.time.Instant;

public class ExpectedBuildInfo {


    /*
     * The values listed here must be in sync with
     * the META-INF/build-info.properties file in the test resources
     */
    public static final Instant TIME = Instant.parse("2022-02-01T14:36:33.066Z");

}
