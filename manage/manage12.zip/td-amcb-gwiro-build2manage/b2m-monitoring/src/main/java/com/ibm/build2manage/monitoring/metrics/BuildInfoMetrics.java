package com.ibm.build2manage.monitoring.metrics;

import io.micrometer.core.instrument.MeterRegistry;
import lombok.RequiredArgsConstructor;
import org.springframework.boot.actuate.autoconfigure.metrics.MeterRegistryCustomizer;
import org.springframework.boot.info.BuildProperties;


@RequiredArgsConstructor
public class BuildInfoMetrics implements MeterRegistryCustomizer<MeterRegistry> {

    private final String meterName;
    private final BuildProperties build;


    @Override
    public void customize(MeterRegistry registry) {
        registry.counter(meterName).increment(build.getTime().getEpochSecond());
    }
}
