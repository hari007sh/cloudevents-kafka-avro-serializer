package com.ibm.build2manage.monitoring.metrics;

import io.micrometer.core.instrument.MeterRegistry;
import io.micrometer.core.instrument.util.IOUtils;
import lombok.RequiredArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.actuate.autoconfigure.metrics.MeterRegistryCustomizer;
import org.springframework.boot.json.JsonParser;
import org.springframework.context.ApplicationContextException;
import org.springframework.core.env.Environment;
import org.springframework.core.io.Resource;
import org.springframework.core.io.support.ResourcePatternResolver;

import java.io.IOException;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Objects;

@RequiredArgsConstructor
public class ConfigurationMetrics implements MeterRegistryCustomizer<MeterRegistry> {

    private static final Logger LOGGER = LoggerFactory.getLogger(ConfigurationMetrics.class);

    private static final List<String> SPRING_RESERVED = Arrays.asList(
            "debug",
            "info",
            "trace",
            "logging",
            "spring",
            "server",
            "management"
    );

    private static final int DEFAULT_VALUE = 1;
    private static final int OVERRIDDEN_VALUE = 2;
    private static final int DEPRECATED_USED = -1;

    private final String meterName;
    private final String tagName;
    private final Environment env;
    private final JsonParser parser;
    private final ResourcePatternResolver resolver;

    @Override
    @SuppressWarnings("unchecked")
    public void customize(MeterRegistry registry) {
        try {
            LOGGER.debug("Scanning classpath for spring configuration metadata");
            Resource[] resources = resolver.getResources("classpath*:META-INF/spring-configuration-metadata.json");
            for (Resource r : resources) {
                LOGGER.debug("Parsing {}", r);
                for (Map<String, Object> p : (List<Map<String, Object>>) parser.parseMap(IOUtils.toString(r.getInputStream())).get("properties")) {
                    String key = (String) p.get("name");
                    boolean overridden = propertyOverridden(key, p.get("defaultValue"));
                    boolean deprecated = p.containsKey("deprecated") || p.containsKey("deprecation");
                    if (deprecated && overridden) {
                        registry.counter(meterName, tagName, key).increment(DEPRECATED_USED);
                        LOGGER.warn("Deprecated configuration key used: {}", key);
                    } else if (!springKey(key)) {
                        LOGGER.debug("Microservice configuration found '{}' using default value? {}", key, !overridden);
                        registry.counter(meterName, tagName, key).increment(overridden ? OVERRIDDEN_VALUE : DEFAULT_VALUE);
                    }
                }
            }
        } catch (IOException e) {
            throw new ApplicationContextException("Unable to parse configuration metadata", e);
        }
    }

    private boolean propertyOverridden(String key, Object defValue) {
        if (defValue == null) {
            return env.getProperty(key) != null;
        }
        Object o = env.getProperty(key, defValue.getClass());
        return o != null && !Objects.equals(o, defValue);
    }

    private static boolean springKey(String key) {
        int i = key.indexOf('.');
        return i >= 0
                && SPRING_RESERVED.contains(key.substring(0, i))
                || SPRING_RESERVED.contains(key);
    }
}
