package com.ibm.build2manage.monitoring.health;

import lombok.RequiredArgsConstructor;
import org.springframework.boot.actuate.health.Status;

import java.util.Comparator;
import java.util.List;

@RequiredArgsConstructor
public class StatusComparator implements Comparator<Status> {

    private final List<String> order;

    @Override
    public int compare(Status o1, Status o2) {
        if (o1.getCode().equalsIgnoreCase(o2.getCode())) {
            return 0;
        }
        for (String s : order) {
            if (s.equalsIgnoreCase(o1.getCode())) {
                return -1;
            } else if (s.equalsIgnoreCase(o2.getCode())) {
                return 1;
            }
        }
        // Not part of the ordering list so they will end up at the end
        return 0;
    }
}
