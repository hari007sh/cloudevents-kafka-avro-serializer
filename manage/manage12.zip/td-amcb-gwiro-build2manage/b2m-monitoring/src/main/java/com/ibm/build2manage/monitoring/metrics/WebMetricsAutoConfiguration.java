package com.ibm.build2manage.monitoring.metrics;

import com.ibm.build2manage.monitoring.metrics.web.OriginTagContributor;
import org.springframework.boot.actuate.metrics.web.servlet.WebMvcTagsContributor;
import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration(proxyBeanMethods = false)
@ConditionalOnClass(WebMvcTagsContributor.class)
public class WebMetricsAutoConfiguration {

    @Bean
    public OriginTagContributor originTagContributor() {
        return new OriginTagContributor();
    }

}
