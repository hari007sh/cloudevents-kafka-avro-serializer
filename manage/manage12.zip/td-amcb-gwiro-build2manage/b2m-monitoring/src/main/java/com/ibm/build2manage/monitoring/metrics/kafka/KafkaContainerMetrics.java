package com.ibm.build2manage.monitoring.metrics.kafka;

import io.micrometer.core.instrument.MeterRegistry;
import io.micrometer.core.instrument.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.kafka.config.ContainerCustomizer;
import org.springframework.kafka.listener.ConcurrentMessageListenerContainer;
import org.springframework.kafka.listener.KafkaMessageListenerContainer;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

@RequiredArgsConstructor
public class KafkaContainerMetrics<K, V> implements ContainerCustomizer<K, V, ConcurrentMessageListenerContainer<K, V>> {

    private final MeterRegistry registry;
    private final KafkaTagParser parser;
    private final String maxConcurrency;
    private final String runningCount;

    @Override
    public void configure(ConcurrentMessageListenerContainer<K, V> container) {
        List<Tag> tags = new ArrayList<>();
        tags.add(Tag.of("name", Objects.requireNonNull(container.getListenerId())));
        parser.addTags(tags, container.getContainerProperties());
        registry.gauge(maxConcurrency,
                tags,
                container,
                ConcurrentMessageListenerContainer::getConcurrency);
        registry.gauge(runningCount,
                tags,
                container,
                c -> c.getContainers().stream().filter(KafkaMessageListenerContainer::isRunning).count());
    }
}
