package com.ibm.build2manage.monitoring.metrics.kafka;

import com.ibm.build2manage.ArrayUtils;
import io.micrometer.core.instrument.Tag;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.springframework.kafka.listener.ContainerProperties;
import org.springframework.lang.NonNull;

import java.util.List;
import java.util.Objects;
import java.util.function.Function;

import static java.util.function.Function.identity;

public class KafkaTagParser {

    /**
     * Add tags related to provided {@link ContainerProperties}.
     *
     * @param tags the list of tags
     * @param properties the container properties
     *
     * @return the list of tags
     */
    @NonNull
    public List<Tag> addTags(@NonNull List<Tag> tags, @NonNull ContainerProperties properties) {
        addTags(tags, "topics", identity(), properties.getTopics());
        addTags(tags, "pattern", Objects::toString, properties.getTopicPattern());
        addTags(tags, "partitions", Objects::toString, properties.getTopicPartitions());
        addTags(tags, "groupId", identity(), properties.getGroupId());
        return tags;
    }

    /**
     * Add tags related to provided {@link ConsumerRecord}.
     *
     * @param tags the list of tags
     * @param consumerRecord the container properties
     *
     * @return the list of tags
     */
    public List<Tag> addTags(@NonNull List<Tag> tags, @NonNull ConsumerRecord<?, ?> consumerRecord) {
        addTags(tags, "topic", identity(), consumerRecord.topic());
        addTags(tags, "partition", Object::toString, consumerRecord.partition());
        return tags;
    }

    /**
     * Add tags of the given name for the provided configuration values.
     *
     * @param tags the list of tags
     * @param name the name of the tag to add the values with
     * @param toString the function to transform a single value into a String
     * @param values the values to turn into a tag
     * @param <T> the type of value to turn into a tag
     */
    @SafeVarargs
    private <T> void addTags(@NonNull List<Tag> tags, @NonNull String name, @NonNull Function<T, String> toString, T... values) {
        if (values != null && values.length > 0) {
            if (values.length > 1) {
                tags.add(Tag.of(name, ArrayUtils.toString(values, toString)));
            } else if (values[0] != null) {
                tags.add(Tag.of(name, toString.apply(values[0])));
            }
        }
    }
}
