package com.ibm.build2manage.monitoring.health;

import com.ibm.build2manage.Thresholds;
import io.micrometer.core.instrument.MeterRegistry;
import org.springframework.boot.actuate.autoconfigure.health.HealthProperties;
import org.springframework.boot.actuate.health.Status;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@Configuration(proxyBeanMethods = false)
@EnableConfigurationProperties(HealthConfiguration.class)
@PropertySource("classpath:health.properties")
public class HealthAutoConfiguration {

    private List<MetricBasedHealthIndicator.MetricHealthIndicator> create(HealthConfiguration config) {
        List<MetricBasedHealthIndicator.MetricHealthIndicator> indicators = new ArrayList<>(config.getMetric().size());
        for (Map.Entry<String, HealthConfiguration.MetricHealthConfiguration> c : config.getMetric().entrySet()) {
            indicators.add(new MetricBasedHealthIndicator.MetricHealthIndicator(c.getKey(), c.getValue().getComparedTo(), c.getValue().getMethod(), getThresholds(c.getValue().getThresholds())));
        }
        return indicators;
    }

    private Thresholds<Status> getThresholds(Map<String, Double> thresholds) {
        Thresholds<Status> result = new Thresholds<>(Status.UP, thresholds.size());
        for (Map.Entry<String, Double> t : thresholds.entrySet()) {
            result.with(t.getValue(), B2mStatus.valueOf(t.getKey()));
        }
        return result;
    }

    @Bean
    private StatusComparator statusComparator(HealthProperties config) {
        return new StatusComparator(config.getStatus().getOrder());
    }

    @Bean
    public MetricBasedHealthIndicator metricBasedHealthIndicator(MeterRegistry registry, HealthConfiguration config, StatusComparator comparator) {
        return new MetricBasedHealthIndicator(registry, create(config), comparator);
    }

}
