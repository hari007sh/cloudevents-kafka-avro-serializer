package com.ibm.build2manage.monitoring.health;

import lombok.RequiredArgsConstructor;
import org.springframework.boot.actuate.health.Health;
import org.springframework.boot.actuate.health.Status;

import java.util.Objects;

/**
 * Home made version of Health Builder that combine health information from multiple elements and returns the proper
 * combined health status and details.
 */
@RequiredArgsConstructor
public class CombinedHealthBuilder {

    private final StatusComparator comparator;

    private final Health.Builder builder = new Health.Builder();
    private Status current = Status.UP;

    /**
     * Update the health of this combined {@link Health}.
     *
     * @param name the name of the component that updates the combined health
     * @param status the status of the component
     *
     * @return this
     */
    public CombinedHealthBuilder update(Object name, Status status) {
        builder.withDetail(Objects.toString(name), status);
        if (comparator.compare(status, current) < 0) {
            current = status;
        }
        return this;
    }

    /**
     * Build the actual combined {@link Health} information.
     *
     * @return the combined {@link Health}
     */
    public Health build() {
        return builder.status(current).build();
    }
}
