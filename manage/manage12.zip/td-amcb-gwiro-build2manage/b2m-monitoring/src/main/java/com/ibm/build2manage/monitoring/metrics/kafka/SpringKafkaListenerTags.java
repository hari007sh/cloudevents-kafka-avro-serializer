package com.ibm.build2manage.monitoring.metrics.kafka;

import io.micrometer.core.instrument.Meter;
import io.micrometer.core.instrument.Tag;
import io.micrometer.core.instrument.config.MeterFilter;
import lombok.RequiredArgsConstructor;
import org.springframework.kafka.config.KafkaListenerEndpointRegistry;
import org.springframework.kafka.listener.ContainerProperties;
import org.springframework.kafka.listener.MessageListenerContainer;
import org.springframework.lang.NonNull;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

/**
 * {@link MeterFilter} implementation adding meaningful tags on the spring.kafka.listener metric. By default, this
 * metrics returned the listenerId which is the implementation name followed by the listener id. This is completely
 * useless for monitoring as it varies depending on the order of discovery and does not give any information that can
 * be
 * correlated with other systems (e.g. is the listener falling behind compared to the topic events).
 * <p>
 * This implementation adds the listener configuration information. This allows to have either the topics, the topic
 * pattern or the topic partitions along with the groupId if it's specified. This means the metric can be correlated
 * with other systems in a meaningful manner.
 */
@RequiredArgsConstructor
public class SpringKafkaListenerTags implements MeterFilter {

    private static final ContainerProperties NULL_OBJECT = new ContainerProperties((Pattern) null);
    private final KafkaListenerEndpointRegistry registry;
    private final KafkaTagParser parser;

    /**
     * Returns the {@link ContainerProperties} for a listener based on its name.
     *
     * @param name the name of the listener
     *
     * @return the the properties of the listener or a blank object if no container found
     */
    private ContainerProperties getProperties(String name) {
        if (name != null) {
            for (MessageListenerContainer container : registry.getListenerContainers()) {
                if (container.getListenerId() != null &&
                        name.startsWith(container.getListenerId())) {
                    return container.getContainerProperties();
                }
            }
        }
        return NULL_OBJECT;
    }

    @Override
    @NonNull
    public Meter.Id map(@NonNull Meter.Id id) {
        // TODO this should be a configurable list of ids
        if (id.getName().equals("spring.kafka.listener")) {
            List<Tag> tags = parser.addTags(new ArrayList<>(1), getProperties(id.getTag("name")));
            return tags.isEmpty() ? id : id.withTags(tags);
        }
        return id;
    }

}
