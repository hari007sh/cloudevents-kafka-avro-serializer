package com.ibm.build2manage.monitoring.metrics.kafka;

import io.micrometer.core.instrument.MeterRegistry;
import io.micrometer.core.instrument.Tag;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import org.apache.kafka.clients.consumer.Consumer;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.springframework.kafka.listener.RecordInterceptor;
import org.springframework.lang.NonNull;

import java.util.ArrayList;
import java.util.List;

/**
 * {@link RecordInterceptor} implementation that record the last offset processed successfully.
 *
 * @param <K> the record key
 * @param <V> the record value
 */
@RequiredArgsConstructor
public class KafkaRequestsMetrics<K, V> implements RecordInterceptor<K, V> {

    private final MeterRegistry registry;
    private final KafkaTagParser parser;
    private final String activeCount;
    private final String lastOffset;
    private final List<TopicPartitionMetrics> topicPartitionMetrics = new ArrayList<>();

    private TopicPartitionMetrics getOrCreate(@NonNull ConsumerRecord<K, V> consumerRecord) {
        String topic = consumerRecord.topic();
        int partition = consumerRecord.partition();
        for (TopicPartitionMetrics l : topicPartitionMetrics) {
            if (topic.equals(l.topic) && partition == l.partition) {
                return l;
            }
        }
        TopicPartitionMetrics metrics = new TopicPartitionMetrics(topic, partition);
        List<Tag> tags = parser.addTags(new ArrayList<>(), consumerRecord);
        registry.gauge(lastOffset, tags, metrics, TopicPartitionMetrics::getOffset);
        registry.gauge(activeCount, tags, metrics, TopicPartitionMetrics::getActiveCount);
        topicPartitionMetrics.add(metrics);
        return metrics;
    }

    @Override
    public ConsumerRecord<K, V> intercept(@NonNull ConsumerRecord<K, V> consumerRecord) {
        getOrCreate(consumerRecord).active();
        return consumerRecord;
    }

    @Override
    public void afterRecord(@NonNull ConsumerRecord<K, V> consumerRecord, @NonNull Consumer<K, V> consumer) {
        TopicPartitionMetrics l = getOrCreate(consumerRecord);
        l.update(consumerRecord.offset());
        l.completed();
    }

    @RequiredArgsConstructor
    private static class TopicPartitionMetrics {

        private final String topic;
        private final int partition;
        @Getter
        private long offset = -1;

        @Getter
        private int activeCount;

        public void update(long newValue) {
            if (offset < newValue) {
                offset = newValue;
            }
        }

        public void active() {
            activeCount++;
        }

        public void completed() {
            // Make sure we do not go below 0. If the stack is
            // properly used, it should never happens but
            // the impact on performance would be minimal for a small
            // safety net  not to return negative value
            if (activeCount > 0) {
                activeCount--;
            }
        }
    }

}
