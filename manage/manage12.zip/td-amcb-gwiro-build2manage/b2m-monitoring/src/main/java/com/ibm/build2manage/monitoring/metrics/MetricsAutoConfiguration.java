package com.ibm.build2manage.monitoring.metrics;

import org.springframework.boot.autoconfigure.condition.ConditionalOnBean;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.boot.info.BuildProperties;
import org.springframework.boot.json.JsonParserFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.core.io.support.ResourcePatternResolver;

@Configuration(proxyBeanMethods = false)
@EnableConfigurationProperties(MetricsConfiguration.class)
@PropertySource("classpath:metrics.properties")
public class MetricsAutoConfiguration {

    @Bean
    @ConditionalOnBean(BuildProperties.class)
    public BuildInfoMetrics buildInfoMetrics(MetricsConfiguration config, BuildProperties build) {
        return new BuildInfoMetrics(config.getBuildTime(), build);
    }

    @Bean
    public ConfigurationMetrics configurationMetrics(MetricsConfiguration config, Environment env, ResourcePatternResolver resolver) {
        return new ConfigurationMetrics(config.getConfigStatus(), config.getConfigTagName(), env, JsonParserFactory.getJsonParser(), resolver);
    }

    @Bean
    public PoolUtilizationMetrics poolUtilizationMetrics(MetricsConfiguration config, ApplicationContext context) {
        return new PoolUtilizationMetrics(config.getPoolActive(), config.getPoolMax(), config.getPoolTagName(), context);
    }

}
