package com.ibm.build2manage.monitoring.health;

import lombok.*;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.ConstructorBinding;

import java.util.*;

@ConfigurationProperties(HealthConfiguration.NAME)
@ConstructorBinding
@RequiredArgsConstructor
@Getter
@ToString
public class HealthConfiguration {

    public static final String NAME = "b2m-monitoring.health";

    private final Map<String, MetricHealthConfiguration> metric;

    public Map<String, MetricHealthConfiguration> getMetric() {
        return metric == null ? Collections.emptyMap() : metric;
    }

    @Getter
    @ConstructorBinding
    @AllArgsConstructor
    @ToString
    public static class MetricHealthConfiguration {

        private final String comparedTo;
        private final ComparisonMethod method;
        // We do not use Status directly since the property converter
        // is not detected during tests since Spring creates 4 different
        // Converter classes and they are not all configured in the same way
        private final Map<String, Double> thresholds;

        public ComparisonMethod getMethod() {
            return method == null ? ComparisonMethod.RAW : method;
        }

        public Map<String, Double> getThresholds() {
            return thresholds == null ? Collections.emptyMap() : thresholds;
        }
    }
}
