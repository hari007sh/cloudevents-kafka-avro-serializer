package com.ibm.build2manage.monitoring.metrics.web;

import io.micrometer.core.instrument.Tag;
import io.micrometer.core.instrument.Tags;
import org.springframework.boot.actuate.metrics.web.servlet.WebMvcTagsContributor;
import org.springframework.http.HttpHeaders;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class OriginTagContributor implements WebMvcTagsContributor {

    private static final String TAG_NAME = "origin";

    private static final Iterable<Tag> UNKNOWN = Tags.of(TAG_NAME, "unknown");

    @Override
    public Iterable<Tag> getTags(HttpServletRequest request, HttpServletResponse response, Object handler, Throwable exception) {
        String tmp = request.getHeader(HttpHeaders.USER_AGENT);
        if (tmp != null) {
            int i = tmp.indexOf('(');
            if (i > 0) {
                return Tags.of(TAG_NAME, tmp.substring(0, i).trim());
            }
            return Tags.of(TAG_NAME, tmp);
        }
        return UNKNOWN;
    }

    @Override
    public Iterable<Tag> getLongRequestTags(HttpServletRequest request, Object handler) {
        return null;
    }
}
