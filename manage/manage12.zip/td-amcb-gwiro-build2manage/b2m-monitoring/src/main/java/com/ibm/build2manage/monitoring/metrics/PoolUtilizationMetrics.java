package com.ibm.build2manage.monitoring.metrics;

import io.micrometer.core.instrument.MeterRegistry;
import io.micrometer.core.instrument.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.aop.target.PoolingConfig;
import org.springframework.boot.actuate.autoconfigure.metrics.MeterRegistryCustomizer;
import org.springframework.context.ApplicationContext;

import java.util.Map;

import static java.util.Collections.singletonList;

@RequiredArgsConstructor
public class PoolUtilizationMetrics implements MeterRegistryCustomizer<MeterRegistry> {

    private final String poolActive;
    private final String poolMax;
    private final String poolTagName;
    private final ApplicationContext context;

    @Override
    public void customize(MeterRegistry registry) {
        Map<String, PoolingConfig> pools = context.getBeansOfType(PoolingConfig.class);
        for (Map.Entry<String, PoolingConfig> pool : pools.entrySet()) {
            registry.gauge(poolActive, singletonList(Tag.of(poolTagName, pool.getKey())), pool.getValue(), PoolingConfig::getActiveCount);
            registry.gauge(poolMax, singletonList(Tag.of(poolTagName, pool.getKey())), pool.getValue(), PoolingConfig::getMaxSize);
        }
    }
}
