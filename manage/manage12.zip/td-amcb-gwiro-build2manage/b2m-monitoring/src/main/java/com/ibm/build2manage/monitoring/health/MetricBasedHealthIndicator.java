package com.ibm.build2manage.monitoring.health;

import com.ibm.build2manage.Thresholds;
import io.micrometer.core.instrument.Meter;
import io.micrometer.core.instrument.MeterRegistry;
import io.micrometer.core.instrument.search.MeterNotFoundException;
import io.micrometer.core.instrument.search.RequiredSearch;
import lombok.RequiredArgsConstructor;
import lombok.ToString;
import org.springframework.boot.actuate.health.Health;
import org.springframework.boot.actuate.health.HealthIndicator;
import org.springframework.boot.actuate.health.Status;

import java.util.List;

@RequiredArgsConstructor
public class MetricBasedHealthIndicator implements HealthIndicator {

    private final MeterRegistry registry;

    private final List<MetricHealthIndicator> indicators;

    private final StatusComparator comparator;

    @Override
    public Health health() {
        CombinedHealthBuilder health = new CombinedHealthBuilder(comparator);
        for (MetricHealthIndicator i : indicators) {
            try {
                for (Meter m : registry.get(i.meterName).meters()) {
                    update(health, m, i);
                }
            } catch (MeterNotFoundException e) {
                health.update(i.meterName, Status.UNKNOWN);
            }
        }
        return health.build();
    }

    private void update(CombinedHealthBuilder health, Meter m, MetricHealthIndicator i) {
        try {
            Meter match = i.comparedTo == null ? null : RequiredSearch.in(registry).name(i.comparedTo).tags(m.getId().getTags()).meter();
            health.update(i.comparator.getDisplay(m, match), i.thresholds.get(i.comparator.applyAsDouble(m, match)));
        } catch (MeterNotFoundException e) {
            health.update(m.getId(), Status.UNKNOWN);
        }
    }

    @RequiredArgsConstructor
    @ToString
    public static class MetricHealthIndicator {
        private final String meterName;
        private final String comparedTo;
        private final ComparisonMethod comparator;
        private final Thresholds<Status> thresholds;
    }
}
