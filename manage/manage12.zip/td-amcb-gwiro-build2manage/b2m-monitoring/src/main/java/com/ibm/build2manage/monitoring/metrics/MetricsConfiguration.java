package com.ibm.build2manage.monitoring.metrics;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.ConstructorBinding;

@ConstructorBinding
@ConfigurationProperties(prefix = MetricsConfiguration.NAME)
@Data
public class MetricsConfiguration {

    public static final String NAME = "b2m-monitoring.metrics";

    // System status configuration
    private final String buildTime;
    private final String configStatus;
    private final String configTagName;

    // Pooling configuration
    private final String poolActive;
    private final String poolMax;
    private final String poolTagName;

    // Kafka configuration
    private final String kafkaListenersMaxConcurrency;
    private final String kafkaListenersAliveCount;
    private final String kafkaRequestsAliveCount;
    private final String kafkaRequestsLastOffset;
}
