package com.ibm.build2manage.monitoring.health;

import lombok.AccessLevel;
import lombok.NoArgsConstructor;
import org.springframework.boot.actuate.health.Status;
import org.springframework.lang.NonNull;

import java.util.Arrays;
import java.util.List;

@NoArgsConstructor(access = AccessLevel.PRIVATE)
public final class B2mStatus {

    /**
     * {@link Status} indicating that the component or subsystem is still working but may not have the most recent
     * information due to a failed dependency.
     */
    public static final Status DEGRADED = new Status("DEGRADED");

    private static final List<Status> statuses;

    static {
        // To think: should we scan the classpath for all Statuses?
        statuses = Arrays.asList(DEGRADED, Status.DOWN, Status.UP, Status.OUT_OF_SERVICE);
    }

    public static Status valueOf(@NonNull String key) {
        for (Status s : statuses) {
            if (s.getCode().equalsIgnoreCase(key)) {
                return s;
            }
        }
        return Status.UNKNOWN;
    }
}
