package com.ibm.build2manage.monitoring.instrument;

import com.ibm.build2manage.IntegerInterval;
import com.sun.tools.attach.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.lang.instrument.Instrumentation;
import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.util.List;
import java.util.Map;
import java.util.Optional;

public class InstrumentationAgent {

    private static final Logger LOGGER = LoggerFactory.getLogger(InstrumentationAgent.class);

    private static volatile Instrumentation global;
    private static final List<Class<?>> simple = List.of(
            Integer.class,
            Long.class,
            Double.class,
            Float.class,
            Character.class,
            Byte.class,
            Boolean.class
    );

    public static void premain(final String agentArgs, final Instrumentation inst) {
        agentmain(agentArgs, inst);
    }

    public static void agentmain(String agentArgs, Instrumentation inst) {
        global = inst;
    }

    public static void load(String applicationName, String path) {
        Optional<VirtualMachineDescriptor> tmp = VirtualMachine.list()
                .stream()
                .filter(jvm -> jvm.displayName().contains(applicationName))
                .findFirst();
        if (tmp.isPresent()) {
            try {
                VirtualMachine vm = VirtualMachine.attach(tmp.get());
                vm.loadAgent(path);
            } catch (AttachNotSupportedException | IOException | AgentLoadException | AgentInitializationException e) {
                LOGGER.error("Unable to attach to VirtualMachine for {}: {}", applicationName, e.getMessage(), e);
            }
        } else {
            LOGGER.error("Unable to attach to VirtualMachine for {}: VirtualMachine not found", applicationName);
        }
    }

    public static long getObjectSize(final Object object) {
        if (global == null) {
            return -1;
        }
        if (object == null) {
            return 0;
        }
        long size = global.getObjectSize(object);
        if (object.getClass().isPrimitive() || simple.contains(object.getClass())) {
            return size;
        }
        if (object instanceof Map) {
            for (Map.Entry<?, ?> e : ((Map<?, ?>) object).entrySet()) {
                size += getObjectSize(e.getKey());
                size += getObjectSize(e.getValue());
            }
        } else if (object instanceof Iterable) {
            for (Object o : (Iterable<?>) object) {
                size += getObjectSize(o);
            }
        } else if (object instanceof String) {
            size += object.toString().length();
        } else {
            for (Field f : object.getClass().getDeclaredFields()) {
                if (!Modifier.isStatic(f.getModifiers())) {
                    f.setAccessible(true);
                    try {
                        size += getObjectSize(f.get(object));
                    } catch (IllegalAccessException e) {
                        throw new RuntimeException(e);
                    }
                }
            }
        }
        return size;
    }

}
