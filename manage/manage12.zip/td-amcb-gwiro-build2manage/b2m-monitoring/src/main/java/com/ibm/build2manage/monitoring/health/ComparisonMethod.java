package com.ibm.build2manage.monitoring.health;

import io.micrometer.core.instrument.Counter;
import io.micrometer.core.instrument.Gauge;
import io.micrometer.core.instrument.Meter;
import lombok.RequiredArgsConstructor;

import java.util.Objects;
import java.util.function.BiFunction;
import java.util.function.ToDoubleBiFunction;

@RequiredArgsConstructor
public enum ComparisonMethod implements ToDoubleBiFunction<Meter, Meter> {

    RAW((t, u) -> getValue(t),
            (t, u) -> t.getId().toString()),
    RATIO((t, u) -> {
        double d = getValue(u);
        if (d == 0.0) {
            return 0;
        }
        return getValue(t) / d;
    }, (t, u) -> t.getId() + " relative to " + u.getId());

    static double getValue(Meter m) {
        Objects.requireNonNull(m, "Null meter received");
        if (m instanceof Counter) {
            return ((Counter) m).count();
        }
        if (m instanceof Gauge) {
            return ((Gauge) m).value();
        }
        throw new IllegalStateException("Meter type not supported " + m.getClass());
    }

    private final ToDoubleBiFunction<Meter, Meter> impl;
    private final BiFunction<Meter, Meter, String> display;

    @Override
    public double applyAsDouble(Meter meter, Meter meter2) {
        return impl.applyAsDouble(meter, meter2);
    }

    public String getDisplay(Meter meter, Meter meter2) {
        return display.apply(meter, meter2);
    }
}
