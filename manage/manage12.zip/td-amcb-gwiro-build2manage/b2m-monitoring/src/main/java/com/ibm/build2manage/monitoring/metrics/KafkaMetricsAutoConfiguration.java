package com.ibm.build2manage.monitoring.metrics;

import com.ibm.build2manage.monitoring.metrics.kafka.*;
import io.micrometer.core.instrument.MeterRegistry;
import org.springframework.boot.autoconfigure.AutoConfigureAfter;
import org.springframework.boot.autoconfigure.condition.ConditionalOnBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.autoconfigure.kafka.KafkaAutoConfiguration;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.annotation.EnableKafka;
import org.springframework.kafka.config.KafkaListenerContainerFactory;
import org.springframework.kafka.config.KafkaListenerEndpointRegistry;

@Configuration(proxyBeanMethods = false)
@ConditionalOnClass(EnableKafka.class)
@AutoConfigureAfter(KafkaAutoConfiguration.class)
public class KafkaMetricsAutoConfiguration {

    @Bean
    @ConditionalOnMissingBean(KafkaTagParser.class)
    public KafkaTagParser kafkaTagParser() {
        return new KafkaTagParser();
    }

    @Bean
    @ConditionalOnBean(KafkaListenerEndpointRegistry.class)
    public SpringKafkaListenerTags springKafkaListenerTags(KafkaListenerEndpointRegistry registry, KafkaTagParser parser) {
        return new SpringKafkaListenerTags(registry, parser);
    }

    @Bean
    @ConditionalOnBean(KafkaListenerContainerFactory.class)
    public <K, V> KafkaContainerMetrics<K, V> kafkaContainerMetrics(MetricsConfiguration config, MeterRegistry registry, KafkaTagParser parser) {
        return new KafkaContainerMetrics<>(
                registry,
                parser,
                config.getKafkaListenersMaxConcurrency(),
                config.getKafkaListenersAliveCount()
        );
    }

    @Bean
    public <K, V> KafkaRequestsMetrics<K, V> kafkaLastProcessedMetric(MetricsConfiguration configs, MeterRegistry registry, KafkaTagParser parser) {
        return new KafkaRequestsMetrics<>(registry, parser, configs.getKafkaRequestsAliveCount(), configs.getKafkaRequestsLastOffset());
    }
}
