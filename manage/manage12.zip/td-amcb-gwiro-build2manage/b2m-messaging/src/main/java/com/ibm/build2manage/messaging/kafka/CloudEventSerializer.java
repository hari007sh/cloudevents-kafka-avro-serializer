package com.ibm.build2manage.messaging.kafka;

import com.ibm.build2manage.encoding.Encoder;
import com.ibm.build2manage.encoding.EncodingFactory;
import io.cloudevents.CloudEvent;
import io.cloudevents.core.builder.CloudEventBuilder;
import io.cloudevents.core.format.EventSerializationException;
import io.confluent.kafka.schemaregistry.client.CachedSchemaRegistryClient;
import io.confluent.kafka.schemaregistry.client.SchemaRegistryClient;
import io.confluent.kafka.serializers.KafkaAvroSerializer;
import org.apache.kafka.common.header.Header;
import org.apache.kafka.common.header.Headers;
import org.apache.kafka.common.header.internals.RecordHeaders;
import org.apache.kafka.common.serialization.Serializer;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.lang.reflect.InvocationTargetException;
import java.net.URI;
import java.util.Map;
import java.util.function.Function;

/**
 * Implementation of {@link Serializer} producing a {@link CloudEvent} from a payload.
 *
 * @param <T> Type to be serialized from.
 */
public class CloudEventSerializer<T> implements Serializer<T> {

    private static final String SCHEMA_REGISTRY_URL_CONFIG = "schema.registry.url";
    private static final int SCHEMA_REGISTRY_CLIENT_CAPACITY = 100;
    public static final String SOURCE_CONFIG = "b2m-messaging.cloudevents.serializer.source";
    public static final String CONTENT_TYPE = "b2m-messaging.cloudevents.serializer.content-type";

    private final KafkaAvroSerializer avroSerializer = new KafkaAvroSerializer();

    private SchemaRegistryClient schemaRegistryClient;
    private static final Function<Object, String> ID = data -> {
        try {
            return data.getClass().getDeclaredMethod("getId").invoke(data).toString();
        } catch (IllegalAccessException | InvocationTargetException | NoSuchMethodException | NullPointerException e) {
            throw new IllegalStateException("Unable to determine the Id of data");
        }
    };

    private static final Function<Object, String> TYPE = data -> data.getClass().getCanonicalName();


    private final Serializer<CloudEvent> delegate = new io.cloudevents.kafka.CloudEventSerializer();
    private io.cloudevents.core.v1.CloudEventBuilder template;
    private String contentType;
    private Encoder<byte[]> encoder;

    private String required(Map<String, ?> configs, String key) {
        Object tmp = configs.get(key);
        if (tmp == null) {
            throw new IllegalArgumentException("Missing required configuration: " + key);
        }
        return (String) tmp;
    }

    @Override
    @SuppressWarnings("unchecked")
    public void configure(Map<String, ?> configs, boolean isKey) {
        delegate.configure(configs, isKey);
        template = CloudEventBuilder.v1().withSource(URI.create(required(configs, SOURCE_CONFIG)));
        contentType = required(configs, CONTENT_TYPE);
        String schemaRegistryUrl = (String) configs.get(SCHEMA_REGISTRY_URL_CONFIG);
        schemaRegistryClient = new CachedSchemaRegistryClient(schemaRegistryUrl, SCHEMA_REGISTRY_CLIENT_CAPACITY);
        avroSerializer.configure(configs, isKey);
    }

    @Override
    public byte[] serialize(String topic, T data) {
        return serialize(topic, new RecordHeaders(), data);
    }

    @Override
    @SuppressWarnings("unchecked")
    public byte[] serialize(String topic, Headers headers, T data) {

        byte[] avroData = avroSerializer.serialize(topic, data); // serialize with avro and publish schema  schema registry
        CloudEventBuilder builder = template
                .withId(getOrDetect("id", data, headers, ID))
                .withType(getOrDetect("type", data, headers, TYPE));
        if (data == null) {
            builder.withoutDataContentType().withoutData();
        } else {
            builder.withDataContentType(contentType)
                    .withData(avroData);
        }
        return delegate.serialize(topic, headers, builder.build());
    }


    private Encoder<byte[]> getEncoder() throws UnsupportedEncodingException {
        if (encoder == null) {
            encoder = EncodingFactory.getEncoder(contentType);
        }
        return encoder;
    }

    private String getOrDetect(String key, T data, Headers headers, Function<Object, String> detected) {
        Header tmp = headers.lastHeader(key);
        if (data == null && (tmp == null || tmp.value() == null)) {
            throw new IllegalStateException("Missing required header: " + key);
        }
        if (tmp == null) {
            return detected.apply(data);
        }
        return new String(tmp.value());
    }
}