package com.ibm.build2manage.messaging;

import com.ibm.build2manage.messaging.kafka.SecurityContextInjector;
import org.springframework.boot.autoconfigure.AutoConfigureBefore;
import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.annotation.EnableKafka;
import org.springframework.security.core.context.SecurityContextHolder;

@Configuration(proxyBeanMethods = false)
@ConditionalOnClass({EnableKafka.class, SecurityContextHolder.class})
@AutoConfigureBefore(KafkaMessagingAutoConfiguration.class)
public class KafkaSecurityAutoConfiguration {

    @Bean
    @ConditionalOnMissingBean(SecurityContextInjector.class)
    public SecurityContextInjector securityContextInjector() {
        return new SecurityContextInjector();
    }
}
