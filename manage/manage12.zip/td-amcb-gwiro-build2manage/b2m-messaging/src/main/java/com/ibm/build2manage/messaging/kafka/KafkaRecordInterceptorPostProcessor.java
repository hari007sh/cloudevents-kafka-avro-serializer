package com.ibm.build2manage.messaging.kafka;

import lombok.RequiredArgsConstructor;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.ObjectProvider;
import org.springframework.beans.factory.config.BeanPostProcessor;
import org.springframework.core.annotation.AnnotationAwareOrderComparator;
import org.springframework.kafka.config.AbstractKafkaListenerContainerFactory;
import org.springframework.kafka.listener.AbstractMessageListenerContainer;
import org.springframework.kafka.listener.CompositeRecordInterceptor;
import org.springframework.kafka.listener.RecordInterceptor;
import org.springframework.lang.NonNull;

/**
 * Implementation of {@link BeanPostProcessor} that inject the record interceptors within an {@link
 * AbstractKafkaListenerContainerFactory}. Depending on the amount of {@link RecordInterceptor} found within the spring
 * context, we may create a {@link CompositeRecordInterceptor} or not.
 *
 * @param <K> the key type
 * @param <V> the value type
 */
@RequiredArgsConstructor
public class KafkaRecordInterceptorPostProcessor<C extends AbstractMessageListenerContainer<K, V>, K, V> implements BeanPostProcessor {

    private final ObjectProvider<RecordInterceptor<K, V>> delegates;

    @Override
    @SuppressWarnings("unchecked")
    public Object postProcessAfterInitialization(@NonNull Object bean, @NonNull String beanName) throws BeansException {
        if (bean instanceof AbstractKafkaListenerContainerFactory) {
            RecordInterceptor<K, V>[] tmp = delegates.stream().sorted(AnnotationAwareOrderComparator.INSTANCE).toArray(RecordInterceptor[]::new);
            if (tmp.length == 1) {
                ((AbstractKafkaListenerContainerFactory<C, K, V>) bean).setRecordInterceptor(tmp[0]);
            } else if (tmp.length > 1) {
                ((AbstractKafkaListenerContainerFactory<C, K, V>) bean).setRecordInterceptor(new CompositeRecordInterceptor<>(tmp));
            }
        }
        return bean;
    }
}
