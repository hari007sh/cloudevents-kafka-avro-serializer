package com.ibm.build2manage.messaging.kafka;

import org.apache.kafka.common.serialization.Deserializer;
import org.apache.kafka.common.serialization.Serde;
import org.apache.kafka.common.serialization.Serializer;

import java.util.Map;

/**
 * Implementation of {@link Serde} allowing to produce and consume {@link io.cloudevents.CloudEvent}.
 *
 * TODO test with integration in streams
 *
 * @param <T> Type to be serialized from and deserialized into.
 */
public class CloudEventSerde<T> implements Serde<T> {

    private final Serializer<T> serializer = new CloudEventSerializer<>();

    private final Deserializer<T> deserializer = new CloudEventDeserializer<>();

    @Override
    public void configure(Map<String, ?> configs, boolean isKey) {
        serializer.configure(configs, isKey);
        deserializer.configure(configs, isKey);
    }

    @Override
    public Serializer<T> serializer() {
        return serializer;
    }

    @Override
    public Deserializer<T> deserializer() {
        return deserializer;
    }
}
