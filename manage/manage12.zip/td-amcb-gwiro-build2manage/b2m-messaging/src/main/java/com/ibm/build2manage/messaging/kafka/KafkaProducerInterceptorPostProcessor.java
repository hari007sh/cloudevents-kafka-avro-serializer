package com.ibm.build2manage.messaging.kafka;

import lombok.RequiredArgsConstructor;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.clients.producer.ProducerInterceptor;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.ObjectProvider;
import org.springframework.beans.factory.config.BeanPostProcessor;
import org.springframework.boot.autoconfigure.kafka.KafkaProperties;
import org.springframework.core.annotation.AnnotationAwareOrderComparator;
import org.springframework.kafka.config.AbstractKafkaListenerContainerFactory;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.listener.AbstractMessageListenerContainer;
import org.springframework.kafka.listener.CompositeRecordInterceptor;
import org.springframework.kafka.listener.RecordInterceptor;
import org.springframework.lang.NonNull;

import java.lang.reflect.InvocationTargetException;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.stream.Collectors;
import java.util.stream.Stream;

/**
 * Implementation of {@link BeanPostProcessor} that inject the record interceptors within an
 * {@link AbstractKafkaListenerContainerFactory}. Depending on the amount of {@link RecordInterceptor} found within the
 * spring context, we may create a {@link CompositeRecordInterceptor} or not.
 */
@RequiredArgsConstructor
public class KafkaProducerInterceptorPostProcessor<K, V> implements BeanPostProcessor {

    private final ObjectProvider<ProducerInterceptor<K, V>> delegates;

    @Override
    public Object postProcessAfterInitialization(@NonNull Object bean, @NonNull String beanName) throws BeansException {
        if (bean instanceof KafkaProperties) {
            Map<String, String> props = ((KafkaProperties) bean).getProducer().getProperties();
            @SuppressWarnings("rawtypes") Stream.Builder<ProducerInterceptor> builder = Stream.builder();
            delegates.stream().forEach(builder::add);
            if (props.containsKey(ProducerConfig.INTERCEPTOR_CLASSES_CONFIG)) {
                Stream.of(props.get(ProducerConfig.INTERCEPTOR_CLASSES_CONFIG).split(",")).map(s -> {
                            try {
                                return Class.forName(s).getConstructor().newInstance();
                            } catch (ReflectiveOperationException e) {
                                throw new RuntimeException(e);
                            }
                        }).map(ProducerInterceptor.class::cast)
                        .forEach(builder::add);
            }
            String key = UUID.randomUUID().toString();
            if (CompositeProducerInterceptor.setInterceptors(key, builder.build()
                    .sorted(AnnotationAwareOrderComparator.INSTANCE)
                    .collect(Collectors.toList()))) {
                props.put(ProducerConfig.INTERCEPTOR_CLASSES_CONFIG, CompositeProducerInterceptor.class.getName());
                props.put(CompositeProducerInterceptor.PROVIDER_CONFIG, key);
            }
        }
        return bean;
    }
}
