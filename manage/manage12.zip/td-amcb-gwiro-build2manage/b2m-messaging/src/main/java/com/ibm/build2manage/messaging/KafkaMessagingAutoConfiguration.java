package com.ibm.build2manage.messaging;

import com.ibm.build2manage.messaging.kafka.KafkaContainerCustomizer;
import com.ibm.build2manage.messaging.kafka.KafkaControllerAdvice;
import com.ibm.build2manage.messaging.kafka.KafkaProducerInterceptorPostProcessor;
import com.ibm.build2manage.messaging.kafka.KafkaRecordInterceptorPostProcessor;
import org.apache.kafka.clients.producer.ProducerInterceptor;
import org.springframework.beans.factory.ObjectProvider;
import org.springframework.boot.autoconfigure.AutoConfigureBefore;
import org.springframework.boot.autoconfigure.condition.ConditionalOnBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
import org.springframework.boot.autoconfigure.kafka.KafkaAutoConfiguration;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.annotation.EnableKafka;
import org.springframework.kafka.config.AbstractKafkaListenerContainerFactory;
import org.springframework.kafka.listener.AbstractMessageListenerContainer;
import org.springframework.kafka.listener.RecordInterceptor;
import org.springframework.web.bind.annotation.ControllerAdvice;

@Configuration(proxyBeanMethods = false)
@ConditionalOnClass(EnableKafka.class)
@AutoConfigureBefore(KafkaAutoConfiguration.class)
public class KafkaMessagingAutoConfiguration {

    @Bean
    public <C extends AbstractMessageListenerContainer<K, V>, K, V> KafkaRecordInterceptorPostProcessor<C, K, V> recordInterceptors(ObjectProvider<RecordInterceptor<K, V>> delegates) {
        return new KafkaRecordInterceptorPostProcessor<>(delegates);
    }

    @Bean
    public <K,V> KafkaProducerInterceptorPostProcessor<K,V> producerInterceptors(ObjectProvider<ProducerInterceptor<K,V>> delegates) {
        return new KafkaProducerInterceptorPostProcessor<>(delegates);
    }

    @Bean
    @ConditionalOnBean(AbstractKafkaListenerContainerFactory.class)
    public <C extends AbstractMessageListenerContainer<K, V>, K, V> KafkaContainerCustomizer<K, V, C> containerCustomizers(AbstractKafkaListenerContainerFactory<C, K, V> factory, ApplicationContext context) {
        KafkaContainerCustomizer<K, V, C> result = new KafkaContainerCustomizer<>(context);
        factory.setContainerCustomizer(result);
        return result;
    }

}
