package com.ibm.build2manage.messaging;

import com.ibm.build2manage.messaging.kafka.KafkaControllerAdvice;
import org.springframework.boot.autoconfigure.AutoConfigureBefore;
import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.annotation.EnableKafka;
import org.springframework.web.bind.annotation.ControllerAdvice;

@Configuration(proxyBeanMethods = false)
@ConditionalOnClass({EnableKafka.class, ControllerAdvice.class})
@AutoConfigureBefore(KafkaMessagingAutoConfiguration.class)
public class KafkaWebAutoConfiguration {

    @Bean
    public KafkaControllerAdvice kafkaControllerAdvice() {
        return new KafkaControllerAdvice();
    }
}
