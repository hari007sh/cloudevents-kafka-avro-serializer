package com.ibm.build2manage.messaging.kafka;

import lombok.RequiredArgsConstructor;
import org.springframework.context.ApplicationContext;
import org.springframework.core.annotation.AnnotationAwareOrderComparator;
import org.springframework.kafka.config.ContainerCustomizer;
import org.springframework.kafka.listener.AbstractMessageListenerContainer;
import org.springframework.lang.NonNull;

import java.util.ArrayList;
import java.util.List;

/**
 * Implementation of {@link ContainerCustomizer} retrieving all other customizer beans and executing each time a
 * container is created.
 *
 * @param <C> the container type.
 * @param <K> the key type.
 * @param <V> the value type.
 */
@RequiredArgsConstructor
public class KafkaContainerCustomizer<K, V, C extends AbstractMessageListenerContainer<K, V>> implements ContainerCustomizer<K, V, C> {

    private final ApplicationContext context;

    @Override
    @SuppressWarnings({"unchecked", "raw"})
    public void configure(@NonNull C container) {
        List<ContainerCustomizer> beans = new ArrayList<>(context.getBeansOfType(ContainerCustomizer.class).values());
        // Remove ourself to avoid infinite loop
        beans.remove(this);
        beans.sort(AnnotationAwareOrderComparator.INSTANCE);
        for (ContainerCustomizer bean : beans) {
            bean.configure(container);
        }
    }
}
