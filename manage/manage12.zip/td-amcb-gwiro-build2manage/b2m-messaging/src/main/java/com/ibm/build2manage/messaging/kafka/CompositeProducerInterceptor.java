package com.ibm.build2manage.messaging.kafka;

import org.apache.kafka.clients.producer.ProducerInterceptor;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.kafka.clients.producer.RecordMetadata;
import org.springframework.util.CollectionUtils;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class CompositeProducerInterceptor<K, V> implements ProducerInterceptor<K, V> {

    public static final String PROVIDER_CONFIG = "spring.producers";

    @SuppressWarnings("rawtypes")
    private final static Map<String, List<ProducerInterceptor>> DELEGATES = new HashMap<>();

    private List<ProducerInterceptor<K, V>> delegates;

    @SuppressWarnings("rawtypes")
    static boolean setInterceptors(String name, List<ProducerInterceptor> delegates) {
        if (delegates.isEmpty()) {
            return false;
        }
        if (DELEGATES.put(name, delegates) != null) {
            throw new IllegalStateException("Cannot overwrite the interceptors");
        }
        return true;
    }

    @Override
    public ProducerRecord<K, V> onSend(ProducerRecord<K, V> record) {
        if (!CollectionUtils.isEmpty(delegates)) {
            ProducerRecord<K, V> result = record;
            for (ProducerInterceptor<K, V> delegate : delegates) {
                result = delegate.onSend(result);
            }
            return result;
        }
        return record;
    }

    @Override
    public void onAcknowledgement(RecordMetadata metadata, Exception exception) {
        if (!CollectionUtils.isEmpty(delegates)) {
            for (ProducerInterceptor<K, V> delegate : delegates) {
                delegate.onAcknowledgement(metadata, exception);
            }
        }
    }

    @Override
    public void close() {
        if (!CollectionUtils.isEmpty(delegates)) {
            for (ProducerInterceptor<K, V> delegate : delegates) {
                delegate.close();
            }
        }
    }

    @Override
    public void configure(Map<String, ?> configs) {
        delegates = new ArrayList<>(0);
        com.ibm.build2manage.CollectionUtils.stream(
                        DELEGATES.remove((String) configs.get(PROVIDER_CONFIG)))
                .forEach(delegates::add);
        delegates.forEach(i -> i.configure(configs));
    }
}
