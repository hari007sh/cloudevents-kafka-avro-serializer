package com.ibm.build2manage.messaging.kafka;

import lombok.RequiredArgsConstructor;
import lombok.extern.log4j.Log4j2;
import org.apache.kafka.common.serialization.Deserializer;
import org.apache.kafka.common.serialization.Serde;
import org.apache.kafka.common.serialization.Serializer;
import org.springframework.kafka.support.serializer.ErrorHandlingDeserializer;
import org.springframework.kafka.support.serializer.FailedDeserializationInfo;

@Log4j2
@RequiredArgsConstructor
public class ErrorHandlingSerde<T> implements Serde<T> {

    private final Serde<T> delegate;
    private ErrorHandlingDeserializer<T> deserializer;

    private T onFailure(FailedDeserializationInfo failedDeserializationInfo) {
        log.atError().withThrowable(failedDeserializationInfo.getException()).log("Unable to deserialize value on topic '{}'", failedDeserializationInfo.getTopic());
        return null;
    }

    @Override
    public Serializer<T> serializer() {
        return delegate.serializer();
    }

    @Override
    public Deserializer<T> deserializer() {
        if (deserializer == null) {
            deserializer = new ErrorHandlingDeserializer<>(delegate.deserializer());
            deserializer.setFailedDeserializationFunction(this::onFailure);
        }
        return deserializer;
    }

}
