package com.ibm.build2manage.messaging.kafka;

import org.apache.kafka.clients.producer.ProducerInterceptor;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.kafka.clients.producer.RecordMetadata;
import org.springframework.http.HttpHeaders;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;

import java.nio.charset.StandardCharsets;
import java.util.Map;

public class SecurityContextInjector implements ProducerInterceptor<Object, Object> {

    @Override
    public ProducerRecord<Object, Object> onSend(ProducerRecord<Object, Object> record) {
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        if (auth != null && record.headers().lastHeader(HttpHeaders.AUTHORIZATION) == null) {
            record.headers().add(HttpHeaders.AUTHORIZATION, ("Basic " + HttpHeaders.encodeBasicAuth(auth.getName(), "", null)).getBytes(StandardCharsets.UTF_8));
        }
        return record;
    }

    @Override
    public void onAcknowledgement(RecordMetadata metadata, Exception exception) {

    }

    @Override
    public void close() {

    }

    @Override
    public void configure(Map<String, ?> configs) {

    }
}
