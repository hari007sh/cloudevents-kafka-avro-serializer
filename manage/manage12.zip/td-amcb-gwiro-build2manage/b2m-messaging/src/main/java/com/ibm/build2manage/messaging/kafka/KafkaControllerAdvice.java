package com.ibm.build2manage.messaging.kafka;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.kafka.KafkaException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

@ControllerAdvice
public class KafkaControllerAdvice {

    private static final Logger LOG = LogManager.getLogger(KafkaControllerAdvice.class);

    @ExceptionHandler(KafkaException.class)
    public void kafkaException(KafkaException ex) {
        LOG.atError().withThrowable(ex).log("Kafka error: {}", ex);
    }
}
