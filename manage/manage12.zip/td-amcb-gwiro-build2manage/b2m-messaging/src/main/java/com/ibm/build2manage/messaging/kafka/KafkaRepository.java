package com.ibm.build2manage.messaging.kafka;

import lombok.Getter;
import lombok.extern.log4j.Log4j2;
import org.apache.kafka.common.serialization.Serde;
import org.apache.kafka.common.utils.Time;
import org.apache.kafka.streams.*;
import org.apache.kafka.streams.kstream.Consumed;
import org.apache.kafka.streams.kstream.GlobalKTable;
import org.apache.kafka.streams.processor.api.Processor;
import org.apache.kafka.streams.processor.api.ProcessorSupplier;
import org.apache.kafka.streams.processor.api.Record;
import org.apache.kafka.streams.state.*;
import org.apache.kafka.streams.state.internals.TimestampedKeyValueStoreBuilder;
import org.springframework.kafka.config.StreamsBuilderFactoryBean;
import org.springframework.lang.NonNull;

import javax.annotation.PostConstruct;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Consumer;

import static org.apache.kafka.common.serialization.Serdes.String;

/**
 * A {@link KafkaRepository} is a read only Repository where the source of the
 * data is stored in memory based on Kafka streams. The main difference between this
 * and a {@link GlobalKTable} is that this instance allows to query the entities using
 * another value than the key.
 *
 * @param <T>  the domain type the repository manages
 * @param <ID> the type of the id of the entity the repository manages
 */
@Log4j2
public class KafkaRepository<T, ID> implements ProcessorSupplier<String, T, Void, Void>, StreamsBuilderFactoryBean.Listener {

    private static final Consumer<?> NO_OP = r -> {
    };

    final Map<String, Map.Entry<Long, T>> byId = new ConcurrentHashMap<>();

    private final StreamsBuilderFactoryBean factory;
    private final String storeName;

    @SuppressWarnings("unchecked")
    private Consumer<T> added = (Consumer<T>) NO_OP;

    @SuppressWarnings("unchecked")
    private Consumer<T> deleted = (Consumer<T>) NO_OP;

    /**
     * Constructor.
     *
     * @param factory the factory used to determine if this instance is ready to be queried
     * @param builder the instance used to create the Kafka components
     * @param topic   the topic which is monitored by this repository
     * @param tClass  the class of the domain type
     * @param serde   the serialization and deserialization strategy
     */
    public KafkaRepository(StreamsBuilderFactoryBean factory,
                           StreamsBuilder builder,
                           String topic,
                           Class<T> tClass,
                           Serde<T> serde
    ) {
        this.factory = factory;
        factory.addListener(this);
        storeName = tClass.getName();
        builder.addGlobalStore(
                new TimestampedKeyValueStoreBuilder<>(
                        Stores.inMemoryKeyValueStore(storeName),
                        String(),
                        serde,
                        Time.SYSTEM),
                topic,
                Consumed.with(String(), serde)
                        .withOffsetResetPolicy(Topology.AutoOffsetReset.EARLIEST),
                this);
    }

    /**
     * Specify a behavior to execute when an item is added. Note that this will be also called when an item is updated,
     * following a deletion call.
     *
     * @param newValue the new behaviour
     * @return this
     */
    @SuppressWarnings("unchecked")
    public KafkaRepository<T, ID> onAddition(Consumer<T> newValue) {
        added = Objects.requireNonNullElse(newValue, (Consumer<T>) NO_OP);
        return this;
    }

    /**
     * Specify a behavior to execute when an item is deleted. Note that this will be also called when an item is updated,
     * before an addition.
     *
     * @param newValue the new behaviour
     * @return this
     */
    @SuppressWarnings("unchecked")
    public KafkaRepository<T, ID> onDeletion(Consumer<T> newValue) {
        deleted = Objects.requireNonNullElse(newValue, (Consumer<T>) NO_OP);
        return this;
    }

    /**
     * Find the domain entity by its id.
     *
     * @param id the entity id
     * @return the entity or null if the entity is not known or this repository is not ready to query
     */
    protected T get(@NonNull ID id) {
        String key = id.toString().toLowerCase();
        if (byId.containsKey(key)) {
            return byId.get(key).getValue();
        }
        return null;
    }

    private void process(Record<String, T> r) {
        String key = r.key().toLowerCase();
        log.info("Event received for '{}' with key '{}'", storeName, key);
        Map.Entry<Long, T> current = byId.get(key);
        if (r.value() == null) {
            byId.remove(key);
            if (current != null) {
                // Not sure why this would happen, but let's be safe
                deleted.accept(current.getValue());
            }
        } else if (current == null) {
            byId.put(key, new AbstractMap.SimpleEntry<>(r.timestamp(), r.value()));
            added.accept(r.value());
        } else if (current.getKey() < r.timestamp()) {
            deleted.accept(current.getValue());
            added.accept(r.value());
            byId.put(key, new AbstractMap.SimpleEntry<>(r.timestamp(), r.value()));
        }
    }

    @Override
    public Processor<String, T, Void, Void> get() {
        return this::process;
    }

    @Override
    public void streamsAdded(@NonNull String id, KafkaStreams streams) {
        // Add the data from the streams
        KeyValueIterator<Object, ValueAndTimestamp<Object>> it = streams.store(StoreQueryParameters.fromNameAndType(storeName, QueryableStoreTypes.timestampedKeyValueStore())).all();
        while (it.hasNext()) {
            KeyValue<Object, ValueAndTimestamp<Object>> tmp = it.next();
            // if tmp.value is null, then we had an issue deserializing the record or the last value was a deletion which we don't bother with
            if (tmp.value != null) {
                process(new Record<>((String) tmp.key, (T) tmp.value.value(), tmp.value.timestamp()));
            }
        }
    }

    @Override
    public void streamsRemoved(@NonNull String id, KafkaStreams streams) {
        // Remove data from the streams if the stream is still running
        // Otherwise, we cannot recover the store, and we are probably shutting down
        if (KafkaStreams.State.RUNNING.equals(streams.state())) {
            KeyValueIterator<Object, ValueAndTimestamp<Object>> it = streams.store(StoreQueryParameters.fromNameAndType(storeName, QueryableStoreTypes.timestampedKeyValueStore())).all();
            while (it.hasNext()) {
                KeyValue<Object, ValueAndTimestamp<Object>> tmp = it.next();
                process(new Record<>((String) tmp.key, null, System.currentTimeMillis()));
            }
        }
    }
}
