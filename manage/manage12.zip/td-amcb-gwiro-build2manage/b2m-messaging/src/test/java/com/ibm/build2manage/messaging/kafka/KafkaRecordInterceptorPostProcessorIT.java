package com.ibm.build2manage.messaging.kafka;

import com.ibm.build2manage.kafka.KafkaTest;
import com.ibm.build2manage.kafka.PublishSpecification;
import com.ibm.build2manage.messaging.KafkaMessagingAutoConfiguration;
import org.apache.kafka.clients.consumer.Consumer;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.kafka.KafkaAutoConfiguration;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.annotation.Import;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.kafka.config.ConcurrentKafkaListenerContainerFactory;
import org.springframework.kafka.config.KafkaListenerEndpointRegistry;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.listener.ConsumerAwareRecordInterceptor;
import org.springframework.lang.NonNull;

import javax.annotation.Priority;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import static org.junit.jupiter.api.Assertions.*;

@KafkaTest
@Import({KafkaRecordInterceptorPostProcessorIT.WithAnnotation.class, KafkaRecordInterceptorPostProcessorIT.WithOrdered.class, KafkaRecordInterceptorPostProcessorIT.WithPriority.class})
@SpringBootTest(classes = {KafkaAutoConfiguration.class, KafkaMessagingAutoConfiguration.class}, properties = {
        "spring.kafka.consumer.auto-offset-reset=earliest"
})
class KafkaRecordInterceptorPostProcessorIT {

    @Autowired
    private KafkaListenerEndpointRegistry registry;

    @Autowired
    private KafkaTemplate<Object, Object> kafka;

    @Autowired
    private ConcurrentKafkaListenerContainerFactory<Object, Object> factory;

    @Autowired
    private List<TimedInterceptor> interceptors;

    @Test
    void testBehavior() {
        assertEquals(3, interceptors.size(), "Not all beans detected");
        for (TimedInterceptor c : interceptors) {
            assertFalse(c.wasCalled());
        }
        PublishSpecification.given("KafkaRecordInterceptorPostProcessorIT")
                .send(kafka)
                .then(registry, factory)
                .waitAtMost(10, TimeUnit.SECONDS);
        for (TimedInterceptor c : interceptors) {
            assertTrue(c.wasCalled());
        }
        List<TimedInterceptor> sortedByExecution = new ArrayList<>(interceptors);
        sortedByExecution.sort(null);

        // We know spring will already sort the beans adequately
        // So we validate the call times are in the same order
        assertEquals(interceptors, sortedByExecution);
    }

    static class TimedInterceptor implements ConsumerAwareRecordInterceptor<String, String>, Comparable<TimedInterceptor> {

        long called = -1;

        public boolean after(TimedInterceptor... cs) {
            for (TimedInterceptor c : cs) {
                if (called <= c.called) {
                    return false;
                }
            }
            return true;
        }

        public boolean wasCalled() {
            return called != -1;
        }

        @Override
        public int compareTo(TimedInterceptor o) {
            return (int) (called - o.called);
        }

        @Override
        public ConsumerRecord<String, String> intercept(@NonNull ConsumerRecord<String, String> consumerRecord, @NonNull Consumer<String, String> consumer) {
            called = System.nanoTime();
            return consumerRecord;
        }
    }

    @Order(10)
    static class WithAnnotation extends TimedInterceptor {
    }

    static class WithOrdered extends TimedInterceptor implements Ordered {

        @Override
        public int getOrder() {
            return -12;
        }
    }

    @Priority(3)
    static class WithPriority extends TimedInterceptor {

    }

}
