package com.ibm.build2manage.messaging.kafka;

import lombok.RequiredArgsConstructor;
import org.apache.kafka.streams.KafkaStreams;
import org.apache.kafka.streams.KeyValue;
import org.apache.kafka.streams.StoreQueryParameters;
import org.apache.kafka.streams.StreamsBuilder;
import org.apache.kafka.streams.processor.ProcessorContext;
import org.apache.kafka.streams.processor.StateStore;
import org.apache.kafka.streams.processor.api.Record;
import org.apache.kafka.streams.state.*;
import org.apache.kafka.streams.state.internals.InMemoryKeyValueStore;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.junit.jupiter.params.provider.MethodSource;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.kafka.config.StreamsBuilderFactoryBean;
import org.springframework.kafka.support.serializer.JsonSerde;

import java.util.*;
import java.util.function.Consumer;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;

@ExtendWith(MockitoExtension.class)
public class KafkaRepositoryTest {

    private final String topic = UUID.randomUUID().toString();
    private final String id = UUID.randomUUID().toString();

    @Mock
    private KafkaStreams streams;

    @Mock
    private StreamsBuilderFactoryBean factory;
    @Mock
    private StreamsBuilder builder;

    @Mock
    private Consumer<TestBean> added;

    @Mock
    private Consumer<TestBean> deleted;

    private KafkaRepository<TestBean, String> create(Consumer<TestBean> added, Consumer<TestBean> deleted) {
        return new KafkaRepository<TestBean, String>(factory, builder, topic, TestBean.class, new JsonSerde<>())
                .onAddition(added)
                .onDeletion(deleted);
    }

    @Test
    void notStarted() {
        assertNull(create(null, null).get(id));
    }

    @Test
    void InitializationAndTearDown() {
        KafkaRepository<TestBean, String> underTest = create(added, deleted);
        TestBean expected = new TestBean(id);
        TestBean expected2 = new TestBean(id + "-2");

        SimpleKeyValueStore store = new SimpleKeyValueStore();
        store.put(id, ValueAndTimestamp.make(expected, System.currentTimeMillis()));
        store.put(id + "-2", ValueAndTimestamp.make(expected2, System.currentTimeMillis()));

        Mockito.when(streams.store(Mockito.argThat(a -> a.storeName().equals(TestBean.class.getName())))).thenReturn(store);
        Mockito.when(streams.state()).thenReturn(KafkaStreams.State.RUNNING);

        underTest.streamsAdded("", streams);

        assertEquals(expected, underTest.get(id));
        assertEquals(expected2, underTest.get(id + "-2"));

        underTest.streamsRemoved("", streams);

        assertNull(underTest.get(id));
        assertNull(underTest.get(id + "-2"));
        Mockito.verify(added, Mockito.times(2)).accept(any());
        Mockito.verify(deleted, Mockito.times(2)).accept(any());
    }


    @Test
    void newRecord() {
        KafkaRepository<TestBean, String> underTest = create(added, deleted);
        TestBean expected = new TestBean(id);
        underTest.get().process(new Record<>(id, expected, System.currentTimeMillis()));
        assertSame(expected, underTest.get(id));
        Mockito.verify(added, Mockito.times(1)).accept(any());
        Mockito.verify(deleted, Mockito.times(0)).accept(any());
    }

    @Test
    void unknownRecordDeleted() {
        KafkaRepository<TestBean, String> underTest = create(added, deleted);
        underTest.get().process(new Record<>(id, null, System.currentTimeMillis()));
        assertNull(underTest.get(id));
        Mockito.verify(added, Mockito.times(0)).accept(any());
        Mockito.verify(deleted, Mockito.times(0)).accept(any());
    }

    @Test
    void deletedRecord() {
        KafkaRepository<TestBean, String> underTest = create(added, deleted);
        TestBean expected = new TestBean(id);
        underTest.get().process(new Record<>(id, expected, System.currentTimeMillis()));
        underTest.get().process(new Record<>(id, null, System.currentTimeMillis() + 10));
        assertNull(underTest.get(id));
        Mockito.verify(added, Mockito.times(1)).accept(any());
        Mockito.verify(deleted, Mockito.times(1)).accept(any());
    }

    @CsvSource({
            "10,1",
            "-10,0",
    })
    @ParameterizedTest
    void update(int delta, int expected) {
        KafkaRepository<TestBean, String> underTest = create(added, deleted);
        TestBean[] beans = new TestBean[]{new TestBean(id), new TestBean(id)};
        long l = System.currentTimeMillis();
        // Initial creation
        underTest.get().process(new Record<>(id, beans[0], l));
        // Update
        underTest.get().process(new Record<>(id, beans[1], l + delta));
        assertSame(beans[expected], underTest.get(id));
        Mockito.verify(added, Mockito.times(expected + 1)).accept(any());
        Mockito.verify(deleted, Mockito.times(expected)).accept(any());
    }


    @RequiredArgsConstructor
    private static class SimpleKeyValueStore implements KeyValueStore<Object, ValueAndTimestamp<Object>> {

        private final HashMap<Object, ValueAndTimestamp<Object>> map = new HashMap<>();

        @Override
        public void put(Object key, ValueAndTimestamp<Object> value) {
            map.put(key, value);
        }

        @Override
        public ValueAndTimestamp<Object> putIfAbsent(Object key, ValueAndTimestamp<Object> value) {
            return null;
        }

        @Override
        public void putAll(List<KeyValue<Object, ValueAndTimestamp<Object>>> entries) {

        }

        @Override
        public ValueAndTimestamp<Object> delete(Object key) {
            return null;
        }

        @Override
        public String name() {
            return null;
        }

        @Override
        public void init(ProcessorContext context, StateStore root) {

        }

        @Override
        public void flush() {

        }

        @Override
        public void close() {

        }

        @Override
        public boolean persistent() {
            return false;
        }

        @Override
        public boolean isOpen() {
            return true;
        }

        @Override
        public ValueAndTimestamp<Object> get(Object key) {
            return map.get(key);
        }

        @Override
        public KeyValueIterator<Object, ValueAndTimestamp<Object>> range(Object from, Object to) {
            return null;
        }

        @Override
        public KeyValueIterator<Object, ValueAndTimestamp<Object>> all() {
            return new TestBeanKVI(map.entrySet().iterator());
        }

        @Override
        public long approximateNumEntries() {
            return map.size();
        }
    }

    @RequiredArgsConstructor
    private static class TestBeanKVI implements KeyValueIterator<Object, ValueAndTimestamp<Object>> {

        private final Iterator<Map.Entry<Object, ValueAndTimestamp<Object>>> it;

        @Override
        public void close() {

        }

        @Override
        public Object peekNextKey() {
            return null;
        }

        @Override
        public boolean hasNext() {
            return it.hasNext();
        }

        @Override
        public KeyValue<Object, ValueAndTimestamp<Object>> next() {
            Map.Entry<Object, ValueAndTimestamp<Object>> tmp = it.next();
            return new KeyValue<>(tmp.getKey(), tmp.getValue());
        }
    }
}
