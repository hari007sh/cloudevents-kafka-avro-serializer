package com.ibm.build2manage.messaging.kafka;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.*;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.ObjectProvider;
import org.springframework.kafka.config.ConcurrentKafkaListenerContainerFactory;
import org.springframework.kafka.listener.CompositeRecordInterceptor;
import org.springframework.kafka.listener.ConcurrentMessageListenerContainer;
import org.springframework.kafka.listener.RecordInterceptor;
import org.springframework.test.util.ReflectionTestUtils;

import java.util.Arrays;
import java.util.stream.Stream;

import static org.junit.jupiter.api.Assertions.assertEquals;


@ExtendWith(MockitoExtension.class)
class KafkaRecordInterceptorPostProcessorTest {

    private static final String NAME = "";

    @Mock
    private ObjectProvider<RecordInterceptor<String, String>> delegates;

    @Mock
    private ConcurrentKafkaListenerContainerFactory<String, String> factory;

    @Mock
    private RecordInterceptor<String, String> i1;

    @Mock
    private RecordInterceptor<String, String> i2;

    @InjectMocks
    private KafkaRecordInterceptorPostProcessor<ConcurrentMessageListenerContainer<String, String>, String, String> underTest;

    @Test
    void noInterceptorShouldNotRegisterInterceptor() {
        Mockito.when(delegates.stream()).thenReturn(Stream.empty());
        underTest.postProcessAfterInitialization(factory, NAME);
        Mockito.verifyNoInteractions(factory);
    }

    @Test
    void oneInterceptorShouldRegisterIt() {
        Mockito.when(delegates.stream()).thenReturn(Stream.of(i1));
        underTest.postProcessAfterInitialization(factory, NAME);
        Mockito.verify(factory).setRecordInterceptor(i1);
    }

    @Test
    @SuppressWarnings("unchecked")
    void oneInterceptorAfterShouldRegister() {
        ArgumentCaptor<CompositeRecordInterceptor<String, String>> composite = ArgumentCaptor.forClass(CompositeRecordInterceptor.class);
        Mockito.when(delegates.stream()).thenReturn(Stream.of(i1, i2));
        underTest.postProcessAfterInitialization(factory, NAME);
        Mockito.verify(factory).setRecordInterceptor(composite.capture());
        assertEquals(Arrays.asList(i1, i2), ReflectionTestUtils.getField(composite.getValue(), "delegates"));
    }
}