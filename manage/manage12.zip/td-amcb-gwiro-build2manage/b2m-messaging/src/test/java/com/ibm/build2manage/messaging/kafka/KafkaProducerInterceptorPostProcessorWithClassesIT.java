package com.ibm.build2manage.messaging.kafka;

import com.ibm.build2manage.kafka.KafkaTest;
import com.ibm.build2manage.messaging.KafkaMessagingAutoConfiguration;
import org.junit.jupiter.api.Test;
import org.springframework.boot.autoconfigure.kafka.KafkaAutoConfiguration;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.annotation.Import;

@KafkaTest
@Import({KafkaProducerInterceptorPostProcessorWithClassesIT.WithAnnotation.class, KafkaProducerInterceptorPostProcessorWithClassesIT.WithOrdered.class, KafkaProducerInterceptorPostProcessorWithClassesIT.WithPriority.class})
@SpringBootTest(classes = {KafkaAutoConfiguration.class, KafkaMessagingAutoConfiguration.class}, properties = {
        "spring.kafka.producer.properties.interceptor.classes=com.ibm.build2manage.messaging.kafka.PredefinedProducerInterceptor"
})
class KafkaProducerInterceptorPostProcessorWithClassesIT extends KafkaProducerInterceptorPostProcessorIT {

    @Test
    void testBehavior() {
        super.testBehavior();
        interceptors.get(0).after(PredefinedProducerInterceptor.instance);
    }

}
