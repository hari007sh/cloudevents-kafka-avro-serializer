package com.ibm.build2manage.messaging.kafka;

import com.ibm.build2manage.kafka.KafkaTest;
import com.ibm.build2manage.kafka.PublishSpecification;
import com.ibm.build2manage.messaging.KafkaMessagingAutoConfiguration;
import com.ibm.build2manage.messaging.KafkaSecurityAutoConfiguration;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.kafka.KafkaAutoConfiguration;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpHeaders;
import org.springframework.kafka.config.ConcurrentKafkaListenerContainerFactory;
import org.springframework.kafka.config.KafkaListenerEndpointRegistry;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.context.SecurityContextImpl;

import java.nio.charset.StandardCharsets;
import java.util.Base64;
import java.util.UUID;
import java.util.concurrent.TimeUnit;

import static org.junit.jupiter.api.Assertions.*;

@KafkaTest
@SpringBootTest(classes = {KafkaAutoConfiguration.class, KafkaMessagingAutoConfiguration.class, KafkaSecurityAutoConfiguration.class},
properties = {
        "spring.kafka.consumer.auto-offset-reset=earliest"
})
class SecurityContextInjectorIT {

    @Autowired
    private KafkaListenerEndpointRegistry registry;

    @Autowired
    private KafkaTemplate<Object, Object> kafka;

    @Autowired
    private ConcurrentKafkaListenerContainerFactory<Object, Object> factory;

    @Test
    void noAuth() {
        ConsumerRecord<Object, Object> actual = PublishSpecification.given(this.getClass().getSimpleName())
                .send(kafka)
                .then(registry, factory)
                .waitAtMost(10, TimeUnit.SECONDS)
                .getData();
        assertNull(actual.headers().lastHeader(HttpHeaders.AUTHORIZATION));
    }

    @Test
    void existingAuth() {
        String expected = UUID.randomUUID().toString();
        SecurityContextHolder.setContext(new SecurityContextImpl(new UsernamePasswordAuthenticationToken(expected, UUID.randomUUID().toString())));
        ConsumerRecord<Object, Object> actual = PublishSpecification.given(this.getClass().getSimpleName())
                .send(kafka)
                .then(registry, factory)
                .waitAtMost(10, TimeUnit.SECONDS)
                .getData();
        assertEquals("Basic " + Base64.getEncoder().encodeToString((expected + ":").getBytes(StandardCharsets.UTF_8)), new String(actual.headers().lastHeader(HttpHeaders.AUTHORIZATION).value()));
    }

    @Test
    void providedHeader() {
        String expected = UUID.randomUUID().toString();
        SecurityContextHolder.setContext(new SecurityContextImpl(new UsernamePasswordAuthenticationToken(UUID.randomUUID().toString(), UUID.randomUUID().toString())));
        ConsumerRecord<Object, Object> actual = PublishSpecification.given(this.getClass().getSimpleName())
                .header(HttpHeaders.AUTHORIZATION, expected)
                .send(kafka)
                .then(registry, factory)
                .waitAtMost(10, TimeUnit.SECONDS)
                .getData();
        assertEquals(expected, new String(actual.headers().lastHeader(HttpHeaders.AUTHORIZATION).value()));
    }

}