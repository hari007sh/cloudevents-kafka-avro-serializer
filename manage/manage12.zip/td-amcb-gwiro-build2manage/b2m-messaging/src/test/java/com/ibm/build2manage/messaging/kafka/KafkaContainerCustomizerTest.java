package com.ibm.build2manage.messaging.kafka;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.context.ApplicationContext;
import org.springframework.kafka.config.ContainerCustomizer;
import org.springframework.kafka.listener.AbstractMessageListenerContainer;

import java.util.Collections;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;

@ExtendWith(MockitoExtension.class)
class KafkaContainerCustomizerTest {

    @Mock
    private ApplicationContext context;

    @Mock
    private AbstractMessageListenerContainer<String, String> container;

    @Mock
    private ContainerCustomizer<String, String, AbstractMessageListenerContainer<String, String>> customizer;

    @InjectMocks
    private KafkaContainerCustomizer<String, String, AbstractMessageListenerContainer<String, String>> underTest;

    @Test
    void onlyUnderTestShouldNotCrash() {
        Mockito.when(context.getBeansOfType(ContainerCustomizer.class)).thenReturn(Collections.singletonMap("whatever", underTest));
        // Make sure we didn't create an infinite loop by calling ourself back
        assertDoesNotThrow(() -> underTest.configure(container));
    }

    @Test
    void beansAreCalled() {
        // Note that sorting is tested by the Integration Test to make sure annotation based
        // sorting works
        Mockito.when(context.getBeansOfType(ContainerCustomizer.class)).thenReturn(Map.of("whatever", underTest, "something", customizer));
        // Make sure we didn't create an infinite loop by calling ourself back
        assertDoesNotThrow(() -> underTest.configure(container));
        // Validate the customizer was called
        Mockito.verify(customizer).configure(container);
    }

}