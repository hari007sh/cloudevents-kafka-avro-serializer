package com.ibm.build2manage.messaging.kafka;

import com.ibm.build2manage.kafka.KafkaTest;
import com.ibm.build2manage.kafka.PublishSpecification;
import com.ibm.build2manage.messaging.KafkaMessagingAutoConfiguration;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.kafka.KafkaAutoConfiguration;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.annotation.Import;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.kafka.config.ConcurrentKafkaListenerContainerFactory;
import org.springframework.kafka.config.ContainerCustomizer;
import org.springframework.kafka.config.KafkaListenerEndpointRegistry;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.listener.ConcurrentMessageListenerContainer;
import org.springframework.lang.NonNull;

import javax.annotation.Priority;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import static org.junit.jupiter.api.Assertions.*;

@KafkaTest
@Import({KafkaContainerCustomizerIT.WithAnnotation.class, KafkaContainerCustomizerIT.WithOrdered.class, KafkaContainerCustomizerIT.WithPriority.class})
@SpringBootTest(classes = {KafkaAutoConfiguration.class, KafkaMessagingAutoConfiguration.class}, properties = {
        "spring.kafka.consumer.auto-offset-reset=earliest"
})
class KafkaContainerCustomizerIT {

    @Autowired
    private KafkaListenerEndpointRegistry registry;

    @Autowired
    private KafkaTemplate<Object, Object> kafka;

    @Autowired
    private ConcurrentKafkaListenerContainerFactory<Object, Object> factory;

    @Autowired
    private List<TimedCustomizer> customizers;

    @Test
    void validateOrderedAndApplied() {
        assertEquals(3, customizers.size(), "Not all beans detected");
        PublishSpecification.given("KafkaContainerCustomizerIT")
                .send(kafka)
                .then(registry, factory)
                .waitAtMost(10, TimeUnit.SECONDS);
        // Validate they were all called
        for (TimedCustomizer c : customizers) {
            assertTrue(c.wasCalled());
        }
        List<TimedCustomizer> sortedByExecution = new ArrayList<>(customizers);
        sortedByExecution.sort(null);

        // We know spring will already sort the beans adequately
        // So we validate the call times are in the same order
        assertEquals(customizers, sortedByExecution);
    }

    static class TimedCustomizer implements ContainerCustomizer<String, String, ConcurrentMessageListenerContainer<String, String>>, Comparable<TimedCustomizer> {

        long called = -1;

        @Override
        public void configure(@NonNull ConcurrentMessageListenerContainer<String, String> container) {
            called = System.nanoTime();
        }

        public boolean after(TimedCustomizer... cs) {
            for (TimedCustomizer c : cs) {
                if (called <= c.called) {
                    return false;
                }
            }
            return true;
        }

        public boolean wasCalled() {
            return called != -1;
        }

        @Override
        public int compareTo(TimedCustomizer o) {
            return (int) (called - o.called);
        }
    }

    @Order(10)
    static class WithAnnotation extends TimedCustomizer {
    }

    static class WithOrdered extends TimedCustomizer implements Ordered {

        @Override
        public int getOrder() {
            return -12;
        }
    }

    @Priority(3)
    static class WithPriority extends TimedCustomizer {

    }

}