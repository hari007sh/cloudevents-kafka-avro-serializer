package com.ibm.build2manage.messaging.kafka;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.ibm.build2manage.encoding.Encoder;
import com.ibm.build2manage.encoding.EncodingFactory;
import com.ibm.build2manage.encoding.EncodingFormat;
import org.apache.kafka.common.header.Headers;
import org.apache.kafka.common.header.internals.RecordHeaders;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;

import java.io.IOException;
import java.util.Map;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.*;

@Disabled
class CloudEventSerdeTest {

    private static final Map<String, ?> configs = Map.of(
            io.cloudevents.kafka.CloudEventSerializer.ENCODING_CONFIG, "STRUCTURED",
            io.cloudevents.kafka.CloudEventSerializer.EVENT_FORMAT_CONFIG, "application/cloudevents+json",
            CloudEventSerializer.SOURCE_CONFIG, "http://unit.example.com/events",
            CloudEventSerializer.CONTENT_TYPE, "cloudevent/serdestest");

    private final String topic = UUID.randomUUID().toString();

    private final String id = UUID.randomUUID().toString();

    private final CloudEventSerde<TestBean> underTest = new CloudEventSerde<>();

    @BeforeAll
    public static void registerEncodingFormat() {
        ObjectMapper mapper = new ObjectMapper();
        EncodingFactory.register(new EncodingFormat<byte[]>("cloudevent/serdestest",
                new Encoder<>() {
                    @Override
                    public <T> byte[] encode(T source, Class<T> tClass) throws IOException {
                        return mapper.writeValueAsBytes(source);
                    }
                }, mapper::readValue));
    }

    @BeforeEach
    public void init() {
        underTest.configure(configs, false);
    }

    @ParameterizedTest
    @CsvSource(value = {
            "false,false",
            "false,true",
            "true,false",
            "true,true",
    })
    void payloadRoundTrip(boolean withId, boolean withType) {
        TestBean expected = new TestBean(id);
        Headers headers = new RecordHeaders();
        if (withId) {
            headers.add("id", id.toString().getBytes());
        }
        if (withType) {
            headers.add("type", TestBean.class.getCanonicalName().getBytes());
        }
        byte[] serialized = underTest.serializer().serialize(topic, headers, expected);
        assertEquals(expected, underTest.deserializer().deserialize(topic, headers, serialized));
    }

    @Test
    void payloadNoHeaders() {
        TestBean expected = new TestBean(id);
        byte[] serialized = underTest.serializer().serialize(topic, expected);
        assertEquals(expected, underTest.deserializer().deserialize(topic, serialized));
    }

    @Test
    void noPayloadNoHeaders() {
        assertThrows(IllegalStateException.class, () -> underTest.serializer().serialize(topic, null));
    }

    @Test
    void noPayloadEmptyHeaders() {
        Headers headers = new RecordHeaders();
        assertThrows(IllegalStateException.class, () -> underTest.serializer().serialize(topic, headers, null));
    }

    @Test
    void noPayloadNoId() {
        Headers headers = new RecordHeaders();
        assertThrows(IllegalStateException.class, () -> underTest.serializer().serialize(topic, headers, null));
    }

    @Test
    void noPayloadNoType() {
        Headers headers = new RecordHeaders();
        headers.add("id", id.toString().getBytes());
        assertThrows(IllegalStateException.class, () -> underTest.serializer().serialize(topic, headers, null));
    }

    @Test
    void noPayloadWithHeaders() {
        Headers headers = new RecordHeaders();
        headers.add("id", id.toString().getBytes());
        headers.add("type", TestBean.class.getCanonicalName().getBytes());
        byte[] serialized = underTest.serializer().serialize(topic, headers, null);
        assertNull(underTest.deserializer().deserialize(topic, headers, serialized));
    }
}
