package com.ibm.build2manage.messaging.kafka;

public class PredefinedProducerInterceptor extends KafkaProducerInterceptorPostProcessorIT.TimedInterceptor {

    public static PredefinedProducerInterceptor instance;

    public PredefinedProducerInterceptor() {
        // Ugly, but works
        instance = this;
    }

}
