package com.ibm.build2manage.validation;

import com.ibm.build2manage.annotations.Prohibit;
import lombok.Data;
import lombok.experimental.Accessors;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.MethodSource;

import javax.validation.ConstraintViolation;
import javax.validation.Validation;
import javax.validation.Validator;
import javax.validation.ValidatorFactory;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.assertEquals;

class ProhibitValidatorTest {

    private static final char[] REGEX_SPECIAL = {'^', '$', '*', '+', '?', '\\', '(', ')', '{', '}', ',', '.', '|'};
    private static final char[] NON_SPECIAL = {'/', 'é', 'ç', '\'', '@'};

    private static Validator validator;

    @BeforeAll
    public static void setUp() {
        ValidatorFactory factory = Validation.buildDefaultValidatorFactory();
        validator = factory.getValidator();
    }

    private void assertInvalid(TestObject test, String expected) {
        Set<ConstraintViolation<TestObject>> constraintViolations = validator.validate(test);
        assertEquals(1, constraintViolations.size());
        assertEquals(expected, constraintViolations.iterator().next().getMessage());
    }

    private void assertValid(TestObject test) {
        Set<ConstraintViolation<TestObject>> constraintViolations = validator.validate(test);
        assertEquals(0, constraintViolations.size());
    }

    private static List<Object[]> generateTests(char[] symbols) {
        List<Object[]> tests = new ArrayList<>(36);
        StringBuilder base = new StringBuilder(36);
        for (char c : symbols) {
            for (int i = 0; i < 36; i++) {
                base.setLength(0);
                base.append(UUID.randomUUID());
                base.setCharAt(i, c);
                tests.add(new Object[]{base.toString()});
            }
        }
        return tests;
    }

    @MethodSource
    public static List<Object[]> regexSpecial() {
        return generateTests(REGEX_SPECIAL);
    }

    @MethodSource
    public static List<Object[]> nonSpecial() {
        return generateTests(NON_SPECIAL);
    }

    @ParameterizedTest
    @MethodSource({"regexSpecial"})
    void shouldRefuseSpecifiedCharacters(String value) {
        assertInvalid(
                new TestObject().regExSpecial(value),
                "The provided value contains one or more prohibited character(s): " + new String(REGEX_SPECIAL)
        );
    }

    @ParameterizedTest
    @MethodSource({"nonSpecial"})
    void shouldAllowNonSpecifiedCharacters(String value) {
        assertValid(new TestObject().regExSpecial(value));
    }

    @ParameterizedTest
    @MethodSource({"regexSpecial", "nonSpecial"})
    void emptyValueIsAlwaysValid(String value) {
        assertValid(new TestObject().emptyValue(value));
    }

    @Accessors(fluent = true)
    @Data
    private static class TestObject {

        @Prohibit("^$*+?\\(){},.|")
        private String regExSpecial;

        @Prohibit(value = "")
        private String emptyValue;

    }

}