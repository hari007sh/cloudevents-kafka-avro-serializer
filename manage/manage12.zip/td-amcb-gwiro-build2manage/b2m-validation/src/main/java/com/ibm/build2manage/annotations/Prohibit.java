package com.ibm.build2manage.annotations;

import com.ibm.build2manage.validation.ProhibitValidator;

import javax.validation.Constraint;
import javax.validation.Payload;
import java.lang.annotation.*;

/**
 * Validation annotation specifying that a string must not contains any character specified. An example of usage for
 * this is to avoid user provided inputs from using regular expression special symbols to do a DoS.
 */
@Retention(RetentionPolicy.RUNTIME)
@Target({ElementType.FIELD, ElementType.PARAMETER, ElementType.ANNOTATION_TYPE})
@Documented
@Constraint(validatedBy = ProhibitValidator.class)
public @interface Prohibit {

    /**
     * @return the error message
     *
     * @see <a href="https://docs.jboss.org/hibernate/validator/4.1/reference/en-US/html/validator-customconstraints.html#validator-customconstraints-constraintannotation">documentation</a>
     */
    String message() default "{com.ibm.build2manage.validation.prohibit}";

    /**
     * @return the validation groups to which this constraint belong
     *
     * @see <a href="https://docs.jboss.org/hibernate/validator/4.1/reference/en-US/html/validator-customconstraints.html#validator-customconstraints-constraintannotation">documentation</a>
     */
    Class<?>[] groups() default {};

    /**
     * @return the custom payload for the client application
     *
     * @see <a href="https://docs.jboss.org/hibernate/validator/4.1/reference/en-US/html/validator-customconstraints.html#validator-customconstraints-constraintannotation">documentation</a>
     */
    Class<? extends Payload>[] payload() default {};

    /**
     * Specify the characters that are prohibited. By default, we refuse boolean, grouping, quantification and wildcard
     * characters. We also refuse escape characters to avoid using \w.
     *
     * @return the prohibited characters
     */
    String value();
}
