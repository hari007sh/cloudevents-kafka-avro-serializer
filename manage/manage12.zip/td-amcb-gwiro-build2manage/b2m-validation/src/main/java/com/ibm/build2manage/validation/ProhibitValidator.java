package com.ibm.build2manage.validation;

import com.ibm.build2manage.annotations.Prohibit;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;
import java.util.Arrays;

/**
 * Implementation of {@link ConstraintValidator} responsible for handling {@link Prohibit} annotation.
 */
public class ProhibitValidator implements ConstraintValidator<Prohibit, String> {

    private char[] characters;

    @Override
    public void initialize(Prohibit constraintAnnotation) {
        this.characters = constraintAnnotation.value().toCharArray();
        Arrays.sort(characters);
    }

    @Override
    public boolean isValid(String s, ConstraintValidatorContext constraintValidatorContext) {
        if (s == null) {
            return true;
        }
        for (int i = 0; i < s.length(); i++) {
            if (Arrays.binarySearch(characters, s.charAt(i)) > -1) {
                return false;
            }
        }
        return true;
    }
}
