package com.ibm.build2manage.validation;

import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
import org.springframework.context.annotation.Bean;
import org.springframework.validation.beanvalidation.MethodValidationPostProcessor;
import org.springframework.web.bind.annotation.ControllerAdvice;

public class ValidationAutoConfiguration {

    /**
     * @return Activate Method validation
     */
    @Bean
    public MethodValidationPostProcessor validation() {
        return new MethodValidationPostProcessor();
    }


    @Bean
    @ConditionalOnClass(ControllerAdvice.class)
    public ValidationControllerAdvice validationControllerAdvice() {
        return new ValidationControllerAdvice();
    }

}
