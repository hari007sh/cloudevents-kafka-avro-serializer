package com.ibm.build2manage.validation;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import javax.validation.ConstraintViolation;
import javax.validation.ConstraintViolationException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@ControllerAdvice
public class ValidationControllerAdvice {


    private static final Logger LOG = LogManager.getLogger(ValidationControllerAdvice.class);

    @ExceptionHandler(ConstraintViolationException.class)
    public ResponseEntity<Map<String, List<String>>> constraintViolation(ConstraintViolationException ex) {
        Map<String, List<String>> errors = new HashMap<>(ex.getConstraintViolations().size());
        LOG.atWarn().withThrowable(ex).log("Bad request received: {}", ex);
        for (ConstraintViolation<?> v : ex.getConstraintViolations()) {
            errors.computeIfAbsent(v.getPropertyPath().toString(), k -> new ArrayList<>()).add(v.getMessage());
        }
        return ResponseEntity
                .status(HttpStatus.BAD_REQUEST)
                .body(errors);
    }

}
